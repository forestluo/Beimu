# -*- coding: utf-8 -*

import sys
import time

from AQMD6040BLS import *

class MotorController:
    # 设备句柄
    __device = None
    # 中断标志
    __interrupt = False

    # 已学习线序
    study = False
    # 额定功率(W)
    power = 800
    # 前进指示
    forward = -1
    # 最低转速(%)
    duty_ratio = 8.0
    # 启动时长(秒)
    skip_time = 2.0
    # 最低换向频率(Hz)
    reverse_freq = 32

    #析构方法
    #当对象被删除时，会自动被调用,然后释放内存
    def __del__(self):
        # 删除设备
        if self.__device is not None :
            del self.__device

    # 定义初始化函数
    def __init__(self, port, address):
        # 生成设备
        self.__device = AQMD6040BLS(port, address)

    # 读取信息
    def read_info(self):
        # 读取信息
        return self.__device.read_info()

    # 停止设备
    def stop_motor(self):
        return self.__device.stop_motor(0)
    
    # 获得实时功率
    def get_power(self):
        # 读取信息
        if not self.__device.read_status():
            print("MotorController.get_power : 无法读取实时信息！")
            return -1
        # 返回数值
        return (self.__device[0x0038].get() * 0.1) * \
            (self.__device[0x0021].get() * 0.01)

    # 获得输入电压
    def get_voltage(self):
        # 读取信息
        if not self.__device.read_reg(0x0038):
            print("MotorController.get_voltage : 无法读取输入电压！")
            return -1
        # 返回数值
        return self.__device[0x0038].get() * 0.1
    
    # 获得实时电流
    def get_current(self):
        # 读取信息
        if not self.__device.read_reg(0x0021):
            print("MotorController.get_current : 无法读取实时电流！")
            return -1
        # 返回数值
        return self.__device[0x0021].get() * 0.01

    # 初始化设备
    def init_device(self):
        # 获得输入电压
        voltage = self.get_voltage()
        # 检查结果
        if voltage < 0:
            print("MotorController.init_device : 无效的输入电压！")
            return False
        # 打印结果
        print("MotroController.init_device : 输入电压%fV"%voltage)

        # 获得实时电流
        current = self.get_current()
        # 检查结果
        if current < 0:
            print("MotorController.init_device : 无效的实时电流！")
            return False
        # 打印结果
        print("MotroController.init_device : 实时电流%fA"%current)
            
        # 初始化电机
        if not self.__device.init_motor() :
            print("MotorController.init_device : 未能初始化电机 !")
            return False
        
        # 电机成功初始化
        print("MotorController.init_device : 电机成功初始化 !")

        # 发送停止指令
        # 正常停止
        if not self.__device.stop_motor(0):
            # 打印信息
            print("MotorController.init_device : 未能停止电机 !")
            return False

        # 返回结果
        return True
    
    # 运行到某个相对位置
    # 基于PWM
    def move(self, pos, pwm = 0, timeout = -1):
        # 检查计数器
        if timeout < 0:
            # 设置成无数
            timeout = sys.maxsize
        # 清理位置计数器
        if not self.__device.clear_pos():
            print("MotorController.move : 位置无法清零！")
            return -1
        #print("MotorController.move : 位置已经清零！")

        # 检查数值
        if pwm == 0 or abs(pwm) > 100:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 检查位置符号
        if pos < 0: pwm = - pwm
        # 设置PWM控制参数
        self.__device[0x0042].set(pwm)
        # 写寄存器
        if not self.__device.write_reg(0x0042):
            print("MotorController.move : 无法设置占空比！")
            return -1
        #print("MotorController.move : 占空比已经设置！")

        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)

        # 实时功率
        power = 0
        # 清理中断标志
        self.__interrupt = False
        # 开始检测设备功率
        while timeout > 0 and power >= 0 and power <= self.power:
            # 计数器减一
            timeout = timeout - 1
            # 读取设备功率
            power = self.get_power()
            # 打印信息
            #print("MotorController.move : %fW"% power)
            
            # 检查中断标志
            if self.__interrupt:
                # 打印信息
                print("MotorController.move : 取消当前命令！")
                break                

            # 读取位置计数器
            if abs(self.__device[0x0024].get()) >= abs(pos):
                # 打印信息
                print("MotorController.move : 已到达目标位！")
                break

            # 读取堵转状态
            if self.__device[0x0032].get() != 0:
                # 打印信息
                print("MotorController.move :", self.__device[0x0032].info)
                break

            # 读取错误状态
            if self.__device[0x0033].get() != 0:
                # 打印信息
                print("MotorController.move :", self.__device[0x0033].info)
                break

        # 检查数据
        if power < 0:
            # 打印信息
            print("MotorController.move : 无法读取实时功率！")
        elif power > self.power:
            # 打印信息
            print("MotorController.move : 实时功率(%dW)超出额定功率！"% power)
        
        # 停止执行
        if not self.__device.stop_motor(0):
            # 打印信息
            print("MotorController.move : 无法停止设备！")
            return -1
        # 打印信息
        #print("MotorController.move : 设备已经停止！")
        if power < 0: return -1

        # 读取位置计数器
        if not self.__device.read_reg(0x0024):
            # 打印信息
            print("MotorController.move : 无法读取位置信息！")
            return -1
        #print("MotorController.move : 已读取位置信息！")

        # 清理标志
        self.__interrupt = False
        # 返回结果
        return abs(self.__device[0x0024].get())

    # 运行到某个相对位置
    # 基于换向频率
    def moveto(self, pos, timeout = -1):
        # 检查计数器
        if timeout < 0:
            # 设置成无数
            timeout = sys.maxsize
        # 清理位置计数器
        if not self.__device.clear_pos():
            print("MotorController.moveto : 位置无法清零！")
            return -1
        #print("MotorController.moveto : 位置已经清零！")

        # 设置换向频率(0.1Hz)
        self.__device[0x0044].set(self.reverse_freq * 10)
        # 设置相对位置模式
        self.__device[0x0045].set(1)
        # 设置目标位置(脉冲数)
        self.__device[0x0046].set(pos * self.forward)
        # 写入寄存器
        if not self.__device.write_reg(0x0044, 3):
            print("MotorController.moveto : 写寄存器失败！")
            return False
        
        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)

        # 实时功率
        power = 0        
        # 清理标志
        self.__interrupt = False
        # 开始检测设备功率
        while timeout > 0 and power >= 0 and power <= self.power * 1.1:
        #while timeout > 0 and power >= 0:
            # 计数器减一
            timeout = timeout - 1
            # 读取设备功率
            power = self.get_power()
            # 打印信息
            #print("MotorController.moveto : %fW"% power)

            # 检查中断标志
            if self.__interrupt:
                # 打印信息
                print("MotorController.moveto : 取消当前命令！")
                break
            
            # 读取堵转状态
            if self.__device[0x0023].get() == 1:
                # 打印信息
                print("MotorController.moveto : 已到达目标！")
                break

            # 读取堵转状态
            if self.__device[0x0032].get() != 0:
                # 打印信息
                print("MotorController.moveto :", self.__device[0x0032].info)
                break

            # 读取错误状态
            if self.__device[0x0033].get() != 0:
                # 打印信息
                print("MotorController.moveto :", self.__device[0x0033].info)
                break

        # 检查数据
        if power < 0:
            # 打印信息
            print("MotorController.moveto : 无法读取实时功率！")
        elif power > self.power:
            # 打印信息
            print("MotorController.moveto : 实时功率(%dW)超出额定功率10%！"% power)
        
        # 停止执行
        if not self.__device.stop_motor(0):
            # 打印信息
            print("MotorController.moveto : 无法停止设备！")
            return -1
        # 打印信息
        #print("MotorController.moveto : 设备已经停止！")
        if power < 0: return -1

        # 读取位置计数器
        if not self.__device.read_reg(0x0024):
            # 打印信息
            print("MotorController.moveto : 无法读取位置信息！")
            return -1
        #print("MotorController.moveto : 已读取位置信息！")

        # 清理中断标志
        self.__interrupt = False
        # 返回结果
        return abs(self.__device[0x0024].get())

    # 向前运行直至到头（堵转）
    def move_forward(self, pwm = 0):

        # 清理位置计数器
        if not self.__device.clear_pos():
            print("MotorController.move_forward : 位置无法清零！")
            return -1
        #print("MotorController.move_forward : 位置已经清零！")

        # 检查数值
        if pwm == 0 or abs(pwm) > 100:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 设置PWM控制参数
        self.__device[0x0042].set(pwm)
        # 写寄存器
        if not self.__device.write_reg(0x0042):
            print("MotorController.move_forward : 无法设置占空比！")
            return -1
        #print("MotorController.move_forward : 占空比已经设置！")

        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)

        # 实时功率
        power = 0
        # 超时计数
        timeout = 0
        # 清理中断标志
        self.__interrupt = False
        # 开始检测设备功率
        while timeout <= 10 * self.skip_time and power >= 0:
            # 读取设备功率
            power = self.get_power()
            # 打印信息
            #print("MotorController.move_forward : %fW"% power)

            # 检查功率超出情况
            if power < self.power:
                # 计数器清零
                timeout = 0
            else:
                # 计数器加一
                timeout = timeout + 1
            
            # 检查中断标志
            if self.__interrupt:
                # 打印信息
                print("MotorController.move_forward : 取消当前命令！")
                break
            
            # 读取堵转状态
            if self.__device[0x0032].get() != 0:
                # 打印信息
                print("MotorController.move_forward : %s！"% self.__device[0x0032].info)
                break

            # 读取错误状态
            if self.__device[0x0033].get() != 0:
                # 打印信息
                print("MotorController.move_forward : %s！"% self.__device[0x0033].info)
                break

        # 检查数据
        if power < 0:
            # 打印信息
            print("MotorController.move_forward : 无法读取实时功率！")
        elif power > self.power:
            # 打印信息
            print("MotorController.move_forward : 实时功率(%dW)超出额定功率！"% power)
            
        # 停止执行
        if not self.__device.stop_motor(0):
            # 打印信息
            print("MotorController.move_forward : 无法停止设备！")
            return -1
        # 打印信息
        #print("MotorController.move_forward : 设备已经停止！")
        if power < 0: return -1

        # 读取位置计数器
        if not self.__device.read_reg(0x0024):
            # 打印信息
            print("MotorController.move_forward : 无法读取位置信息！")
            return -1
        #print("MotorController.move_forward : 已读取位置信息！")

        # 清理中断标志
        self.__interrupt = False
        # 返回结果
        return abs(self.__device[0x0024].get())

    # 向前运行直至到头（堵转）
    def move_backward(self, pwm = 0):
      
        # 清理位置计数器
        if not self.__device.clear_pos():
            print("MotorController.move_backward : 位置无法清零！")
            return -1
        #print("MotorController.move_backward : 位置已经清零！")

        # 检查数值
        if pwm == 0 or abs(pwm) > 100:
            # 计算PWM控制参数
            pwm = - int(self.duty_ratio * self.forward / 0.1)
        # 设置PWM控制参数
        self.__device[0x0042].set(pwm)
        # 写寄存器
        if not self.__device.write_reg(0x0042):
            print("MotorController.move_backward : 无法设置占空比！")
            return -1
        #print("MotorController.move_backward : 占空比已经设置！")

        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)
        
        # 实时功率
        power = 0
        # 计数器
        timeout = 0
        # 清理中断标志
        self.__interrupt = False       
        # 开始检测设备功率
        while timeout <= 10 * self.skip_time and power >= 0:
            # 读取设备功率
            power = self.get_power()
            # 打印信息
            #print("MotorController.move_backward : %fW"% power)
            
            # 检查功率超出情况
            if power < self.power:
                # 计数器清零
                timeout = 0
            else:
                # 计数器加一
                timeout = timeout + 1

            # 检查中断标志
            if self.__interrupt:
                # 打印信息
                print("MotorController.move_backward : 取消当前命令！")
                break
            
            # 读取堵转状态
            if self.__device[0x0032].get() != 0:
                # 打印信息
                print("MotorController.move_backward : %s !"% self.__device[0x0032].info)
                break

            # 读取错误状态
            if self.__device[0x0033].get() != 0:
                # 打印信息
                print("MotorController.move_backward : %s ！"% self.__device[0x0033].info)
                break

        # 检查数据
        if power < 0:            
            # 打印信息
            print("MotorController.move_backward : 无法读取实时功率！")
        elif power > self.power:
            # 打印信息
            print("MotorController.move_backward : 实时功率(%dW)超出额定功率！"% power)
        
        # 停止执行
        if not self.__device.stop_motor(0):
            # 打印信息
            print("MotorController.move_backward : 无法停止设备！")
            return -1
        # 打印信息
        #print("MotorController.move_backward : 设备已经停止！")
        if power < 0: return -1

        # 读取位置计数器
        if not self.__device.read_reg(0x0024):
            # 打印信息
            print("MotorController.move_backward : 无法读取位置信息！")
            return -1
        #print("MotorController.move_backward : 已读取位置信息！")

        # 清理中断标志
        self.__interrupt = False
        # 返回结果
        return abs(self.__device[0x0024].get())
        
# 定义主函数
def main():

    # 创建控制器
    myController = MotorController("/dev/ttyUSB0", 0x05)

    # 检查设备是否存在
    if myController.read_info():
        print("MotorController.main : 设备存在 !")
        # 初始化设备
        myController.init_device()
        
        # 反复行走
        for i in range(0, 1):
            # 向前进
            position1 = myController.move_forward()
            print("MotorController.main : 前进位置计数%d"% position1)
            # 向后退
            position2 = myController.move_backward()
            print("MotorController.main : 后退位置计数%d"% position2)

    else:
        print("MotorController.main : 设备不存在 !")

    # 删除控制器
    del myController

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("MotorController.__main__ :", str(e))
        print("MotorController.__main__ : unexpected exit !")