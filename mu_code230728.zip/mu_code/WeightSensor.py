# -*- coding: utf-8 -*

from YP353 import *

class WeightSensor:
    # 设备句柄
    __device = None

    #析构方法
    #当对象被删除时，会自动被调用,然后释放内存
    def __del__(self):
        # 删除设备
        if self.__device is not None :
            del self.__device

    # 定义初始化函数
    def __init__(self, port, address):
        # 生成设备
        self.__device = YP353(port, address)
   
    # 读取重量计数
    def get_weight(self):
        # 读取电能计数
        if not self.__device.read_reg(0x0001):
            print("WeightSensor.get_weight : fail to read R[0001] !")
            return -1
        # 返回结果
        return (self.__device[0x0001].get() >> 16) & 0xFFFF

# 定义主函数
def main():

    # 创建传感器
    mySensor = WeightSensor("/dev/ttyUSB1", 0x03)

    # 检查传感器
    if mySensor.get_weight() >= 0:
        print("称重计数：%d"%mySensor.get_weight())
    else:
        print("WeightSensor.main : sensor not exists !")

    # 删除传感器
    del mySensor

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("WeightSensor.__main__ :", str(e))
        print("WeightSensor.__main__ : unexpected exit !")