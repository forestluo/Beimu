# -*- coding: utf-8 -*

import time
import serial
import struct
import threading
import traceback

from SerialPort import *

class R200XD(SerialPort):
    # 结果集
    __rfids = []
    # 同步锁
    __lock = threading.Lock()

    # 定义初始化函数
    def __init__(self, name):
        # 调用父函数初始化
        SerialPort.__init__(self, name)
        # 设置串口参数
        # 需要与设备设置保持一致
        self._set_port(115200, serial.EIGHTBITS,
            serial.PARITY_NONE, serial.STOPBITS_ONE)
        
    # 获得RFID记录
    def get_rfids(self, clear = False):
        # 结果集
        rfids = []
        # 锁定
        self.__lock.acquire()
        # 循环处理
        for i in range(0, len(self.__rfids)):
            # 新结果
            rfid = [None, 0, 0, 0]
            # 设置数值
            rfid[0] = self.__rfids[i][0]
            rfid[1] = self.__rfids[i][1]
            rfid[2] = self.__rfids[i][2]
            rfid[3] = self.__rfids[i][3]
            # 增加结果
            rfids.append(rfid)
        # 检查标志位
        if clear: self.__rfids = []
        # 释放
        self.__lock.release()
        # 返回拷贝结果
        return rfids
    
    # 配置单天线
    def set_ant(self, index):
        # 打印信息
        if (self.debug):
            print("R200XD.set_ant : begin !")
        if(index <= 0 or index > 4):
            print("R200XD.set_ant : invalid ant index(%d) !"% index)
            return False
        # 拼接命令字
        buffer = struct.pack(">BBBBBBBBB",
            # 帧头
            0xBB,
            # 帧类型
            0x00,
            # 指令代码
            0x1B,
            # 指令长度
            0x00, 0x02,
            # 参数
            # 单天线
            0x01,
            # 天线端口号
            index,
            # 校验和
            (0x00 + 0x1B + 0x00 + 0x02 + 0x01 + index) & 0xFF,
            # 帧尾
            0x7E
            )
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x1B")
            print("\tPL = 2")
            print("\toption = 0x01")
            print("\tant = %d"%index)
            print("\tbytes = 0x%s"%buffer.hex())
        try:
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : port was opened !")
            # 向串口输出
            serialPort.write(buffer)
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : send request !")
            # 等待必要的时间
            time.sleep(0.1)
            # 从串口读取
            input = serialPort.read_all()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : receive response !")
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : port was closed !")
            # 检查反馈结果
            if input is None or len(input) < 7:
                # 打印信息
                if (self.debug): \
                    print("R200XD.set_ant : invalid response !")
                return None
            # 打印信息
            if (self.debug): \
                print("\tbytes[%d] = 0x%s"%(len(input), input.hex()))

        except Exception as e:
            print("R200XD:set_ant :", str(e))
            print("R200XD:set_ant : unexpected exit !")
            # 返回结果
            return False

        # 检查帧头
        if input[0] != 0xBB:
            # 打印信息
            if (self.debug):
                print("R200XD:set_ant : invalid header !")
            return False
        # 检查帧尾
        if input[len(input) - 1] != 0x7E:
            # 打印信息
            if (self.debug):
                print("R200XD:set_ant : invalid end !")
            return False
        
        # 获得类型
        type = input[1] & 0xFF
        # 打印信息
        if (self.debug):
            print("\ttype = %d"% type)
        # 检查类型
        if type != 0x01:
            print("R200XD.set_ant : invalid type !")
            return False
        
        # 获得命令
        command = input[2] & 0xFF
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x%02X"% command)
        # 检查命令
        if command != 0x1B:
            print("R200XD.set_ant : invalid command !")
            return False

        # 获得长度
        PL = struct.unpack("!H", input[3 : 5])[0] & 0xFFFF
        # 打印信息
        if (self.debug):
            print("\tPL = %d"% PL)
        # 检查长度
        if PL != 0x0001:
            print("R200XD.set_ant : invalid parameter length !")
            return False

        # 获得参数
        option = input[5] & 0xFF
        # 打印信息
        if (self.debug):
            print("\toption = %d"% option)
        # 检查长度
        if option != 0x00:
            print("R200XD.set_ant : invalid option !")
            return False

        checksum = 0
        # 获得cheksum
        for i in range(1, len(input) - 2):
            checksum = checksum + input[i]
        # 检查checksum
        if input[len(input) - 2] != (checksum & 0xFF):
            print("R200XD.set_ant : invalid checksum !")
            return False
        # 打印信息
        if (self.debug):
            print("R200XD.set_ant : sucessfully done !")
        # 返回结果
        return True

    # 设置多天线模式
    def set_ants(self, ant1 = 4, ant2 = 4, ant3 = 4, ant4 = 4):
        # 打印信息
        if (self.debug):
            print("R200XD.set_ants : begin !")
        # 拼接命令字
        buffer = struct.pack(">BBBBBBBBBBBB",
            # 帧头
            0xBB,
            # 帧类型
            0x00,
            # 指令代码
            0x1B,
            # 指令长度
            0x00, 0x05,
            # 参数
            # 多天线
            0x02,
            # 天线工作次数
            ant1 & 0xFF, ant2 & 0xFF, ant3 & 0xFF, ant4 & 0xFF,
            # 校验和
            (0x00 + 0x1B + 0x00 + 0x05 + 0x02 + (ant1 & 0xFF) + (ant2 & 0xFF) + (ant3 & 0xFF) + (ant4 & 0xFF)) & 0xFF,
            # 帧尾
            0x7E
            )
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x1B")
            print("\tPL = 5")
            print("\toption = 0x02")
            print("\tant = 0xFFFFFFFF")
            print("\tbytes = 0x%s"%buffer.hex())
        try:
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ants : port was opened !")
            # 向串口输出
            serialPort.write(buffer)
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ants : send request !")
            # 等待必要的时间
            time.sleep(0.1)
            # 从串口读取
            input = serialPort.read_all()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ants : receive response !")
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ants : port was closed !")
            # 检查反馈结果
            if input is None or len(input) < 7:
                # 打印信息
                if (self.debug): \
                    print("R200XD.set_ants : invalid response !")
                return None
            # 打印信息
            if (self.debug): \
                print("\tbytes[%d] = 0x%s"%(len(input), input.hex()))

        except Exception as e:
            print("R200XD:set_ants :", str(e))
            print("R200XD:set_ants : unexpected exit !")
            # 返回结果
            return False

        # 检查帧头
        if input[0] != 0xBB:
            # 打印信息
            if (self.debug):
                print("R200XD:set_ants : invalid header !")
            return False
        # 检查帧尾
        if input[len(input) - 1] != 0x7E:
            # 打印信息
            if (self.debug):
                print("R200XD:set_ants : invalid end !")
            return False
        
        # 获得类型
        type = input[1] & 0xFF
        # 打印信息
        if (self.debug):
            print("\ttype = %d"% type)
        # 检查类型
        if type != 0x01:
            print("R200XD.set_ants : invalid type(%d) !"% type)
            return False
        
        # 获得命令
        command = input[2] & 0xFF
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x%02X"% command)
        # 检查命令
        if command != 0x1B:
            print("R200XD.set_ants : invalid command !")
            return False

        # 获得长度
        PL = struct.unpack("!H", input[3 : 5])[0] & 0xFFFF
        # 打印信息
        if (self.debug):
            print("\tPL = %d"% PL)
        # 检查长度
        if PL != 0x0001:
            print("R200XD.set_ants : invalid parameter length !")
            return False

        # 获得参数
        option = input[5] & 0xFF
        # 打印信息
        if (self.debug):
            print("\toption = %d"% option)
        # 检查长度
        if option != 0x00:
            print("R200XD.set_ants : invalid option !")
            return False

        checksum = 0
        # 获得cheksum
        for i in range(1, len(input) - 2):
            checksum = checksum + input[i]
        # 检查checksum
        if input[len(input) - 2] != (checksum & 0xFF):
            print("R200XD.set_ants : invalid checksum !")
            return False
        # 打印信息
        if (self.debug):
            print("R200XD.set_ants : sucessfully done !")
        # 返回结果
        return True

    # 停止读标签
    def stop_read(self, wait = False):
        # 打印信息
        if (self.debug):
            print("R200XD.stop_read : begin !")
        # 拼接命令字
        buffer = struct.pack(">BBBBBBB",
            # 帧头
            0xBB,
            # 帧类型
            0x00,
            # 指令代码
            0x28,
            # 指令长度
            0x00, 0x00,
            # 校验和
            0x28,
            # 帧尾
            0x7E
            )
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x28")
            print("\tPL = 0")
            print("\tbytes = 0x%s"%buffer.hex())
        try:
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug): \
                print("R200XD.stop_read : port was opened !")
            # 向串口输出
            serialPort.write(buffer)
            # 打印信息
            if (self.debug): \
                print("R200XD.stop_read : send request !")
            # 检查标志位
            if wait:
                # 等待必要的时间
                time.sleep(0.1)
                # 从串口读取
                input = serialPort.read_all()
                # 打印信息
                if (self.debug): \
                    print("R200XD.stop_read : receive response !")
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug): \
                print("R200XD.stop_read : port was closed !")
            # 检查标志位
            if wait:
                # 检查反馈结果
                if input is None or len(input) < 7:
                    # 打印信息
                    if (self.debug): \
                        print("R200XD.stop_read : invalid response !")
                    return None
                # 打印信息
                if (self.debug): \
                    print("\tbytes[%d] = 0x%s"%(len(input), input.hex()))

        except Exception as e:
            print("R200XD:stop_read :", str(e))
            print("R200XD:stop_read : unexpected exit !")
            # 返回结果
            return False

        # 检查标志位
        if not wait: return True

        # 检查帧头
        if input[0] != 0xBB:
            # 打印信息
            if (self.debug):
                print("R200XD:stop_read : invalid header !")
            return False
        # 检查帧尾
        if input[len(input) - 1] != 0x7E:
            # 打印信息
            if (self.debug):
                print("R200XD:stop_read : invalid end !")
            return False
        
        # 获得类型
        type = input[1] & 0xFF
        # 打印信息
        if (self.debug):
            print("\ttype = %d"% type)
        # 检查类型
        if type != 0x01:
            print("R200XD.stop_read : invalid type !")
            return False
        
        # 获得命令
        command = input[2] & 0xFF
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x%02X"% command)
        # 检查命令
        if command != 0x28:
            print("R200XD.stop_read : invalid command !")
            return False

        # 获得长度
        PL = struct.unpack("!H", input[3 : 5])[0] & 0xFFFF
        # 打印信息
        if (self.debug):
            print("\tPL = %d"% PL)
        # 检查长度
        if PL != 0x0001:
            print("R200XD.stop_read : invalid parameter length !")
            return False

        # 获得参数
        option = input[5] & 0xFF
        # 打印信息
        if (self.debug):
            print("\toption = %d"% option)
        # 检查长度
        if option != 0x00:
            print("R200XD.stop_read : invalid option !")
            return False

        checksum = 0
        # 获得cheksum
        for i in range(1, len(input) - 2):
            checksum = checksum + input[i]
        # 检查checksum
        if input[len(input) - 2] != (checksum & 0xFF):
            print("R200XD.stop_read : invalid checksum !")
            return False
        # 打印信息
        if (self.debug):
            print("R200XD.stop_read : sucessfully done !")
        # 返回结果
        return True

    # 连续读取
    def read_rfids(self, count = 1):
        # 打印信息
        if (self.debug):
            print("R200XD.read_rfids : begin !")
        # 检查参数
        if count <= 0 or count > 65535: count = 65535
        # 拼接命令字
        buffer = struct.pack(">BBBBBBBBBB",
            # 帧头
            0xBB,
            # 帧类型
            0x00,
            # 指令代码
            0x27,
            # 指令长度
            0x00, 0x03,
            # 保留位
            0x22,
            # 次数
            (count >> 8) & 0xFF, count & 0xFF,
            # 校验和
            (0x00 + 0x27 + 0x00 + 0x03 + 0x22 + ((count >> 8) & 0xFF) + (count & 0xFF)) & 0xFF,
            # 帧尾
            0x7E
            )
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x27")
            print("\tPL = 3")
            print("\treserve = 0x22")
            print("\tbytes = 0x%s"%buffer.hex())
        try:            
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug): \
                print("R200XD.read_rfids : port was opened !")
            # 向串口输出
            serialPort.write(buffer)
            # 打印信息
            if (self.debug): \
                print("R200XD.read_rfids : send request !")
            # 等待必要的时间
            time.sleep(0.1)

            # 清理缓冲区
            buffer = None
            # 记录时间
            last_time = time.time()
            # 循环读取
            while count > 0:
                # 检查缓冲区
                if buffer is None or \
                    len(buffer) <= 0 or \
                    buffer.find(b'\x7E') < 0:
                    # 从串口读取
                    input = serialPort.read_all()
                    # 检查结果
                    if input is not None and len(input) > 0:
                        # 重新计时
                        last_time = time.time()
                        # 加入到缓冲区
                        if buffer is None:
                            buffer = input
                        else : buffer = buffer + input
                        '''
                        # 打印信息
                        if (self.debug): \
                            print("\tbytes(received) = 0x%s"%input.hex())
                        '''
                    else:
                        # 等待一段时间，释放CPU
                        time.sleep(0.1)
                        # 检查超时设置（1秒）
                        if time.time() - last_time > 1.1:
                            # 打印信息
                            if (self.debug): \
                                print("\tR200XD.read_rfids : read timeout !")
                            break
                # 检查数据帧
                if buffer is None or len(buffer) <= 0: continue

                # 查找帧开头
                ind = buffer.find(b'\xBB')
                # 检查结果
                if ind < 0:
                    # 丢弃数据
                    buffer = None
                    # 打印信息
                    if (self.debug): \
                        print("R200XD.read_rfids : cannot find header !")
                    continue
                elif ind > 0:
                    # 丢弃前面的数
                    buffer = buffer[ind : ]
                    # 打印信息
                    if (self.debug): \
                        print("R200XD.read_rfids : align buffer to header !")

                # 查找帧结尾
                ind = buffer.find(b'\x7E')
                # 检查结果
                if ind < 0:
                    # 需要继续补充数据
                    # 打印信息
                    '''
                    if (self.debug): \
                        print("R200XD.read_rfids : continue to read !")
                    '''
                    continue
                # 检查结果
                if ind == 0:
                    # 无效的数值
                    # 丢弃前面的数
                    buffer = buffer[1 : ] if len(buffer) > 1 else None
                    # 打印信息
                    if (self.debug): \
                        print("R200XD.read_rfids : invalid end position !")
                    continue
                # 检查结果
                if ind == 1:
                    # 空帧
                    # 丢弃前面的数
                    buffer = buffer[2 : ] if len(buffer) > 2 else None
                    # 打印信息
                    if (self.debug): \
                        print("R200XD.read_rfids : unexpected empty frame !")
                    continue

                # 截获一段数据
                frame = buffer[ : ind + 1]
                # 重新设置buffer
                buffer = buffer[ind + 1 : ]
                # 计数器减一
                if(count > 0 and count < 65535): count = count - 1
                # 打印信息
                if (self.debug): \
                    print("\tframe[%d] = 0x%s"%(count, frame.hex()))

                # 获得类型
                type = frame[1]
                # 检查类型
                if type == 0x01:
                    # 获得命令
                    command = frame[2]
                    # 检查结果
                    if command != 0xFF:
                        # 打印信息
                        if (self.debug):
                            print("R200XD:read_rfids : invalid command(0x%02X) !"% command)
                        continue

                    # 获得长度
                    PL = struct.unpack("!H", frame[3 : 5])[0] & 0xFFFF
                    # 检查长度
                    if PL != 0x0001:
                        if (self.debug):
                            print("R200XD.read_rfids : invalid PL(%d) !"% PL)
                        continue

                    # 获得参数
                    parameter = frame[5] & 0xFF
                    # 检查长度
                    if parameter != 0x15:
                        if (self.debug):
                            print("R200XD.read_rfids : invalid parameter !")
                        continue               

                    # 检查checksum
                    if frame[6] != 0x16:
                        if (self.debug):
                            print("R200XD.read_rfids : invalid checksum !")
                        continue
                # 检查类型
                elif type == 0x02:
                    # 获得命令
                    command = frame[2]
                    # 检查结果
                    if command != 0x22:
                        # 打印信息
                        if (self.debug):
                            print("R200XD:read_rfids : invalid command(0x%02X) !"% command)
                        continue

                    # 获得长度
                    PL = struct.unpack("!H", frame[3 : 5])[0] & 0xFFFF
                    # 检查长度
                    if PL != 0x0012:
                        if (self.debug):
                            print("R200XD.read_rfids : invalid PL(%d) !"% PL)
                        continue

                    checksum = 0
                    # 获得cheksum
                    for i in range(1, len(frame) - 2):
                        checksum = checksum + frame[i]
                    # 检查checksum
                    if frame[len(frame) - 2] != (checksum & 0xFF):
                        if (self.debug):
                            print("R200XD.read_rfids : invalid checksum !")
                        continue                    

                    # 生成RFID
                    rfid = [None, 0, 0, 0]
                    # 设置标识
                    rfid[0] = frame[8 : 20]
                    # 设置天线编号
                    rfid[1] = frame[22]
                    # 设置计数器
                    rfid[2] = 1
                    # 设置信号强度
                    rfid[3] = frame[5]
                    # 调整符号
                    if (rfid[3] & 0x80) != 0: rfid[3] -= 0x100
                    # 打印信息
                    if (self.debug):
                        print("R200XD.read_rfids : rfid(%s) = [%d, %d]"%(rfid[0].hex(), rfid[1], rfid[3]))

                    # 标志位
                    flag = False
                    # 锁定
                    self.__lock.acquire()               
                    # 更新结果集
                    for i in range(0, len(self.__rfids)):
                        # 检查结果
                        # EPC一致，而且天线编号一致
                        if self.__rfids[i][0] == rfid[0] and self.__rfids[i][1] == rfid[1]:
                            # 设置标记位
                            flag = True
                            # 计数器加一
                            self.__rfids[i][2] = self.__rfids[i][2] + 1
                            # 检查信号强度，则设置最大值者
                            if rfid[3] > self.__rfids[i][3]:
                                self.__rfids[i][3] = rfid[3]
                                #print("R200XD.read_rfids : rfid(%s) = [%d, %d]"%(rfid[0].hex(), rfid[1], rfid[3]))
                            break
                    # 检查标志位
                    if not flag:
                        self.__rfids.append(rfid)
                        #print("R200XD.read_rfids : rfid(%s) = [%d, %d]"%(rfid[0].hex(), rfid[1], rfid[3]))
                    # 释放
                    self.__lock.release()
                else:
                    # 打印信息
                    if (self.debug):
                        print("R200XD:read_rfids : invalid type(%d) !"% type)

            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug): \
                print("R200XD.read_rfids : port was closed !")
        except Exception as e:
            print("R200XD.read_rfids :", str(e))
            print("R200XD.read_rfids : unexpected exit !")

# 定义主函数
def main():  

    # 打印所有串口
    #myDevice = R200XD("/dev/ttyUSB0")
    myDevice = R200XD("/dev/ttyAMA0")

    # 停止读取
    myDevice.stop_read()
    # 设置单天线
    myDevice.set_ants()
    # 读取数据
    myDevice.read_rfids(100)
    # 获得结果集
    rfids = myDevice.get_rfids()
    # 检查结果
    if rfids is not None:
        # 打印信息
        print("R200XD.main : read results !")
        # 打印结果
        for i in range(0, len(rfids)):
            print("\tcard(%s)[%d, %d] = %d"%(rfids[i][0].hex(), rfids[i][1], rfids[i][3], rfids[i][2]))

    # 删除设备
    del myDevice

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("R200XD:__main__ :", str(e))
        print("R200XD:__main__ : unexpected exit !")
