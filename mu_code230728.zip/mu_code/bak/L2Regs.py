# -*- coding: utf-8 -*

from Register import *

from SlaveStation import *


'''
激光测距传感器寄存器
'''

class L0007(Register):
    # 定义构造函数
    def __init__(self):
        Register.__init__(self, 0x0007, \
            "开启/关闭", DataType.int16)
        
    # 注释信息
    @property
    def info(self):
        # 检查数值
        if self.get() == 0: return "关闭"
        elif self.get() == 1: return "开启"
        else: return "未定义"

class L000B(Register):
    # 定义构造函数
    def __init__(self):
        Register.__init__(self, 0x000B, \
            "量程", DataType.int32)
        
class L000D(Register):
    # 定义构造函数
    def __init__(self):
        Register.__init__(self, 0x000D, \
            "偏移量", DataType.int16)

class L0010(Register):
    # 定义构造函数
    def __init__(self):
        self.mode("R")
        Register.__init__(self, 0x0010, \
            "手动测量", DataType.int32)
        
class L0017(Register):
    # 定义构造函数
    def __init__(self):
        Register.__init__(self, 0x0017, \
            "从机地址", DataType.int16)

class L0019(Register):
    # 定义构造函数
    def __init__(self):
        Register.__init__(self, 0x0019, \
            "波特率", DataType.int32)
        
class L001B(Register):
    # 定义构造函数
    def __init__(self):
        Register.__init__(self, 0x001B, \
            "采样率", DataType.int16)
        
class L0031(Register):
    # 定义构造函数
    def __init__(self):
        self.mode("W")
        Register.__init__(self, 0x0031, \
            "停止测量", DataType.int16)

class L0034(Register):
    # 定义构造函数
    def __init__(self):
        self.mode("R")
        Register.__init__(self, 0x0034, \
            "快速连续自动测量", DataType.int16)