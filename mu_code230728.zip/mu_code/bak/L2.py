# -*- coding: utf-8 -*

import re
import time
import serial
import traceback

from SerialPort import *

class L2(SerialPort):
       
    # 定义初始化函数
    def __init__(self, name):
        # 调用父函数初始化
        SerialPort.__init__(self, name)
        # 设置串口参数
        # 需要与设备设置保持一致
        self._set_port(115200, serial.EIGHTBITS,
            serial.PARITY_NONE, serial.STOPBITS_ONE)

    # 单次测量
    def get_dist(self, manu = False):
        # 操作串口
        try:
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug):
                print("L2.get_dist : port was opened !")
            # 向串口输出
            if manu:
                serialPort.write("iCM\r\n".encode("utf-8"))
            else:
                serialPort.write("iSM\r\n".encode("utf-8"))
            # 刷新
            serialPort.flushOutput()
            # 打印信息
            if (self.debug):
                print("L2.get_dist : send request !")
            # 从串口读取
            input = serialPort.readlines()
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug):
                print("L2.get_dist : port was closed !")

            # 检查结果
            if input is not None and len(input) > 0:
                # 打印信息
                if (self.debug):
                    print("L2.get_dist : receive response !")
            else:
                # 打印信息
                if (self.debug):
                    print("L2.get_dist : fail to receive response !")
                return -1

            # 循环处理
            for i in range(len(input)):
                # 裁剪
                input[i] = input[i].\
                    decode("utf-8").strip()
                # 打印信息
                if (self.debug): print("\t%s"% input[i])

            # 解析
            groups = re.\
                match("D=(\d+\.?\d*)m", input[0]).groups()
            # 返回结果
            if groups is not None \
                and len(groups) > 0:
                # 返回毫米单位结果
                return int(1000 * float(groups[0]))
            # 解析
            groups = re.match("E=(\d+)", input[0]).groups()
            # 返回结果
            if groups is not None and len(groups) > 0:
                # 获得错误码
                error = int(groups[0])
                # 打印错误信息
                if error == 252:
                    print("L2.get_dist : 温度过高（超过60度）！")
                elif error == 253:
                    print("L2.get_dist : 温度过低（低于-20度）！")
                elif error == 255:
                    print("L2.get_dist : 弱反射或计算失败！")
                elif error == 256:
                    print("L2.get_dist : 强反射！")
                elif error == 258:
                    print("L2.get_dist : 超出量程！")
                elif error == 285:
                    print("L2.get_dist : 光敏器件异常！")
                elif error == 286:
                    print("L2.get_dist : 激光管异常！")
                elif error == 290:
                    print("L2.get_dist : 硬件异常！")
                return - error
            # 打印信息
            if (self.debug):
                print("L2.get_dist : fail to get dist !")
        except Exception as e:
            print("L2.get_dist :", str(e))
            print("L2.get_dist : unexpected exit !")
        # 返回结果
        return -1

    # 开启/关闭激光
    def toggle(self, on):
        # 操作串口
        try:
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug):
                print("L2.toggle : port was opened !")
            # 向串口输出
            if on:
                serialPort.write("iLD:1\r\n".encode("utf-8"))
            else:
                serialPort.write("iLD:0\r\n".encode("utf-8"))
            # 刷新
            serialPort.flushOutput()
            # 打印信息
            if (self.debug):
                print("L2.toggle : send request !")
            # 等待一段时间
            time.sleep(0.1)
            # 从串口读取
            input = serialPort.readlines()
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug):
                print("L2.toggle : port was closed !")

            # 检查结果
            if input is not None and len(input) > 0:
                # 打印信息
                if (self.debug):
                    print("L2.toggle : receive response !")
            else:
                # 打印信息
                if (self.debug):
                    print("L2.toggle : fail to receive response !")
                return False

            # 循环处理
            for i in range(len(input)):
                # 裁剪
                input[i] = input[i].\
                    decode("utf-8").strip()
                # 打印信息
                if (self.debug): print("\t%s"% input[i])

            # 检查结果
            if len(input) == 1 and input[0] == "BUSY":
                # 打印信息
                if (self.debug):
                    print("L2.toggle : device is busy !")
                return False
            if len(input) == 2 and input[1] == "OK":
                if on:
                    if input[0] == "LASER OPEN": return True
                else:
                    if input[0] == "LASER CLOSE": return True
            # 打印信息
            if (self.debug):
                print("L2.toggle : fail to switch laser !")
        except Exception as e:
            print("L2.toggle :", str(e))
            print("L2.toggle : unexpected exit !")
        # 返回结果
        return False

    # 停止测量
    def stop(self):
        # 操作串口
        try:
            # 打开设备
            serialPort = self.open_port()
            # 清空缓冲区
            serialPort.flushInput()
            # 打印信息
            if (self.debug):
                print("L2.stop : port was opened !")
            # 向串口输出
            serialPort.write("iHALT\r\n".encode("utf-8"))
            # 刷新
            serialPort.flushOutput()
            # 打印信息
            if (self.debug):
                print("L2.stop : send request !")
            # 等待一段时间
            time.sleep(0.1)
            # 从串口读取
            input = serialPort.readlines()
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug):
                print("L2.stop : port was closed !")

            # 检查结果
            if input is not None and len(input) > 0:
                # 打印信息
                if (self.debug):
                    print("L2.stop : receive response !")
            else:
                # 打印信息
                if (self.debug):
                    print("L2.stop : fail to receive response !")
                return False

            # 循环处理
            for i in range(len(input)):
                # 裁剪
                input[i] = input[i].\
                    decode("utf-8").strip()
                # 打印信息
                if (self.debug): print("\t%s"% input[i])

            # 检查结果
            if len(input) != 2 or \
                input[0] != "STOP" or input[1] != "OK":
                # 打印信息
                if (self.debug): print("L2.stop : fail to stop read !")
                return False
            # 返回结果
            return True
        except Exception as e:
            print("L2.stop :", str(e))
            print("L2.stop : unexpected exit !")
        # 返回结果
        return False

# 定义主函数
def main():  
    # 创建设备
    myDevice = L2("/dev/ttyUSB0")

    # 停止前面的操作
    myDevice.stop()
    # 开启激光
    myDevice.toggle(True)

    # 连续测量
    for i in range(5):
        # 等待一段时间
        time.sleep(0.1)
        # 测量
        print("L2.main : %dmm"% myDevice.get_dist(True))

    # 关闭激光
    myDevice.toggle(False)

    # 删除设备
    del myDevice

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("L2:__main__ :", str(e))
        print("L2:__main__ : unexpected exit !")
