# -*- coding: utf-8 -*

from threading import Thread

from R200XD import *

class RFIDSensor(Thread):
    # 设备句柄
    __device = None

    # 启动标志
    __start = False
    # 停止标志
    __stopped = False

    # 定义初始化函数
    def __init__(self, port):
        # 初始化线程
        Thread.__init__(self)
        # 生成设备
        self.__device = R200XD(port)
    
    # 是否启动
    def is_start(self):
        # 返回结果
        return self.__start
    
    # 是否停止
    def is_stopped(self):
        # 返回结果
        return self.__stopped

    # 更新数据
    def get_rfids(self, clear = False):
        # 获得数据
        return self.__device.get_rfids(clear)

    # 开始读取
    def start_read(self):
        # 设置启动标志
        self.__start = False
        # 清理停止标志
        self.__stopped = False
        # 停止读取
        if not self.__device.stop_read(True):
            # 打印信息
            print("RFIDSensor.start_read : 无法停止读取！")
            return False
        # 设置天线
        if not self.__device.set_ants():
            # 打印信息
            print("RFIDSensor.start_read : 无法设置天线！")
            return False
        # 启动线程
        self.start()
        # 等待一段时间
        while not self.__start: time.sleep(0.1)
        # 打印信息
        print("RFIDSensor.start_read : 读取线程已经启动 !")
        # 返回结果
        return True

    # 停止读取
    def stop_read(self):
        # 停止读取
        self.__device.stop_read()
        # 等待线程结束
        if self.__start:
            # 等待结束
            self.join()
            # 清理标记位
            self.__start = False
        # 打印信息
        print("RFIDSensor.stop_read : 线程已经停止 !")

    # 运行函数
    def run(self):
        # 设置启动标志
        self.__start = True
        # 清理停止标志
        self.__stopped = False
        # 打印信息
        print("RFIDSensor.run : 开始连续读取 !")
        # 执行函数
        try:
            # 开始读取数据
            self.__device.read_rfids(-1)
        # 处理异常
        except Exception as e:
            traceback.print_exc()
            print("RFIDSensor.run :", str(e))
            print("RFIDSensor.run : unexpected exit !")
        # 设置停止标志
        self.__stopped = True            
        # 打印信息
        print("RFIDSensor.run : 停止连续读取 !")

# 定义主函数
def main():

    # 创建传感器
    mySensor = RFIDSensor("/dev/ttyAMA0")

    # 启动线程
    mySensor.start_read()
    # 等待一段时间
    for i in range(0, 100):
        # 计数器加一
        i = i + 1
        # 等待一段时间
        time.sleep(0.1)
        # 检查标志位
        if mySensor.is_stopped(): break
    # 停止线程
    mySensor.stop_read()
    # 结果集
    rfids = mySensor.get_rfids()
    # 打印信息
    for i in range(0, len(rfids)):
        print("RFIDSensor.main : rfid(%s)[%d, %d] = %d"%(rfids[i][0].hex(), rfids[i][1], rfids[i][3], rfids[i][2]))

    # 删除传感器
    del mySensor

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    # 处理异常
    except Exception as e:
        traceback.print_exc()
        print("RFIDSensor.__main__ :", str(e))
        print("RFIDSensor.__main__ : unexpected exit !")