# -*- coding: utf-8 -*

from threading import *

from VehicleConfig import *

from EnergySensor import *
from WeightSensor import *
from MotorController import *

class Vehicle:
    # 配置文件
    __config = None
    # 同步锁
    __lock = Lock()

    # 电能表设备
    __energySensor = None
    # 称重传感器
    __weightSensor = None
    # 后桥电机控制器
    __motorController = None

    # 定义初始化函数
    def __init__(self):
        # 生成缺省配置
        self.__config = VehicleConfig()
   
    # 中断指令
    def stop(self):
        self.__motorController.__interrupt = True
        # 返回指令执行结果
        return self.__motorController.stop_motor(0)

    # 运动到某个相对位置
    # 基于PWM
    def move(self, pos, pwm = 0):
        # 将位置从毫米换算成脉冲数
        pulse = int(pos * self.pulse_count \
            / (self.rail_length - self.wheel_range))
        # 打印信息
        print("Vehicle.move : 脉冲数(%d)！"% pulse)
        # 执行移动指令
        return self.__motorController.move(pulse, pwm) * \
            (self.rail_length - self.wheel_range) / self.pulse_count

    # 运动到某个相对位置
    # 基于换向频率
    def moveto(self, pos):
        # 将位置从毫米换算成脉冲数
        pulse = int(pos * self.pulse_count \
            / (self.rail_length - self.wheel_range))
        # 打印信息
        print("Vehicle.moveto : 脉冲数(%d)！"% pulse)
        # 执行移动指令
        return self.__motorController.moveto(pulse) * \
            (self.rail_length - self.wheel_range) / self.pulse_count

    # 前进直至堵转
    # 基于配置文件的PWM设置
    def move_forward(self, pwm = 0):
        return self.__motorController.move_forward(pwm)
    
    # 后退直至堵转
    # 基于配置文件的PWM设置
    def move_backward(self, pwm = 0):
        return self.__motorController.move_backward(pwm)
    
    # 测量最大脉冲
    # 基于配置文件的PWM设置
    def measure_pulse(self):
        # 退回起始位
        if self.move_backward() < 0:
            print("Vehicle.measure_pulse : 无法退回原点！")
            return False
        # 执行循环业务（3次）
        i = 3
        pulse = 0
        while i > 0:
            # 计数器减一
            i = i - 1
            # 向前进
            value = self.move_forward()
            # 检查结果
            if value < 0:
                print("Vehicle.measure_pulse : 无法前进！")
                return False
            pulse += value

            # 向后退
            value = self.move_backward()
            # 检查结果
            if value < 0:
                print("Vehicle.measure_pulse : 无法后退！")
                return False
            pulse += value
        # 返回平均结果数值
        self.pulse_count = int(pulse / 20.0)
        # 更新配置属性
        self.__config.set_pulse_count(self.pulse_count)
        # 保存配置文件
        self.__config.save_conf()
        # 打印信息
        print("Vehicle.measure_pulse : 脉冲数(%d)"% self.pulse_count)
        # 返回结果
        return True
    
    # 移动至自动充电
    # 基于配置文件的PWM设置    
    def moveto_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power > 0:
            print("Vehicle.moveto_charger : 已经在充电！")
            return True

        # 退回设备
        position = self.move_backward()
        # 检查结果
        if position < 0:
            print("Vehicle.moveto_charger : 无法移动小车！")
            return False
        
        print("Vehicle.moveto_charger : 等待延迟开关！")
        # 等待一段时间
        time.sleep(5)

        print("Vehicle.moveto_charger : 等待电能表启动！")
        # 等待一段时间
        time.sleep(5)

        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vehicle.moveto_charger : 充电装置异常！")
            return False
        # 返回结果
        return True

    # 离开自动充电装置
    # 基于配置文件的PWM设置    
    def leave_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vehicle.leave_charger : 已经离开！")
            return True
        # 循环处理
        while power > 0:
            # 移动一小段距离（大约1秒）
            if not self.__motorController.move_forward(self.leave_count):
                print("Vehicle.leave_charger : 无法前进！")
                return False
            # 再次读取电表数值
            power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vehicle.leave_charger : 已经离开！")
            return True
        return False

    # 创建设备
    def init_Vehicle(self):
        # 加载配置
        self.__config.load_conf()
        
        # 创建设备
        self.__energySensor = EnergySensor(\
            self.__config.get_port(2, "/dev/ttyUSB0"),\
                self.__config.get_address(2, 0x01))
        
        # 创建设备
        self.__weightSensor = WeightSensor(\
            self.__config.get_port(3, "/dev/ttyUSB0"),\
                self.__config.get_address(3, 0x03))
        
        # 创建设备
        self.__motorController = MotorController(\
            self.__config.get_port(4, "/dev/ttyUSB0"),\
                self.__config.get_address(4, 0x05))
        # 设置学习标志
        self.__motorController.study = \
            self.__config.get_study(self.__motorController.study)
        # 设置额定功率
        self.__motorController.power = \
            self.__config.get_power(self.__motorController.power)
        # 设置前进方向
        self.__motorController.forward = \
            self.__config.get_forward(self.__motorController.forward)
        # 设置运行速度
        self.__motorController.duty_ratio = \
            self.__config.get_duty_ratio(self.__motorController.duty_ratio)
        # 设置启动时长
        self.__motorController.start_time = \
            self.__config.get_start_time(self.__motorController.start_time)
        # 设置换向频率
        self.__motorController.reverse_freq = \
            self.__config.get_reverse_freq(self.__motorController.reverse_freq)

        # 检查学习标志
        if not self.__motorController.study:
            # 初始化设备
            if not self.__motorController.init_device():
                print("Vehicle.init_device : 无法初始化设备！")
                return False
            # 设置标记位
            self.__config.set_option(4, "study", "1")

        # 停止电机
        if not self.__motorController.stop_motor():
            # 打印信息
            print("Vehicle.init_device : 无法停止后桥电机！")
            return False
        # 返回结果
        return True

# 定义主函数
def main():

    # 创建小车
    myVehicle = Vehicle()

    # 创建设备
    if myVehicle.init_Vehicle():

        # 回到原点
        if not myVehicle.move_backward():
            print("Vehicle.main : 无法回到原点！")

    else:
        print("Vehicle.main : 无法初始化设备！")
            
    # 删除小车
    del myVehicle

    # 等待键盘消息
    #input("Vehicle.main : 按下Enter键结束当前程序！\r\n")

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("Vehicle:__main__ :", str(e))
        print("Vehicle:__main__ : unexpected exit !")