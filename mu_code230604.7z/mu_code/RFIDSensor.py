# -*- coding: utf-8 -*

import sys
import time

from R200XD import *
from RFIDResults import *

class RFIDSensor:
    # 设备句柄
    __device = None
    # 结果集
    __results = RFIDResults()

    # 天线间距
    ant_dist = 260
    # 天线高度
    ant_height = 130
    # RFID标签间距
    rfid_dist = 530

    # 定义初始化函数
    def __init__(self, port):
        # 生成设备
        self.__device = R200XD(port)
        
# 定义主函数
def main():

    # 创建传感器
    mySensor = RFIDSensor("/dev/ttyUSB0")

    # 删除传感器
    del mySensor

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("RFIDSensor.__main__ :", str(e))
        print("RFIDSensor.__main__ : unexpected exit !")