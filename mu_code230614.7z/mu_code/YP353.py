# -*- coding: utf-8 -*

import traceback

from Register import *
from YP353Regs import *

from SlaveStation import *

class YP353(SlaveStation):
    # 控制寄存器列表
    __regs = \
        { \
            0x0001 : Y0001(),
        }
       
    # 定义初始化函数
    def __init__(self, name, address = 0x01):
        # 调用父函数初始化
        SlaveStation.__init__(self, name, address)
        # 设置寄存器列表
        SlaveStation.__setregs__(self, self.__regs)

# 定义主函数
def main():  
    # 创建设备
    myDevice = YP353("/dev/ttyUSB1", 0x03)

    # 读取数据
    myDevice.read_items()
    # 打印数据
    myDevice.print_items()

    # 删除设备
    del myDevice

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("YP353:__main__ :", str(e))
        print("YP353:__main__ : unexpected exit !")
