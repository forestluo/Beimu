# -*- coding: utf-8 -*

import re
import socket

from threading import *

from VechileConfig import *

from RFIDSensor import *
from EnergySensor import *
from WeightSensor import *
from MotorController import *

class Vechile:
    # 当前位置
    __pos = 0
    # RFID标签
    __rfids = []
    # 配置文件
    __config = None
    # 同步锁
    __lock = Lock()

    # 离开充电桩的距离（0.1s）
    leave_count = 5
    # 脉冲数
    pulse_count = 1113
    # 车轮外缘距离（mm） 
    wheel_range = 750
    # 轨道长度（mm）
    rail_length = 5430

    # 电能表设备
    __energySensor = None
    # 称重传感器
    __weightSensor = None
    # 后桥电机控制器
    __motorController = None

    # 定义初始化函数
    def __init__(self):
        # 生成缺省配置
        self.__config = VechileConfig()

    # 获得当前位置
    def get_pos(self):
        # 锁定
        self.__lock.acquire()
        # 获得数值
        value = self.__pos
        # 解锁
        self.__lock.release()
        # 返回结果
        return value
    
    # 运动到某个相对位置
    # 基于PWM
    def move(self, pos):
        # 将位置从毫米换算成脉冲数
        pulse = int(pos * self.pulse_count \
            / (self.rail_length - self.wheel_range))
        # 打印信息
        print("Vechile.move : 脉冲数(%d)！"% pulse)
        # 执行移动指令
        return self.__motorController.move(pulse) * \
            (self.rail_length - self.wheel_range) / self.pulse_count

    # 运动到某个相对位置
    # 基于换向频率
    def moveto(self, pos):
        # 将位置从毫米换算成脉冲数
        pulse = int(pos * self.pulse_count \
            / (self.rail_length - self.wheel_range))
        # 打印信息
        print("Vechile.moveto : 脉冲数(%d)！"% pulse)
        # 执行移动指令
        return self.__motorController.moveto(pulse) * \
            (self.rail_length - self.wheel_range) / self.pulse_count

    # 前进直至堵转
    def move_forward(self):
        return self.__motorController.move_forward()
    
    # 后退直至堵转
    def move_backward(self):
        return self.__motorController.move_backward()
    
    # 测量最大脉冲
    def measure_pulse(self):
        # 退回起始位
        if self.move_backward() < 0:
            print("Vechile.measure_pulse : 无法退回原点！")
            return False
        # 执行循环业务（10次）
        i = 10
        pulse = 0
        while i > 0:
            # 计数器减一
            i = i - 1
            # 向前进
            value = self.move_forward()
            # 检查结果
            if value < 0:
                print("Vechile.measure_pulse : 无法前进！")
                return False
            pulse += value

            # 向后退
            value = self.move_backward()
            # 检查结果
            if value < 0:
                print("Vechile.measure_pulse : 无法后退！")
                return False
            pulse += value
        # 返回平均结果数值
        self.pulse_count = int(pulse / 20.0)
        # 更新配置属性
        self.__config.set_pulse_count(self.pulse_count)
        # 保存配置文件
        self.__config.save_conf()
        # 打印信息
        print("Vechile.measure_pulse : 脉冲数(%d)"% self.pulse_count)
        # 返回结果
        return True
    
    # 移动至自动充电
    def moveto_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power > 0:
            print("Vechile.moveto_charger : 已经在充电！")
            return True

        # 退回设备
        position = self.move_backward()
        # 检查结果
        if position < 0:
            print("Vechile.moveto_charger : 无法移动小车！")
            return False
        
        print("Vechile.moveto_charger : 等待延迟开关！")
        # 等待一段时间
        time.sleep(5)

        print("Vechile.moveto_charger : 等待电能表启动！")
        # 等待一段时间
        time.sleep(5)

        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vechile.moveto_charger : 充电装置异常！")
            return False
        # 返回结果
        return True

    # 离开自动充电装置
    def leave_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vechile.leave_charger : 已经离开！")
            return True
        # 循环处理
        while power > 0:
            # 移动一小段距离（大约1秒）
            if not self.__motorController.move_forward(self.leave_count):
                print("Vechile.leave_charger : 无法前进！")
                return False
            # 再次读取电表数值
            power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vechile.leave_charger : 已经离开！")
            return True
        return False

    # 创建设备
    def init_vechile(self):
        # 加载配置
        self.__config.load_conf()

        # 设置离开距离
        self.leave_count = \
            self.__config.get_leave_count(self.leave_count)
        # 设置脉冲数
        self.pulse_count = \
            self.__config.get_pulse_count(self.pulse_count)
        # 设置车轮外缘距离
        self.wheel_range = \
            self.__config.get_wheel_range(self.wheel_range)
        # 设置轨道长度
        self.rail_length = \
            self.__config.get_rail_length(self.rail_length)
        
        # 获得RFID的数量
        count = self.__config.get_rfid_count(11)
        # 循环处理
        for i in range(0, count):
            # 注册RFID
            self.__rfids.append(binascii.unhexlify(self.__config.get_rfid_epc(i, "00112233445566778899aabb")))

        # 创建设备
        self.__energySensor = EnergySensor(\
            self.__config.get_port(2, "/dev/ttyUSB0"),\
                self.__config.get_address(2, 0x01))
        
        # 创建设备
        self.__weightSensor = WeightSensor(\
            self.__config.get_port(3, "/dev/ttyUSB0"),\
                self.__config.get_address(3, 0x03))
        
        # 创建设备
        self.__motorController = MotorController(\
            self.__config.get_port(4, "/dev/ttyUSB0"),\
                self.__config.get_address(4, 0x05))
        # 设置学习标志
        self.__motorController.study = \
            self.__config.get_study(self.__motorController.study)
        # 设置额定功率
        self.__motorController.power = \
            self.__config.get_power(self.__motorController.power)
        # 设置前进方向
        self.__motorController.forward = \
            self.__config.get_forward(self.__motorController.forward)
        # 设置运行速度
        self.__motorController.duty_ratio = \
            self.__config.get_duty_ratio(self.__motorController.duty_ratio)
        # 设置启动时长
        self.__motorController.start_time = \
            self.__config.get_start_time(self.__motorController.start_time)
        # 设置换向频率
        self.__motorController.reverse_freq = \
            self.__config.get_reverse_freq(self.__motorController.reverse_freq)
        
        # 创建线程
        thread = Thread(target = self.update_rfids,\
            args = (self.__config.get_port(1,"/dev/ttyAMA0"), ))
        # 设置属性
        thread.daemon = True
        # 启动线程
        thread.start()

        # 检查学习标志
        if not self.__motorController.study:
            # 初始化设备
            if not self.__motorController.init_device():
                print("Vechile.init_device : 无法初始化设备！")
                return False
            # 设置标记位
            self.__config.set_option(4, "study", "1")

        # 停止电机
        if not self.__motorController.stop_motor():
            # 打印信息
            print("Vechile.init_device : 无法停止后桥电机！")
            return False
        # 返回结果
        return True

    # 运行函数
    def update_rfids(self, port):
        # 获得天线距离
        ant_dist = \
            self.__config.get_ant_dist(250)
        # 获得标签距离
        rfid_dist = \
            self.__config.get_rfid_dist(530)
        # 打印信息
        print("Vechile.update_rfids : 开启扫描守护进程 !")
        # 执行函数
        try:
            # 检查标记位
            while True:
                # 生成传感器
                sensor = RFIDSensor(port)
                # 打印信息
                print("Vechile.update_rfids : 尝试启动RFID传感器 !")
                # 启动读取线程
                if sensor.start_read():
                    # 打印信息
                    print("Vechile.update_rfids : RFID传感器已经启动 !")
                    # 等待一段时间
                    while True:
                        # 等待一段时间
                        time.sleep(0.25)
                        # 检查标志位
                        if sensor.is_stopped(): break

                        # 统计数据
                        pos = [0, 0, 0, 0]
                        count = [0, 0, 0, 0]
                        # 获得结果集                        
                        rfids = sensor.get_rfids(True)
                        # 检查结果
                        if len(rfids) <= 0: continue

                        # 检查结果
                        for i in range(0, len(rfids)):
                            # 获得epc
                            epc = rfids[i][0]
                            # 获得索引值
                            ind = self.__rfids.index(epc)
                            # 检查结果
                            if ind < 0: continue
                            # 获得ant
                            ant = rfids[i][1]
                            # 获得cnt
                            cnt = rfids[i][2]
                            # 统计计数器
                            count[ant - 1] += cnt
                            # 统计位置加权和
                            pos[ant - 1] += cnt * ind * rfid_dist

                        # 加权平均数值
                        dist = 0
                        avg_count = 0
                        # 处理最后结果
                        for i in range(0, 4):
                            # 检查统计数据
                            if count[i] > 0:
                                # 计数器加一
                                avg_count += 1
                                # 求加权平均距离
                                pos[i] = pos[i] / count[i] + (i - 1.5) * ant_dist
                                # 统计距离
                                dist += pos[i]
                        # 检查结果
                        if avg_count <= 0:
                            # 打印最终结果
                            print("Vechile.update_rfids : fail to locate !")
                            return -1
                        # 计算结果
                        dist /= avg_count

                        # 更新数值
                        # 锁定
                        self.__lock.acquire()
                        # 设置数值
                        self.__pos = dist
                        # 解锁
                        self.__lock.release()
                else:
                    # 打印信息
                    print("Vechile.update_rfids : 无法启动RFID传感器 !")
                # 等待一段时间
                time.sleep(1)
                # 停止读取线程
                sensor.stop_read()
                # 打印信息
                print("Vechile.update_rfids : 重新启动RFID传感器 !")
        # 处理异常
        except Exception as e:
            traceback.print_exc()
            print("Vechile.update_rfids :", str(e))
            print("Vechile.update_rfids : unexpected exit !")
        # 打印信息
        print("Vechile.update_rfids : 扫描守护进程已经停止 !")

# 定义主函数
def main():

    # 创建小车
    myVechile = Vechile()

    # 创建设备
    if myVechile.init_vechile():

        # 回到原点
        if not myVechile.move_backward():
            print("Vechile.main : 无法回到原点！")

        # 执行循环业务
        i = 1
        while i >= 0:
            # 计数器减一
            i = i - 1

            # 获得当前位置
            print("Vechile.main : 当前位置(%dmm)"% myVechile.get_pos())

            # 向前进
            fp = myVechile.move(10)
            print("Vechile.main : 前进计数(%d)"% fp)

            # 等待一段时间
            time.sleep(5)
    else:
        print("Vechile.main : 无法初始化设备！")
            
    # 删除小车
    del myVechile

    # 等待键盘消息
    #input("Vechile.main : 按下Enter键结束当前程序！\r\n")

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("Vechile:__main__ :", str(e))
        print("Vechile:__main__ : unexpected exit !")