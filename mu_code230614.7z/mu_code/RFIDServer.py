# -*- coding: utf-8 -*

import socket
import traceback

from threading import Thread

from RFIDSensor import *

class RFIDServer:
    # 端口
    __port = None
    # 套接字
    __socket = None
    # 传感器
    __sensor = None

    # 定义初始化函数
    def __init__(self, port):
        # 设置端口
        self.__port = port

    # 运行函数
    def scan_rfids(self):
        # 打印信息
        print("RFIDServer.scan_rfids : 开启扫描守护进程 !")
        # 执行函数
        try:
            # 检查标记位
            while True:
                # 生成传感器
                self.__sensor = RFIDSensor(self.__port)
                # 打印信息
                print("RFIDServer.scan_rfids : 尝试启动RFID传感器 !")
                # 启动读取线程
                if self.__sensor.start_read():
                    # 打印信息
                    print("RFIDServer.scan_rfids : RFID传感器已经启动 !")
                    # 等待一段时间
                    while True:
                        # 等待一段时间
                        time.sleep(0.1)
                        # 检查标志位
                        if self.__sensor.is_stopped(): break
                else:
                    # 打印信息
                    print("RFIDServer.scan_rfids : 无法启动RFID传感器 !")
                # 等待一段时间
                time.sleep(1)
                # 停止读取线程
                self.__sensor.stop_read()
                # 打印信息
                print("RFIDServer.scan_rfids : 重新启动RFID传感器 !")
        # 处理异常
        except Exception as e:
            traceback.print_exc()
            print("RFIDServer.scan_rfids :", str(e))
            print("RFIDServer.scan_rfids : unexpected exit !")
        # 打印信息
        print("RFIDServer.scan_rfids : 扫描守护进程已经停止 !")

    # 启动服务端
    def start_server(self, port):        
        # 启动服务器
        try:
            # 打印提示
            print("RFIDServer.start_server : 创建守护线程！")
            # 创建守护线程
            thread = Thread(target = self.scan_rfids)
            # 设置属性
            thread.daemon = True
            # 启动守护线程
            thread.start()
            # 打印提示
            print("RFIDServer.start_server : 守护线程已启动！")

            # 打印提示
            print("RFIDServer.start_server : 启动服务端！")
            # 初始化套接字
            self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # 设置选项
            self.__socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
            # 绑定本机端口
            self.__socket.bind(('127.0.0.1', port))
            # 侦听
            self.__socket.listen()
            # 创建守护线程
            thread = Thread(target = self.accept_client)
            # 设置属性
            thread.daemon = True
            # 启动守护线程
            thread.start()
            # 打印信息
            print("RFIDServer.start_server : 服务端已经启动！")
            # 返回结果
            return True
        except Exception as e:
            traceback.print_exc()
            print("RFIDServer.start_server :", str(e))
            print("RFIDServer.start_server : unexpected exit !")
        # 返回结果
        return False

    # 接受客户端
    def accept_client(self):
        # 循环处理
        while True:
            try:
                # 接受客户端
                client, client_ip = self.__socket.accept()
                # 设置连接的超时期
                client.settimeout(10)
                # 打印信息
                print("RFIDServer.accept_client : client%s accepted !"% str(client_ip))
                # 生成线程
                thread = Thread(target = self.message_handle, args = (client, ))
                # 设置属性
                thread.daemon = True
                # 启动线程
                thread.start()
            # 处理异常
            except Exception as e:
                traceback.print_exc()
                print("RFIDServer.accept_client :", str(e))
                print("RFIDServer.accept_client : unexpected exit !")

    # 处理客户端信息
    def message_handle(self, client):
        try:
            # 组织文件
            makefile = client.makefile(mode = "rw", encoding = 'utf-8')
            # 循环处理
            while True:
                # 逐行读取
                input = makefile.readline()
                # 检查结果
                if input is None or len(input) <= 0: break
                # 剪裁空格
                input = input.strip()
                # 检查结果
                # 空操作
                if input == "noop": continue
                # 退出当前连接
                if input == "exit" or input == "quit" : break
                
                # 清理数据
                if input == "clear":
                    self.__sensor.get_rfids(True)
                # 获取数据
                elif input == "get":
                    # 清理数据
                    if self.__sensor is not None:
                        # 获得结果集                        
                        rfids = self.__sensor.get_rfids(True)
                        # 打印信息
                        for i in range(0, len(rfids)):
                            # 格式化输出
                            makefile.writelines("rfid(%s)[%d, %d] = %d\n"%(rfids[i][0].hex(), rfids[i][1], rfids[i][3], rfids[i][2]))
                        # 发送结束符号
                        makefile.writelines("end\n")
                        # 强制输出
                        makefile.flush()
                else:
                    # 打印信息
                    print("RFIDServer.message_handle : %s "% input)
        except Exception as e:
            traceback.print_exc()
            print("RFIDServer.message_handle :", str(e))
            print("RFIDServer.message_handle : unexpected exit !")
        
        # 关闭通道
        client.shutdown(socket.SHUT_WR)
        print("RFIDServer.message_handle : io closed !")
        # 关闭客户端
        client.close()
        print("RFIDServer.message_handle : socket closed !")        

# 定义主函数
def main():
    
    # 生成服务端
    myServer = RFIDServer("/dev/ttyAMA0")
    # 启动服务短
    if not myServer.start_server(9527):
        print("RFIDServer.main : 无法启动服务端！")
    # 等待键盘消息
    input("RFIDServer.main : 按下Enter键结束当前程序！\r\n")
    
if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("RFIDScanner.__main__ :", str(e))
        print("RFIDScanner.__main__ : unexpected exit !")