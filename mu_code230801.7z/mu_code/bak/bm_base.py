##########################import的模块###########################################
#import mysql.connector          as mc # mysql数据库连接模块
import tkinter                  as tk # 图形界面模块
import tkinter.messagebox       as bmmsgbox
import configparser             as configparser
##########################import的模块###########################################
#########################窗体父类##########################
class bmwindow(object):# bmWindow类（避免重复打开窗口）
    def __init__(self):# 类初始化方法
        self.topwindow=None
        self.topwindow_flag = None
        self.ruid=""
        self.runame=""
        self.btpre = ""# 前缀（        sp，     se,     sr，     zc，   de， ro，  rt）
        self.bttype_name = ""# 类型（档案类别，事件类别，收入类别，支出类别，部门，角色，权限）
        self.bmdb = bmdb()  # 实例化bmdb类
    def destroywindow(self):# 关闭窗口
        self.topwindow_flag = None
        self.topwindow.destroy()
    def getwindow(self,rootwindow):# get窗口
        if self.topwindow_flag == None:
            self.topwindow = tk.Toplevel(rootwindow)
        self.topwindow.attributes('-topmost', True)
        self.topwindow.resizable(False,False)
        self.topwindow_flag = True
        self.topwindow.protocol('WM_DELETE_WINDOW',self.destroywindow)
    def getloginwindow(self,rootwindow,windowtitle):# 调用登录窗口    
        rootwindow.title(windowtitle)
        rootwindow.geometry('350x180+600+300')
        rootwindow.resizable(False,False)
        frame_login = tk.Frame(rootwindow)
        frame_login.place(x=0, y=0, width=400, height=150)
        label_username=tk.Label(frame_login,text='登录ID', anchor='e')
        label_username.place(x=20, y=20, width=50, height=30)
        entry_username=tk.Entry(frame_login,)
        entry_username.place(x=90, y=20, width=220, height=30)
        label_password=tk.Label(frame_login,text='密码', anchor='e')
        label_password.place(x=20, y=70, width=50, height=30)
        entry_password=tk.Entry(frame_login,show='*')
        entry_password.place(x=90, y=70, width=220, height=30)
        entry_username.insert(tk.END,"yyh")
        entry_password.insert(tk.END,"yyh")
        def submit():# 验证用户     
            rulogid=entry_username.get()
            rupwd=entry_password.get()
            # sql='select ruid,runame from rt_user where rulogid=\''+rulogid+'\' and rupwd=\''+rupwd+'\' and rulogflag=\'正常\'' 
            # info, result = self.bmdb.getresult(sql)
            # if info != 'OK':
            #     bmmsgbox.showerror("错误信息", info, parent=rootwindow)
            #     return()
            # if len(result)<=0:
            #     bmmsgbox.showerror("错误信息","用户名或者密码错误，请重新输入。", parent=rootwindow)
            #     return()
            # else:
            #     self.ruid=result[0][0]
            #     self.runame=result[0][1]

            self.ruid="yyh"
            self.runame="sdfsdfsdf"
            frame_login.destroy()#登录成功，销毁登录窗口
        button_submit=tk.Button(frame_login,text='登录',command=submit)
        button_submit.place(x=90, y=120, width=100, height=30)
        button_exit=tk.Button(frame_login,text='退出',command=rootwindow.destroy)
        button_exit.place(x=210, y=120, width=100, height=30)
        return(frame_login)  # 这里一定要return啊
    def reordertree(self,tree,result,pid,pitem):  # 递归调用刷新tree
        if pitem == None:
            for i in result:
                if str(i[1]) ==pid:
                    pitem = tree.insert("", 'end', str(i[0]), text=str(i[2]),open=True)
                    self.reordertree(tree,result,str(i[0]), pitem)
        else:
            for i in result:
                if str(i[1]) == pid:
                    pitem1 = tree.insert(pitem, 'end', str(i[0]), text=str(i[2]),open=True)
                    self.reordertree(tree,result, str(i[0]), pitem1)
    def refreshtree(self,tree,result):  # 刷新tree的方法
        for i in tree.get_children():
            tree.delete(i)
        self.reordertree(tree,result, "",None)
#########################窗体父类##########################
#########################北牧公共函数类##########################
class bmpublic(object):# bmpublic类（北牧公共函数）
    pass
#########################北牧公共函数类##########################
##########bm数据库类（提供数据库连接，执行sql，返回查询结果）########################
class bmdb():
    def __init__(self):
        # 类属性初始化赋值为空
        self.host=""
        self.port=""
        self.charset=""
        self.database=""
        self.user=""
        self.password=""
        # 读取配置文件信息，并把参数赋值给对应的类属性
        try:
            with open('bm.conf','r') as f:
                for i in f.readlines():
                    i=i.strip()
                    if i=="":# 判断是否为空
                        continue
                    if i[0]=='#':# 判断是否是注释行
                        continue
                    if i.find('=')<0:# 判断是否含有"="
                        continue
                    name,value=i.split('=')# 拆分"="两边的字符串
                    name=name.strip()
                    value=value.strip()
                    if value=="":# 判断是否为空
                        continue
                    if name=="":# 判断是否为空
                        continue
                    if value[-1]=='\n':# 判断最后一位是否是换行符
                        value=value[:-1]
                    #给类属性赋值    
                    if name=='host':
                        self.host=value
                    elif name=='port':
                        self.port=value
                    elif name=='charset':
                        self.charset=value
                    elif name=='database':
                        self.database=value
                    elif name=='user':
                        self.user=value
                    elif name=='password':
                        self.password=value
        except Exception as e:
            return(None)# 返回空值
    def conndb(self):# 连接数据库方法
        try:
            # # 判断数据库连接参数
            # if self.host=="":
            #     return("数据库连接参数错误:host为空！","")
            # if self.port=="":
            #     return("数据库连接参数错误:port为空！","")
            # if self.charset=="":
            #     return("数据库连接参数错误:charset为空！","")
            # if self.database=="":
            #     return("数据库连接参数错误:database为空！","")
            # if self.user=="":
            #     return("数据库连接参数错误:user为空！","")
            # if self.password=="":
            #     return("数据库连接参数错误:password为空！","")
            # db=mc.connect(host=self.host,port=self.port,\
            #     database=self.database,charset=self.charset,\
            #         user=self.user,password=self.password)# 连接数据库
            # return('OK',db)# 返回结果
            return("OK")
        except Exception as e:
            return("数据库连接错误:"+str(e),"")# 返回错误信息
    def execsql(self,sql):# 执行SQL方法
        # 连接数据库
        info,db=self.conndb()
        if info!='OK':
            return(info)
        try:
            # 执行SQL语句
            cursor=db.cursor()
            sql=str(sql).strip()
            sql=sql.split('#*#*#*#*#*')# ‘#*#*#*#*#*’是关键字，用于分隔多个SQL
            for i in sql:
                i=i.strip()
                cursor.execute(i)
            db.commit()# 事物提交
            db.close# 关闭数据库连接
            return('OK')# 返回结果
        except Exception as e:
            db.rollback()# 事物回滚
            db.close()# 关闭数据库连接
            return("执行SQL错误："+str(e))# 返回错误信息
    def getresult(self,sql):# 返回结果集方法
        # 连接数据库
        info,db=self.conndb()
        if info!='OK':
            return(info,"")        
        try:
            # 执行SQL语句
            cursor=db.cursor()
            cursor.execute(sql)
            result=cursor.fetchall()
            cursor.close()# 关闭游标
            db.close()# 关闭数据库连接
            return('OK',result)# 返回结果
        except Exception as e:
            cursor.close()# 关闭游标
            db.close()# 关闭数据库连接
            return("返回结果集错误："+str(e),"")# 返回错误信息
    def getfieldmaxid(self,tablename,fieldname,preid,fieldlength):  # 返回给定表字段的最大值
        sql='select max(' + fieldname + ') from ' + tablename + ' where ' \
        + fieldname + ' like \'' + preid + '%\''
        info,result=self.getresult(sql)
        if info!="OK":
            return(info,"")
        preid_length=len(preid)
        maxid=str(result[0][0])
        returnid=preid
        if maxid=='None':
            for i in range(fieldlength-preid_length-1):
                returnid=returnid+'0'
            returnid=returnid+'1'
        else:
            intid=int(maxid[preid_length:fieldlength])
            intid=intid+1
            for i in range(fieldlength-preid_length-len(str(intid))):
                returnid=returnid+'0'
            returnid=returnid+str(intid)
        return("OK",returnid)
##########bm数据库类（提供数据库连接，执行sql，返回查询结果）########################
