##########################import的模块##########################
##########################公共的模块#######################
import tkinter as tk
import ttkbootstrap as tbs
import PIL as pil
import time as time
import tkinter.messagebox as bmmsgbox
from Vehicle import *
##########################公共的模块#######################
##########################北牧的模块#######################
import bm_base as bm_base
##########################北牧的模块#######################
##########################import的模块##########################
##########################初始化窗体###########################################
bmvechile=Vehicle()
# 创建设备
bmvechile.init_Vehicle()
    
bmwindow=bm_base.bmwindow()
# style = tbs.Style()
# style = tbs.Style(theme='solar')#superhero,solar
# rootwindow = style.master
rootwindow=tk.Tk(screenName=":0")
# 登录窗口
#loginwindow = bmwindow.getloginwindow(rootwindow,"北牧养殖场管理系统V1.0--用户登录")
#rootwindow.wait_window(window=loginwindow)  # 等待直到login销毁，不销毁后面的语句就不执行
# 登录成功后显示主窗口
rootwindow.title('北牧养殖场管理系统V1.0---------当前登录用户：'+bmwindow.runame+'  '+\
                    time.strftime("%Y-%m-%d") + ' '+time.strftime("%H:%M:%S"))
rootwindow.geometry('800x600+0+0')
rootwindow.resizable(True,True)
# 背景图
# canvas = tk.Canvas(rootwindow, width=800, height=600, bd=0, highlightthickness=0)
# imgpath = 'bbb.jpg'
# img = pil.Image.open(imgpath)
# img = img.resize((800, 600))
# photo = pil.ImageTk.PhotoImage(img, width=800, height=600)
# canvas.create_image(1, 1, anchor='nw', image=photo)
# canvas.place(x=0, y=0, width=800, height=600)
##########################初始化窗体###########################################
def moveto():#
    # 创建线程
    thread = Thread(target = bmvechile.moveto(2000))
    # 启动线程
    thread.start()
def moveforward():#
    # 创建线程
    #bmvechile.move_forward
    thread = Thread(target = bmvechile.move_forward)
    # 启动线程
    thread.start()

def movebackward():#
    # 创建线程
    thread = Thread(target = bmvechile.move_backward)
    # 启动线程
    thread.start()

def stop():#
    thread = Thread(target = bmvechile.stop)
    # 启动线程
    thread.start()
    #bmvechile.stop()
##########self.frame_edit.place(x=270, y=340, width=1120, height=150)###########
# 第一行控件
frame_edit = tk.Frame(rootwindow)
frame_edit.place(x=0, y=0, width=800, height=600)
# 按钮
button_moveforward = tk.Button(frame_edit, text='zhengzhuan', command=moveforward)
button_moveforward.place(x=100, y=20, width=200, height=100)
button_movebackward = tk.Button(frame_edit, text='fanzhuan', command=movebackward)
button_movebackward.place(x=100, y=150, width=200, height=100)
button_stop = tk.Button(frame_edit, text='tingzhi', command=stop)
button_stop.place(x=100, y=280, width=200, height=100)
button_moveto = tk.Button(frame_edit, text='moveto', command=moveto)
button_moveto.place(x=100, y=400, width=200, height=100)
# button_exit = tk.Button(frame_edit, text='退出',command=rootwindow.destroywindow)
# button_exit.place(x=100, y=300, width=200, height=100)
##########self.frame_edit.place(x=270, y=340, width=1120, height=150)###########
#########################建立状态栏###########################################
# def def_showtime():  # 状态栏显示时间
#     string = "日期： "+time.strftime("%Y-%m-%d") + "  时间:  "+time.strftime("%H:%M:%S")+"    "
#     statusbar.config(text=string)
#     statusbar.after(1000, def_showtime)
# statusbar = tk.Label(rootwindow, text="北牧养殖场管理系统V1.0", font=("楷体",12), \
#                     bd=1, relief=tk.SUNKEN, anchor='e')
# statusbar.pack(side=tk.BOTTOM, fill=tk.X)
# def_showtime()
##########################建立状态栏###########################################
##########################设置窗体###########################################
rootwindow.mainloop()
##########################设置窗体###########################################