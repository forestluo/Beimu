import threading

from threading import Thread

from L2 import *

class LaserSensor(Thread):
    # 设备句柄
    __rear = None
    __front = None
    # 距离
    __rear_dist = -1
    __front_dist = -1
    
    # 启动标志
    __start = False
    # 停止标志
    __stopped = False
    # 同步锁
    __lock = threading.Lock()

    # 定义初始化函数
    def __init__(self, port1, port2):
        # 初始化线程
        Thread.__init__(self)
        # 生成设备
        self.__rear = L2(port2)
        self.__front = L2(port1)

    # 是否启动
    def is_start(self):
        # 返回结果
        return self.__start
    
    # 是否停止
    def is_stopped(self):
        # 返回结果
        return self.__stopped
    
    # 获得距离
    def get_dist(self):
        # 获得同步数据
        self.__lock.acquire()
        rear_dist = self.__rear_dist
        front_dist = self.__front_dist
        self.__lock.release()
        # 检查结果
        if rear_dist <= 0: return rear_dist
        if front_dist <= 0: return front_dist
        # 返回结果
        return rear_dist + front_dist
    
    # 获得后部距离
    def get_rear_dist(self):
        # 获得同步数据
        self.__lock.acquire()
        value = self.__rear_dist
        self.__lock.release()
        return value
    
    # 获得前部距离
    def get_front_dist(self):
        # 获得同步数据
        self.__lock.acquire()
        value = self.__front_dist
        self.__lock.release()
        return value

    # 开始读取
    def start_read(self):
        # 设置启动标志
        self.__start = False
        # 清理停止标志
        self.__stopped = False
        # 关闭
        if not self.__rear.stop():
            # 打印信息
            print("LaserSensor.start_read : 无法停止后部传感器！")
            return False
        # 开启激光
        if not self.__rear.toggle(True):
            # 打印信息
            print("LaserSensor.start_read : 无法开启后部激光器！")
            return False
        # 开启连续读取
        if self.__rear.get_dist(False) <= 0:
            # 打印信息
            print("LaserSensor.start_read : 无法开启连续读取模式！")
            return False
        # 关闭
        if not self.__front.stop():
            # 打印信息
            print("LaserSensor.start_read : 无法停止后部传感器！")
            return False
        # 开启激光
        if not self.__front.toggle(True):
            # 打印信息
            print("LaserSensor.start_read : 无法开启后部激光器！")
            return False
        # 开启连续读取
        if self.__front.get_dist(False) <= 0:
            # 打印信息
            print("LaserSensor.start_read : 无法开启连续读取模式！")
            return False
        # 启动线程
        self.start()
        # 等待一段时间
        while not self.__start: time.sleep(0.1)
        # 打印信息
        print("LaserSensor.start_read : 读取线程已经启动 !")
        # 返回结果
        return True

    # 停止读取
    def stop_read(self):
        # 等待线程结束
        if self.__start:
            # 设置标志位
            self.__start = False
            # 等待结束
            self.join()
            # 清理标记位
            self.__start = False
        # 打印信息
        print("LaserSensor.stop_read : 线程已经停止 !")
        # 关闭激光器
        if not self.__rear.toggle(False):
            # 打印信息
            print("LaserSensor.stop_read : 无法关闭后部激光器 !")
        # 关闭激光器
        if not self.__front.toggle(False):
            # 打印信息
            print("LaserSensor.stop_read : 无法关闭前部激光器 !")

    # 运行函数
    def run(self):
        # 设置启动标志
        self.__start = True
        # 清理停止标志
        self.__stopped = False
        # 打印信息
        print("LaserSensor.run : 开始连续读取 !")
        # 执行函数
        try:
            # 执行死循环
            while self.__start:
                # 获得测量结果
                rear_dist = \
                    self.__rear.get_dist(True)
                # 设置同步数据
                self.__lock.acquire()
                self.__rear_dist = rear_dist
                self.__lock.release()
                # 获得测量结果
                front_dist = \
                    self.__front.get_dist(True)
                # 设置同步数据
                self.__lock.acquire()
                self.__front_dist = front_dist
                self.__lock.release()
        # 处理异常
        except Exception as e:
            traceback.print_exc()
            print("LaserSensor.run :", str(e))
            print("LaserSensor.run : unexpected exit !")
        # 设置停止标志
        self.__stopped = True            
        # 打印信息
        print("LaserSensor.run : 停止连续读取 !")
