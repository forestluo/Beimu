# -*- coding: utf-8 -*

import sys
import time

from AQMD6040BLS import *

class MotorController:
    # 设备句柄
    __device = None
    # 中断标志
    __interrupt = False

    # 已学习线序
    study = False
    # 额定功率(W)
    power = 800
    # 前进指示
    forward = -1
    # 最低转速(%)
    duty_ratio = 12
    # 启动时长(秒)
    skip_time = 2.0
    # 最低换向频率(Hz)
    reverse_freq = 32

    #析构方法
    #当对象被删除时，会自动被调用,然后释放内存
    def __del__(self):
        # 删除设备
        if self.__device is not None :
            del self.__device

    # 定义初始化函数
    def __init__(self, port, address):
        # 生成设备
        self.__device = AQMD6040BLS(port, address)

    # 读取信息
    def read_info(self):
        # 读取信息
        return self.__device.read_info()
    
    # 读取状态
    def read_status(self):
        # 读取信息
        return self.__device.read_status()

    # 寄存器信息
    def reg_info(self, ind):
        # 返回数值
        return self.__device[ind].info
    
    # 获得寄存器数值
    def get_reg(self, ind):
        # 返回数值
        return self.__device[ind].get()
    
    # 设置寄存器数值
    def set_reg(self, ind, value):
        # 返回数值
        return self.__device[ind].set(value)

    # 获得状态
    def get_error(self):
        # 返回数值
        return self.get_reg(0x0033)

    # 获得堵转
    def get_blocked(self):
        # 返回数值
        return self.get_reg(0x0032)

    # 获得输入电压
    def get_voltage(self):
        # 返回数值
        return self.get_reg(0x0038) * 0.1
    
    # 获得实时电流
    def get_current(self):
        # 返回数值
        return self.get_reg(0x0021) * 0.01

    # 获得实时功率
    def get_power(self):
        # 返回数值
        return self.get_voltage() * self.get_current()

    # 清理坐标
    def clear_pos(self):
        # 返回结果
        return self.__device.clear_pos()

    # 停止设备
    def stop_motor(self, mode = 0):
        # 设置标志位
        self.__interrupt = True
        # 返回结果        
        return self.__device.stop_motor(mode)
    
    # 设置PWM
    # 设置后电机会产生相应动作！
    def set_pwm(self, pwm):
        # 设置PWM控制参数
        self.__device[0x0042].set(pwm)
        # 写寄存器
        if not self.__device.write_reg(0x0042):
            print("MotorController.set_pwm : 无法设置占空比！")
            return False
        #print("MotorController.set_pwm : 占空比已经设置！")
        return True

    # 初始化设备
    def init_device(self, force = False):
        
        # 读取设备信息
        if not self.read_info():
            print("MotorController.init_device : 无法读取设备信息！")
            return False
        
        # 读取设备状态
        if not self.read_status():
            print("MotorController.init_device : 无法读取设备状态！")
            return False
            
        # 获得输入电压
        voltage = self.get_voltage()
        # 检查结果
        if voltage < 0:
            print("MotorController.init_device : 无效的输入电压！")
            return False
        # 打印结果
        print("MotroController.init_device : 输入电压%fV"%voltage)

        # 获得实时电流
        current = self.get_current()
        # 检查结果
        if current < 0:
            print("MotorController.init_device : 无效的实时电流！")
            return False
        # 打印结果
        print("MotroController.init_device : 实时电流%fA"%current)
            
        # 初始化电机
        if not self.__device.init_motor(force) :
            print("MotorController.init_device : 未能初始化电机 !")
            return False
        
        # 电机成功初始化
        print("MotorController.init_device : 电机成功初始化 !")

        # 发送停止指令
        # 正常停止
        if not self.stop_motor():
            # 打印信息
            print("MotorController.init_device : 未能停止电机 !")
            return False

        # 返回结果
        return True

    # 向前运行直至到头（堵转）
    def forward_cmd(self, pwm = 0):
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 返回结果数值
        return self.pwm_cmd(+1, pwm)

    # 向前运行直至到头（堵转）
    def move_forward(self, pwm = 0):
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 返回结果数值
        return self.pwm_move(+1, pwm)

    # 向前运行直至到头（堵转）
    def backward_cmd(self, pwm = 0):
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = - int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = - int(self.duty_ratio * self.forward / 0.1)
        # 返回结果数值
        return self.pwm_cmd(-1, pwm)

    # 向前运行直至到头（堵转）
    def move_backward(self, pwm = 0):
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = - int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = - int(self.duty_ratio * self.forward / 0.1)
        # 返回结果数值
        return self.pwm_move(-1, pwm)

    # 运行到某个相对位置
    # 基于PWM
    def pwm_cmd(self, pos, pwm = 0):
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 检查位置符号
        if pos < 0: pwm = - pwm

        # 清理位置计数器
        if not self.clear_pos():
            print("MotorController.pwm_cmd : 位置无法清零！")
            return False
        print("MotorController.pwm_cmd : 位置已经清零！")

        # 设置PWM控制参数
        if not self.set_pwm(pwm):
            print("MotorController.pwm_cmd : 无法设置占空比！")
            return False
        print("MotorController.pwm_cmd : 占空比已经设置！")
        # 返回结果
        return True
        
    # 运行到某个相对位置
    # 基于PWM
    def pwm_move(self, pos, pwm = 0):
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 检查位置符号
        if pos < 0: pwm = - pwm

        # 清理位置计数器
        if not self.clear_pos():
            print("MotorController.pwm_move : 位置无法清零！")
            return -1
        print("MotorController.pwm_move : 位置已经清零！")

        # 设置PWM控制参数
        if not self.set_pwm(pwm):
            print("MotorController.pwm_move : 无法设置占空比！")
            return -1
        print("MotorController.pwm_move : 占空比已经设置！")

        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)
        # 开始移动
        if not self.check_moving(pos):
            # 打印信息
            print("MotorController.pwm_move: 无法正确移动！")
        # 读取位置计数器
        if not self.__device.read_reg(0x0024):
            # 打印信息
            print("MotorController.pwm_move : 无法读取位置信息！")
            return -1
        #print("MotorController.pwm_move : 已读取位置信息！")
        # 返回结果
        return abs(self.__device[0x0024].get())

    # 运行到某个相对位置
    # 基于换向频率
    def freq_move(self, pos, freq = 0):
        # 检查数值
        if freq <= 0 or freq > 1000:
            # 计算PWM控制参数
            freq = self.reverse_freq

        # 清理位置计数器
        if not self.clear_pos():
            print("MotorController.freq_move : 位置无法清零！")
            return -1
        #print("MotorController.freq_move : 位置已经清零！")
        
        # 设置换向频率(0.1Hz)
        self.__device[0x0044].set(freq * 10)
        # 设置相对位置模式
        self.__device[0x0045].set(1)
        # 设置目标位置(脉冲数)
        self.__device[0x0046].set(pos * self.forward)
        # 写入寄存器
        if not self.__device.write_reg(0x0044, 3):
            print("MotorController.freq_move : 写寄存器失败！")
            return False
        
        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)
        # 开始移动
        if not self.check_moving(pos):
            # 打印信息
            print("MotorController.freq_move: 无法正确移动！")
        # 读取位置计数器
        if not self.__device.read_reg(0x0024):
            # 打印信息
            print("MotorController.freq_move : 无法读取位置信息！")
            return -1
        #print("MotorController.freq_move : 已读取位置信息！")
        # 返回结果
        return abs(self.__device[0x0024].get())

    # 运动检测
    def check_moving(self, pos = 0):
        # 实时功率
        power = 0
        # 计数器
        timeout = 0
        # 清理中断标志
        self.__interrupt = False       
        # 开始检测设备功率
        while timeout <= 10 * self.skip_time \
            and power >= 0 and not self.__interrupt:

            # 读取设备状态
            if not self.read_status():
                # 设置无效值
                power = -1
                # 打印信息
                print("MotorController.check_moving : 无法读取设备状态！")
                break

            # 读取设备功率
            power = self.get_power()
            # 打印信息
            #print("MotorController.check_moving : %fW"% power)
            
            # 检查功率超出情况
            if power < self.power:
                # 计数器清零
                timeout = 0
            else:
                # 计数器加一
                timeout = timeout + 1
            
            # 读取位置计数器
            if abs(pos) > 1 and \
                abs(self.__device[0x0024].get()) >= abs(pos):
                # 打印信息
                print("MotorController.check_moving : 已到达目标位！")
                break
            
            # 读取堵转状态
            if self.__device[0x0032].get() != 0:
                # 打印信息
                print("MotorController.check_moving : %s !"% self.__device[0x0032].info)
                break

            # 读取错误状态
            if self.__device[0x0033].get() != 0:
                # 打印信息
                print("MotorController.check_moving : %s ！"% self.__device[0x0033].info)
                break

        # 检查中断标志
        if self.__interrupt:
            # 清理中断标志
            self.__interrupt = False
        else:
            # 检查数据
            if power < 0:
                # 打印信息
                print("MotorController.check_moving : 无法读取实时功率！")
            elif power > self.power:
                # 打印信息
                print("MotorController.check_moving : 实时功率(%dW)超出额定功率！"% power)
        
        # 停止执行
        if not self.stop_motor():
            # 打印信息
            print("MotorController.check_moving : 无法停止设备！")
            return False
        # 打印信息
        print("MotorController.check_moving : 设备已经停止！")
        # 返回结果
        return True if power > 0 and self.get_blocked() == 0 and self.get_error() == 0 else False

# 定义主函数
def main():

    # 创建控制器
    myController = MotorController("/dev/ttyUSB0", 0x05)

    # 检查设备是否存在
    if myController.read_info():
        print("MotorController.main : 设备存在 !")
        # 初始化设备
        #myController.init_device()
        # 后退
        #myController.move_backward()
        
    else:
        print("MotorController.main : 设备不存在 !")

    # 删除控制器
    del myController

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("MotorController.__main__ :", str(e))
        print("MotorController.__main__ : unexpected exit !")