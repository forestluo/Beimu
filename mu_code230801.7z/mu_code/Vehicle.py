# -*- coding: utf-8 -*

from threading import *

from VehicleConfig import *

from WheelSensor import *
from EnergySensor import *
from WeightSensor import *
from MotorController import *

class Vehicle:
    # 配置文件
    __config = None
    # 同步锁
    __lock = Lock()

    # 配置参数
    rail_dist = 1039
    leave_count = 100
    pulse_count = 3020

    # 位置传感器
    __wheelSensor = None
    # 电能表设备
    __energySensor = None
    # 称重传感器
    __weightSensor = None
    # 后桥电机控制器
    __motorController = None
    
    # 定义初始化函数
    def __init__(self):
        # 生成缺省配置
        self.__config = VehicleConfig()
   
    # 重置
    def reset(self):
        # 返回指令执行结果
        return self.__wheelSensor.reset()
    
    # 返回当前位置
    def get_pos(self):
        # 返回指令执行结果
        return self.__wheelSensor.get_pos()

    # 中断指令
    def stop(self):
        # 返回指令执行结果
        return self.__motorController.stop_motor()
    
    # 运动到某个相对位置
    # 基于PWM (单位：毫米)
    def move(self, pos, pwm = 0):
        # 将位置从毫米换算成脉冲数
        pulse = int(pos * self.pulse_count / self.rail_dist)
        # 打印信息
        print("Vehicle.move : 脉冲数(%d)！"% pulse)
        # 执行移动指令
        return self.__motorController.\
            pwm_move(pulse, pwm) * self.rail_dist / self.pulse_count

    # 前进直至堵转
    # 基于配置文件的PWM设置
    def move_forward(self, pwm = 0):
        # 返回指令执行结果
        return self.__motorController.move_forward(pwm)
    
    # 后退直至堵转
    # 基于配置文件的PWM设置
    def move_backward(self, pwm = 0):
        # 返回指令执行结果
        return self.__motorController.move_backward(pwm)
        
    # 创建设备
    def init_Vehicle(self):
        # 加载配置
        self.__config.load_conf()
        
        # 设置参数
        self.rail_dist = self.__config.\
            get_rail_dist(self.rail_dist)
        self.leave_count = self.__config.\
            get_leave_count(self.leave_count)
        self.pulse_count = self.__config.\
            get_pulse_count(self.pulse_count)
        
        # 创建设备
        self.__wheelSensor = WheelSensor(\
            self.__config.get_port(1, "dev/ttyUSB0"),\
                self.__config.get_address(1, 0x03))

        # 创建设备
        self.__energySensor = EnergySensor(\
            self.__config.get_port(2, "/dev/ttyUSB0"),\
                self.__config.get_address(2, 0x01))
        
        # 创建设备
        self.__weightSensor = WeightSensor(\
            self.__config.get_port(3, "/dev/ttyUSB1"),\
                self.__config.get_address(3, 0x03))
        
        # 创建设备
        self.__motorController = MotorController(\
            self.__config.get_port(4, "/dev/ttyUSB0"),\
                self.__config.get_address(4, 0x05))
        # 设置学习标志
        self.__motorController.study = \
            self.__config.get_study(self.__motorController.study)
        # 设置额定功率
        self.__motorController.power = \
            self.__config.get_power(self.__motorController.power)
        # 设置前进方向
        self.__motorController.forward = \
            self.__config.get_forward(self.__motorController.forward)
        # 设置运行速度
        self.__motorController.duty_ratio = \
            self.__config.get_duty_ratio(self.__motorController.duty_ratio)
        # 设置启动时长
        self.__motorController.skip_time = \
            self.__config.get_skip_time(self.__motorController.skip_time)
        # 设置换向频率
        self.__motorController.reverse_freq = \
            self.__config.get_reverse_freq(self.__motorController.reverse_freq)

        # 检查学习标志
        if not self.__motorController.study:
            # 初始化设备
            if not self.__motorController.init_device():
                print("Vehicle.init_device : 无法初始化设备！")
                return False
            # 设置标记位
            self.__config.set_option(4, "study", "1")

        # 停止电机
        if not self.__motorController.stop_motor():
            # 打印信息
            print("Vehicle.init_device : 无法停止后桥电机！")
            return False
        # 返回结果
        return True

    # 移动至自动充电
    # 基于配置文件的PWM设置    
    def moveto_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power > 0:
            print("Vehicle.moveto_charger : 已经在充电！")
            return True

        # 退回设备
        position = self.move_backward()
        # 检查结果
        if position < 0:
            print("Vehicle.moveto_charger : 无法移动小车！")
            return False
        
        print("Vehicle.moveto_charger : 等待延迟开关！")
        # 等待一段时间
        time.sleep(5)

        print("Vehicle.moveto_charger : 等待电能表启动！")
        # 等待一段时间
        time.sleep(5)

        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vehicle.moveto_charger : 充电装置异常！")
            return False
        # 返回结果
        return True

    # 离开自动充电装置
    # 基于配置文件的PWM设置    
    def leave_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vehicle.leave_charger : 已经离开！")
            return True
        # 循环处理
        while power > 0:
            # 移动一小段距离
            if not self.move(self.leave_count):
                print("Vehicle.leave_charger : 无法前进！")
                return False
            # 再次读取电表数值
            power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vehicle.leave_charger : 已经离开！")
            return True
        return False

    # 定义原点
    def set_origin(self):

        # 退回设备
        position = self.move_backward()
        # 检查结果
        if position < 0:
            print("Vehicle.set_origin : 无法移动小车！")
            return False
        
        print("Vehicle.set_origin : 等待小车静止！")
        # 等待一段时间
        time.sleep(5)

        # 移动一小段距离
        if not self.move(self.leave_count):
            print("Vehicle.set_origin : 小车无法前进！")
            return False
        
        # 重置位置计数器
        if not self.__wheelSensor.reset():
            print("Vehicle.set_scale : 无法重置位置计数器！")
            return False
        
        print("Vehicle.set_scale : 原点已经设置完毕！")
        return True

    # 测量脉冲与距离之间的关系
    # 基于配置文件的PWM设置
    def set_scale(self, pulse_count = 0):
  
        # 检查参数
        if pulse_count == 0:
            # 调整参数
            pulse_count = self.pulse_count
            
        # 重置位置计数器
        if not self.__wheelSensor.reset():
            print("Vehicle.set_scale : 无法重置位置计数器！")
            return False
        
        # 移动一段距离
        value = self.__motorController.freq_move(pulse_count)
        # 检查结果
        if abs(value) < abs(pulse_count):
            print("Vehicle.set_scale : 移动小车失败！")
            return False
        # 设置当前数值
        self.pulse_count = value       

        # 读取位置信息
        pos = self.__wheelSensor.get_pos()
        # 检查结果
        if pos is None:
            print("Vehicle.set_scale : 无法获得当前位置信息！")
            return False            
        # 设置当前数值
        self.rail_dist = round(1000.0 * abs(pos))
        
        # 更新配置属性
        self.__config.set_rail_dist(self.rail_dist)
        self.__config.set_pulse_count(self.pulse_count)
        # 保存配置文件
        self.__config.save_conf()
        # 打印信息
        print("Vehicle.set_scale : 脉冲数(%d), 轨道距离(%f)"% (self.pulse_count, self.rail_dist))
        # 返回结果
        return True

    # 运动到某个相对位置
    # 基于PWM和计米器 (单位：毫米)
    def moveto(self, pos, pwm = 0):

        # 获得当前位置
        curr = self.get_pos() * 1000.0
        # 检查结果
        if curr is None:
            print("Vehicle.moveto : 无法获取当前位置！")
            return False
        # 打印信息
        print("Vehicle.moveto : 当前位置(%d)，目标位置(%d)"% (curr, pos))
        
        # 计算距离
        dist = pos - curr
        # 打印信息
        print("Vehicle.moveto : 需要移动距离%d毫米！"% dist)
        
        # 检查数值
        if pwm > 0 and abs(pwm) <= 100:
            # 计算PWM控制参数
            pwm = int(pwm * self.forward / 0.1)
        else:
            # 计算PWM控制参数
            pwm = int(self.duty_ratio * self.forward / 0.1)
        # 检查位置符号
        if dist < 0: pwm = - pwm

        # 清理位置计数器
        if not self.__motorController.clear_pos():
            print("Vehicle.moveto : 位置无法清零！")
            return False
        print("Vehicle.moveto : 位置已经清零！")
        
        # 设置PWN控制参数
        if not self.__motorController.set_pwm(pwm):
            print("Vehicle.moveto : 无法设置占空比！")
            return False
        print("Vehicle.moveto : 占空比已经设置！")

        # 启动时功率会临时超额定功率
        # 需要跳过启动阶段进行功率判断
        time.sleep(self.skip_time)
        
        # 开始移动
        if not self.move(pos):
            # 打印信息
            print("Vehicle.moveto: 无法正确移动！")
            return False
        
        # 获得当前位置
        curr = self.get_pos() * 1000.0
        # 检查结果
        if curr is None:
            print("Vehicle.moveto : 无法获取当前位置！")
            return False
        # 打印信息
        print("Vehicle.moveto : 当前位置(%d)，目标位置(%d)"% (curr, pos))
        return True

# 定义主函数
def main():

    # 创建小车
    myVechile = Vehicle()

    # 创建设备
    if myVechile.init_Vehicle():

        # 设置原点
        myVechile.set_origin()
        # 测量比例
        #myVechile.set_scale(1000)

    else:
        print("Vehicle.main : 无法初始化设备！")
            
    # 删除小车
    del myVechile

    # 等待键盘消息
    #input("Vehicle.main : 按下Enter键结束当前程序！\r\n")

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("Vehicle:__main__ :", str(e))
        print("Vehicle:__main__ : unexpected exit !")