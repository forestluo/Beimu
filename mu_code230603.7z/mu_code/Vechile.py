# -*- coding: utf-8 -*

import os
import configparser

from VechileConfig import *

from RFIDSensor import *
from EnergySensor import *
from WeightSensor import *
from MotorController import *

class Vechile:
    # 配置文件
    __config = None

    # 离开充电桩的距离（0.1s）
    leave_count = 5
    # 脉冲数
    pulse_count = 1113
    # 车轮外缘距离（mm） 
    wheel_range = 750
    # 轨道长度（mm）
    rail_length = 5430

    # RFID设备
    __rfidSensor = None
    # 电能表设备
    __energySensor = None
    # 称重传感器
    __weightSensor = None
    # 后桥电机控制器
    __motorController = None

    #析构方法
    #当对象被删除时，会自动被调用,然后释放内存
    def __del__(self):
        # 删除配置
        if self.__config is not None:
            del self.__config
        # 删除设备
        if self.__rfidSensor is not None :
            del self.__rfidSensor
        if self.__energySensor is not None :
            del self.__energySensor
        if self.__weightSensor is not None :
            del self.__weightSensor
        if self.__motorController is not None :
            del self.__motorController

    # 定义初始化函数
    def __init__(self):
        # 生成缺省配置
        self.__config = VechileConfig()

    # 前进直至堵转
    def move_forward(self):
        return self.__motorController.move_forward()
    
    # 后退直至堵转
    def move_backward(self):
        return self.__motorController.move_backward()
    
    # 测量最大脉冲
    def measure_pulse(self):
        # 退回起始位
        if self.move_backward() < 0:
            print("Vechile.measure_pulse : 无法退回原点！")
            return False

        # 执行循环业务（10次）
        i = 10
        pulse = 0
        while i > 0:
            # 计数器减一
            i = i - 1
            # 向前进
            value = self.move_forward()
            # 检查结果
            if value < 0:
                print("Vechile.measure_pulse : 无法前进！")
                return False
            pulse += value

            # 向后退
            value = self.move_backward()
            # 检查结果
            if value < 0:
                print("Vechile.measure_pulse : 无法后退！")
                return False
            pulse += value
        # 返回平均结果数值
        self.pulse_count = int(pulse / 20.0)
        # 更新配置属性
        self.__config.set_pulse_count(self.pulse_count)
        # 保存配置文件
        self.__config.save_conf()
        # 打印信息
        print("Vechile.measure_pulse : 脉冲数(%d)"% self.pulse_count)
        # 返回结果
        return True
    
    # 移动至自动充电
    def moveto_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power > 0:
            print("Vechile.moveto_charger : 已经在充电！")
            return True

        # 退回设备
        position = self.move_backward()
        # 检查结果
        if position < 0:
            print("Vechile.moveto_charger : 无法移动小车！")
            return False
        
        print("Vechile.moveto_charger : 等待延迟开关！")
        # 等待一段时间
        time.sleep(5)

        print("Vechile.moveto_charger : 等待电能表启动！")
        # 等待一段时间
        time.sleep(5)

        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vechile.moveto_charger : 充电装置异常！")
            return False
        # 返回结果
        return True

    # 离开自动充电装置
    def leave_charger(self):
        # 读取电能设备
        power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vechile.leave_charger : 已经离开！")
            return True
        # 循环处理
        while power > 0:
            # 移动一小段距离（大约1秒）
            if not self.__motorController.move_forward(self.leave_count):
                print("Vechile.leave_charger : 无法前进！")
                return False
            # 再次读取电表数值
            power = self.__energySensor.get_power()
        # 检查结果
        if power < 0:
            print("Vechile.leave_charger : 已经离开！")
            return True
        return False

    # 创建设备
    def init_vechile(self):
        # 加载配置
        self.__config.load_conf()

        # 设置离开距离
        self.leave_count = \
            self.__config.get_leave_count(self.leave_count)
        # 设置脉冲数
        self.pulse_count = \
            self.__config.get_pulse_count(self.pulse_count)
        # 设置车轮外缘距离
        self.wheel_range = \
            self.__config.get_wheel_range(self.wheel_range)
        # 设置轨道长度
        self.rail_length = \
            self.__config.get_rail_length(self.rail_length)
        
        # 创建设备
        self.__rfidSensor = RFIDSensor(\
            self.__config.get_port(1, "/dev/ttyUSB0"))
        
        # 创建设备
        self.__energySensor = EnergySensor(\
            self.__config.get_port(2, "/dev/ttyUSB1"),\
                self.__config.get_address(2, 0x01))
        
        # 创建设备
        self.__weightSensor = WeightSensor(\
            self.__config.get_port(3, "/dev/ttyUSB1"),\
                self.__config.get_address(3, 0x03))
        
        # 创建设备
        self.__motorController = MotorController(\
            self.__config.get_port(4, "/dev/ttyUSB1"),\
                self.__config.get_address(4, 0x05))
        # 设置学习标志
        self.__motorController.study = \
            self.__config.get_study(self.__motorController.study)
        # 设置额定功率
        self.__motorController.power = \
            self.__config.get_power(self.__motorController.power)
        # 设置前进方向
        self.__motorController.forward = \
            self.__config.get_forward(self.__motorController.forward)
        # 设置运行速度
        self.__motorController.duty_ratio = \
            self.__config.get_duty_ratio(self.__motorController.duty_ratio)
        # 设置启动时长
        self.__motorController.start_time = \
            self.__config.get_start_time(self.__motorController.start_time)
        
        # 检查学习标志
        if not self.__motorController.study:
            # 初始化设备
            if not self.__motorController.init_device():
                print("Vechile.init_device : 无法初始化设备！")
                return False
            # 设置标记位
            self.__config.set_option(4, "study", "1")

        # 保存配置
        self.__config.save_conf()
        # 返回结果
        return True

# 定义主函数
def main():

    # 创建小车
    myVechile = Vechile()

    # 创建设备
    if myVechile.init_vechile():

        # 测量脉冲数
        if not myVechile.measure_pulse():
            print("Vechile.main : 无法测量脉冲！")
        
        '''
        # 执行循环业务
        i = 20
        while i >= 0:
            # 计数器减一
            i = i - 1

            # 向前进
            fp = myVechile.move_forward()
            print("Vechile.main : 前进计数(%d)"% fp)

            # 等待一段时间
            time.sleep(30)

            # 移动至充电桩
            if myVechile.moveto_charger():
                print("Vechile.main : 开始充电！")
            else:
                print("Vechile.main : 流程异常！")

            # 等待一段时间
            time.sleep(30)

            # 离开充电桩
            if myVechile.leave_charger():
                print("Vechile.main : 放弃充电！")
            else:
                print("Vechile.main : 流程异常！")

            # 等待一段时间
            time.sleep(30)

            # 向后退
            bp = myVechile.move_backward()
            print("Vechile.main : 后退计数(%d)"% bp)

            # 等待一段时间
            time.sleep(30)
            '''
    else:
        print("Vechile.main : 无法初始化设备！")
    
    # 删除小车
    del myVechile

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("Vechile:__main__ :", str(e))
        print("Vechile:__main__ : unexpected exit !")