# -*- coding: utf-8 -*

import serial
import traceback

from Register import *
from DDSU666Regs import *

from SlaveStation import *

class DDSU666(SlaveStation):
    # 控制寄存器列表
    __regs = \
        { \
            0x0000 : D0000(), 0x0001 : D0001(),
            # 协议及地址
            0x0005 : D0005(), 0x0006 : D0006(),
            # 变比
            0x0007 : D0007(), 0x0008 : D0008(),
            # 波特率
            0x000C : D000C(),
            0x000D : D000D(),
            # 时间设置
            0x000E : D000E(), 0x000F : D000F(), 0x0010 : D0010(),

            # 电压与电流
            0x2000 : D2000(), 0x2002 : D2002(),
            # 功率相关参数
            0x2004 : D2004(), 0x2006 : D2006(), 0x2008 : D2008(), 0x200A : D200A(),
            # 频率
            0x200E : D200E(),

            # 有功总电能
            0x4000 : D4000(),
        }
       
    # 定义初始化函数
    def __init__(self, name, address = 0x01):
        # 调用父函数初始化
        SlaveStation.__init__(self, name, address)
        # 设置寄存器列表
        SlaveStation.__setregs__(self, self.__regs)
        # 设置串口参数
        # 需要与设备设置保持一致
        self._set_port(9600, serial.EIGHTBITS,
            serial.PARITY_NONE, serial.STOPBITS_TWO)

# 定义主函数
def main():  
    # 创建设备
    myDevice = DDSU666("/dev/ttyUSB1", 0x01)

    # 读取数据
    myDevice.read_items()
    # 打印数据
    myDevice.print_items()

    # 删除设备
    del myDevice

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("DDSU666:__main__ :", str(e))
        print("DDSU666:__main__ : unexpected exit !")
