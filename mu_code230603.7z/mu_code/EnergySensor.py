# -*- coding: utf-8 -*

from DDSU666 import *

class EnergySensor:
    # 设备句柄
    __device = None

    #析构方法
    #当对象被删除时，会自动被调用,然后释放内存
    def __del__(self):
        # 删除设备
        if self.__device is not None :
            del self.__device

    # 定义初始化函数
    def __init__(self, port, address):
        # 生成设备
        self.__device = DDSU666(port, address)
   
    # 读取电能计数
    def get_power(self):
        # 读取电能计数
        if not self.__device.read_reg(0x4000):
            print("EnergySensor.get_power : fail to read R[4000] !")
            return -1
        return self.__device[0x4000].get()

# 定义主函数
def main():

    # 创建传感器
    mySensor = EnergySensor("/dev/ttyUSB1", 0x01)

    # 检查传感器
    if mySensor.get_power() >= 0:
        print("电能计数：%fKW"%mySensor.get_power())
    else:
        print("EnergySensor.main : sensor not exists !")

    # 删除传感器
    del mySensor

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("EnergySensor.__main__ :", str(e))
        print("EnergySensor.__main__ : unexpected exit !")