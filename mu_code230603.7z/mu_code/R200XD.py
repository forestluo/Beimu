# -*- coding: utf-8 -*

import time
import serial
import struct
import traceback

from SerialPort import *

class R200XD(SerialPort):

    # 定义初始化函数
    def __init__(self, name):
        # 调用父函数初始化
        SerialPort.__init__(self, name)
        # 设置串口参数
        # 需要与设备设置保持一致
        self._set_port(115200, serial.EIGHTBITS,
            serial.PARITY_NONE, serial.STOPBITS_ONE)

    # 配置单天线
    def set_ant(self, index):
        # 打印信息
        if (self.debug):
            print("R200XD.set_ant : begin !")
            print("\tant = %d"%index)
            if(index <= 0 or index > 4):
                print("R200XD.set_ant : invalid ant index !")
                return False
        # 拼接命令字
        buffer = struct.pack(">BBBBBBBBBBBBBBBBBB",
            # 帧头
            0xBB,
            # 帧类型
            0x00,
            # 指令代码
            0x1B,
            # 指令长度
            0x00, 0x02,
            # 参数
            # 单天线
            0x01,
            # 天线端口号
            index,
            # 校验和
            0x00 + 0x1B + 0x00 + 0x02 + 0x01 + index,
            # 帧尾
            0x7E
            )
        # 打印信息
        if (self.debug):
            print("\tcommand = 0x1B")
            print("\tPL = 2")
            print("\toption = 0x01")
            print("\tant = %d"%index)
            print("\tbytes = 0x%s"%buffer.hex())
        try:
            # 打开设备
            serialPort = self.open_port()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : port was opened !")
            # 向串口输出
            serialPort.write(buffer)
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : send request !")
            # 等待必要的时间
            time.sleep(0.1)
            # 从串口读取
            input = serialPort.read_all()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : receive response !")
            # 关闭串口
            serialPort.close()
            # 打印信息
            if (self.debug): \
                print("R200XD.set_ant : port was closed !")
            # 检查反馈结果
            if input is None or len(input) < 7:
                # 打印信息
                if (self.debug): \
                    print("R200XD.set_ant : invalid response !")
                return None
            # 打印信息
            if (self.debug): \
                print("\tbytes[%d] = 0x%s"%(len(input), input.hex()))

        except Exception as e:
            print("R200XD:set_ant :", str(e))
            print("R200XD:set_ant : unexpected exit !")
            # 返回结果
            return False

        # 检查帧头
        if input[0] != 0xBB:
            # 打印信息
            if (self.debug):
                print("R200XD:set_ant : invalid header !")
            return False
        # 检查帧尾
        if input[len(input) - 1] != 0x7E:
            # 打印信息
            if (self.debug):
                print("R200XD:set_ant : invalid end !")
            return False
        
        # 返回结果
        return True

# 定义主函数
def main():  

    # 打印所有串口
    myDevice = R200XD("/dev/ttyS0")

    # 设置单天线
    myDevice.set_ant(2)

    # 删除设备
    del myDevice

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("R200XD:__main__ :", str(e))
        print("R200XD:__main__ : unexpected exit !")
