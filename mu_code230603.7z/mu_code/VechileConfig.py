import os
import traceback
import configparser

class VechileConfig:
    # 配置文件
    __config = None
    # 区划配置
    __sections = \
        [\
            "Vechile", \
            "RFID Sensor", \
            "Charge Sensor", \
            "Weight Sensor", \
            "Motor Controller"]

    #析构方法
    #当对象被删除时，会自动被调用,然后释放内存
    def __del__(self):
        # 删除配置
        if self.__config is not None:
            del self.__config

    # 定义初始化函数
    def __init__(self):
        # 初始化
        self.__config = configparser.ConfigParser()

    # 检查是否存在
    def exists(self):
        # 检查配置文件是否存在
        if not os.path.exists("config.ini"):
            print("VechileConfig.exists : 无法找到配置文件 !")
            return False
        # 读取配置文件
        self.__config.read("config.ini", encoding = "utf-8")
        return True

    # 增加区域
    def add_section(self, ind):
        self.__config.add_section(self.__sections[ind])

    # 检查区域
    def has_section(self, ind):
        # 返回结果
        return self.__config.has_section(self.__sections[ind])
    
    # 检查选项
    def has_option(self, ind, name):
        # 返回结果
        return self.__config.has_option(self.__sections[ind], name)

    # 设置选项
    def set_option(self, ind, name, value):
        # 设置数值
        self.__config.set(self.__sections[ind], name, str(value))
        
    # 获得Port参数
    def get_port(self, ind, default):
        # 检查参数
        if not self.has_option(ind, "port"):
            self.set_option(ind, "port", default)
            return default
        # 读取参数
        port = self.__config.get(self.__sections[ind], "port")
        # 检查参数
        if port.find("/dev/tty") != 0:
            self.set_option(ind, "port", default)
            return default
        # 返回数值
        return port
    
    # 获得Address参数
    def get_address(self, ind, default):
        # 检查参数
        if not self.has_option(ind, "address"):
            self.set_option(ind, "address", default)
            return default
        # 读取参数
        address = self.__config.getint(self.__sections[ind], "address")
        # 检查参数
        if address < 0 or address > 127:
            self.set_option(ind, "address", default)
            return default
        # 返回数值
        return address

    # 获得LeaveCount参数
    def get_leave_count(self, default):
        # 检查参数
        if not self.has_option(0, "leave_count"):
            self.set_option(0, "leave_count", default)
            return default
        # 读取参数
        count = self.__config.getint(self.__sections[0], "leave_count")
        # 检查参数
        if count <= 0 or count > 100:
            self.set_option(0, "leave_count", default)
            return default
        # 返回数值
        return count
                
    # 设置PulseCount参数
    def set_pulse_count(self, value):
         # 检查参数
        if value > 1000 and value < 100000:
            self.set_option(0, "pulse_count", value)

    # 获得PulseCount参数
    def get_pulse_count(self, default):
        # 检查参数
        if not self.has_option(0, "pulse_count"):
            self.set_option(0, "pulse_count", default)
            return default
        # 读取参数
        count = self.__config.getint(self.__sections[0], "pulse_count")
        # 检查参数
        if count <= 1000 or count > 100000:
            self.set_option(0, "pulse_count", default)
            return default
        # 返回数值
        return count
    
    # 获得WheelRange参数
    def get_wheel_range(self, default):
        # 检查参数
        if not self.has_option(0, "wheel_range"):
            self.set_option(0, "wheel_range", default)
            return default
        # 读取参数
        range = self.__config.getint(self.__sections[0], "wheel_range")
        # 检查参数
        if range <= 600 or range > 5000:
            self.set_option(0, "wheel_range", default)
            return default
        # 返回数值
        return range
    
    # 获得RailLength参数
    def get_rail_length(self, default):
        # 检查参数
        if not self.has_option(0, "rail_length"):
            self.set_option(0, "rail_length", default)
            return default
        # 读取参数
        return self.__config.getint(self.__sections[0], "rail_length")    

    # 获得RFIDCount参数
    def get_rfid_count(self, default):
        # 检查参数
        if not self.has_option(1, "rfid_count"):
            self.set_option(1, "rfid_count", default)
            return default
        # 读取参数
        return self.__config.getint(self.__sections[1], "rfid_count")

    # 获得ANTHeight参数
    def get_ant_height(self, default):
        # 检查参数
        if not self.has_option(1, "ant_height"):
            self.set_option(1, "ant_height", default)
            return default
        # 读取参数
        height = self.__config.getint(self.__sections[1], "ant_height")
        # 检查结果
        if height <= 0 or height > 1000:
            self.set_option(1, "ant_height", default)
            return default
        # 返回数值
        return height
            
    # 获得RFIDDist参数
    def get_rfid_dist(self, default):
        # 检查参数
        if not self.has_option(1, "rfid_dist"):
            self.set_option(1, "rfid_dist", default)
            return default
        # 读取参数
        dist = self.__config.getint(self.__sections[1], "rfid_dist")
        # 检查结果
        if dist <= 0 or dist > 2000:
            self.set_option(1, "rfid_dist", default)
            return default
        # 返回数值
        return dist
    
    # 获得ANTDist参数
    def get_ant_dist(self, default):
        # 检查参数
        if not self.has_option(1, "ant_dist"):
            self.set_option(1, "ant_dist", default)
            return default
        # 读取参数
        dist = self.__config.getint(self.__sections[1], "ant_dist")
        # 检查结果
        if dist <= 0 or dist > 1000:
            self.set_option(1, "ant_dist", default)
            return default
        # 返回数值
        return dist

    # 获得RFIDEPC参数
    def get_rfid_epc(self, ind, default):
        # 格式化名字
        name = "rfid_epc_%d"% ind
        # 检查参数
        if not self.has_option(1, name):
            self.set_option(1, name, default)
            return default
        # 读取参数
        return self.__config.get(self.__sections[1], name)
    
    # 获得ResultTimeout参数
    def get_result_timeout(self, default):
        # 检查参数
        if not self.has_option(1, "result_timeout"):
            self.set_option(1, "result_timeout", default)
            return default
        # 读取参数
        timeout = self.__config.getint(self.__sections[1], "result_timeout")
        # 检查结果
        if timeout <= 0 or timeout > 1000:
            self.set_option(1, "result_timeout", default)
            return default
        # 返回数值
        return timeout

    # 获得Study参数
    def get_study(self, default):
         # 检查参数
        if not self.has_option(4, "study"):
            self.set_option(4, "study", default)
            return default
        # 读取参数
        return self.__config.getboolean(self.__sections[4], "study")

    # 获得Power参数
    def get_power(self, default):
         # 检查参数
        if not self.has_option(4, "power"):
            self.set_option(4, "power", default)
            return default
        # 读取参数
        power = self.__config.getint(self.__sections[4], "power")
        # 检查结果
        if power < 100 or power > 5000:
            self.set_option(4, "power", default)
            return default
        # 返回数值
        return power
       
    # 获得Forward参数
    def get_forward(self, default):
        # 检查参数
        if not self.has_option(4, "forward"):
            self.set_option(4, "forward", default)
            return default
        # 读取参数
        forward = self.__config.getint(self.__sections[4], "forward")
        # 检查结果
        if not forward in [-1, +1]:
            self.set_option(4, "forward", default)
            return default
        # 返回数值
        return forward
    
    # 获得DutyRatio参数
    def get_duty_ratio(self, default):
        # 检查参数
        if not self.has_option(4, "duty_ratio"):
            self.set_option(4, "duty_ratio", default)
            return default
        # 读取参数
        duty_ratio = self.__config.getfloat(self.__sections[4], "duty_ratio")
        # 检查结果
        if duty_ratio < -100 or duty_ratio > +100:
            self.set_option(4, "duty_ratio", default)
            return default
        # 返回数值
        return duty_ratio
    
    # 获得StartTime参数
    def get_start_time(self, default):
        # 检查参数
        if not self.has_option(4, "start_time"):
            self.set_option(4, "start_time", default)
            return default
        # 读取参数
        start_time = self.__config.getfloat(self.__sections[4], "start_time")
        # 检查结果
        if start_time < 0 or start_time > 15:
            self.set_option(4, "start_time", default)
            return default
        # 返回数值
        return start_time

    # 加载配置
    def load_conf(self):
        # 检查配置文件是否存在
        if not self.exists():
            print("VechileConfig.load_conf : 无法找到配置文件 !")
            return False

        for i in range(0, len(self.__sections)):
            # 检查区划，并增加区划
            if not self.has_section(i): self.add_section(i)                

        # Vechile
        self.get_leave_count(5)
        self.get_wheel_range(750)
        self.get_rail_length(5430)
        self.get_pulse_count(1113)

        # RFID
        self.get_port(1, "/dev/ttyUSB0")
        # 获得天线距离
        self.get_ant_dist(260)
        # 获得天线高度
        self.get_ant_height(130)
        # 获得RFID距离
        self.get_rfid_dist(530)
        # 获得结果超时时间
        self.get_result_timeout(1)

        # 获得RFID个数
        rfid_count = self.get_rfid_count(0)
        # 检查结果
        if rfid_count <= 0:
            self.set_option(1, "rfid_count", 11)
            self.get_rfid_epc(0, "E280699500005005EF4829B2")
            self.get_rfid_epc(1, "E28069940000501DAC56255D")
            self.get_rfid_epc(2, "E28068940000401DAC585566")
            self.get_rfid_epc(3, "E28068940000501DAC581D62")
            self.get_rfid_epc(4, "E28068940000401DAC559961")
            self.get_rfid_epc(5, "E28068940000401DAC56A8CF")
            self.get_rfid_epc(6, "E28068940000501DAC567962")
            self.get_rfid_epc(7, "E28068940000501DAC534561")
            self.get_rfid_epc(8, "E28068940000501DAC557961")
            self.get_rfid_epc(9, "E28068940000501DAC565D5D")
            self.get_rfid_epc(10, "E28068940000501DAC584D62")
        else:
            # 循环添加
            for i in range(0, rfid_count):
                self.get_rfid_epc(i, "000000000000000000000000")

        # 电能表
        self.get_port(2, "/dev/ttyUSB1")
        self.get_address(2, 0x01)

        # 称重传感器
        self.get_port(3, "/dev/ttyUSB1")
        self.get_address(3, 0x03)

        # 电机控制器
        self.get_port(4, "/dev/ttyUSB1")
        self.get_address(4, 0x05)
        # 电机控制器参数
        self.get_study(False)
        self.get_power(800)
        self.get_forward(-1)
        self.get_duty_ratio(5)
        self.get_start_time(1.0)

        # 返回结果
        return True
    
    # 保存配置
    def save_conf(self):
        # 保存配置文件
        with open("config.ini", "w", encoding = "utf-8") as file:
            self.__config.write(file)

# 定义主函数
def main():

    # 创建小车
    myConfig = VechileConfig()
    # 加载配置文件
    myConfig.load_conf()

    # 保存配置文件
    myConfig.save_conf()
    # 删除小车
    del myConfig

if __name__ == '__main__':
    try:
        # 调用主函数
        main()
    except Exception as e:
        traceback.print_exc()
        print("Vechile:__main__ :", str(e))
        print("Vechile:__main__ : unexpected exit !")