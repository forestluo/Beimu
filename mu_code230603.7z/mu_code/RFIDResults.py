# -*- coding: utf-8 -*

import time

class RFIDResult:
    # 唯一编号
    __epc = ""
    # 天线号
    __ant = 0
    # 计数器
    __cnt = 0
    # 信号强度
    # 单位dBm，一般为负值
    __rssi = 0.0
    # 数据更新时间
    __last_time = time.time()

class RFIDResults:
    # 注册的RFID
    __rfids = []
    # 实时结果集
    __results = []
    # 信号最强记录
    __rssi_results = []

    # 超时时间
    result_timeout = 1

    # 注册RFID
    def reg_rfid(self, epc):
        # 增加注册记录
        if not self.is_reg(epc): \
            self.__rfids.append(epc)

    # 是否注册
    def is_reg(self, epc):
        # 查找匹配的记录
        for i in range(0, len(self.__rfids)):
            if self.__rfids[i] == epc: return True
        return False

    # 增加结果记录
    def add_result(self, result):
        # 查找匹配的记录
        for i in range(0, len(self.__results)):
            # 查找到匹配的元素
            if self.__results[i].__epc == result.__epc \
                and self.__results[i].__ant == result.__ant:
                # 更新信号强度
                self.__results[i].__rssi = result.__rssi
                # 更新时间戳
                self.__results[i].__last_time = result.__last_time
                # 记录数增加一个
                self.__results[i].__cnt = self.__results[i].__cnt + 1
                return
        # 在数据集中增加一个记录
        self.__results.app(result)

    # 清理超时记录
    def remove_result(self):
        # 标志位
        flag = False
        # 获得当前时间戳
        # 设置时间为1秒前
        timeout = time.time() - self.result_timeout
        # 查找匹配的记录
        for i in range(0, len(self.__results)):
            # 查找到匹配的元素
            if self.__results[i].__last_time < timeout:
                # 设置标记位
                flag = True
                self.__results[i].__cnt = -1
        # 检查标记位
        # 如果有超时对象，则切换结果集
        if flag:
            # 生成新数组
            results = []
            # 查找匹配的记录
            for i in range(0, len(self.__results)):
                # 检查标记位
                if self.__result[i].__cnt > 0:
                    # 添加未超时元素
                    results.append(self.__result[i])
            # 删除原数组
            del self.__results
            # 设置新数组
            self.__results = results

    # 获得所有被发现的RFID
    def get_disc(self):
        # 生成数组
        epcs = []
        # 循环处理
        for i in range(0, len(self.__rssi_results)):
            epcs.append(self.__rssi_results.__epc)
        # 返回结果
        return epcs
    
    # 增加最大信号记录
    def add_rssi(self, result):
        # 查找匹配的记录
        for i in range(0, len(self.__rssi_results)):
            # 查找到匹配的元素
            if self.__rssi_results[i].__epc == self.__rssi_results.__epc \
                and self.__rssi_results[i].__ant == self.__rssi_results.__ant \
                and self.__rssi_results[i].__rssi < self.__rssi_results.__rssi:
                # 更新信号强度
                self.__rssi_results[i].__rssi = result.__rssi
                # 更新时间戳
                self.__rssi_results[i].__last_time = result.__last_time
                # 记录数增加一个
                self.__rssi_results[i].__cnt = self.results[i].__cnt + 1
                return
        # 在数据集中增加一个记录
        self.__rssi_results.app(result)

