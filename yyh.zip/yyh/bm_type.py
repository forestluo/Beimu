##########################import的模块###########################################
import tkinter as tk
import tkinter.messagebox as bmmsgbox
import bm_base as bm_base
##########################import的模块###########################################
######类别管理类(档案类别sp，事件类别se,收入类别sr，支出类别zc，部门de，角色ro，权限ri)##############
class bmtype(bm_base.bmwindow):  # 类别管理类
    def __init__(self):  # 类初始化
        super().__init__()
        self.tree_btid = ""  # 父类别
        self.tree1_btid = ""  # 当前类别
        self.detailtable = ""  # 删除时判断关联子表
        self.detailtable_typeid = ""  # 关联子表类别字段
        self.tree_btid_cut=""
        self.tree_btid_copy=""
        self.have_children_item=False
    def add(self):  # 增加类别
        self.tree1_btid = ""
        self.entry_btname.delete(0, tk.END)
        self.entry_btorder.delete(0, tk.END)
    def save(self):  # 保存类别
        btid = self.tree1_btid
        btpid = self.tree_btid
        btname = self.entry_btname.get()
        btorder = self.entry_btorder.get()
        if btpid == "":
            bmmsgbox.showerror("错误信息", "请选择上一级" + self.bttype_name + "。", parent=self.topwindow)
            return ()
        if btname == "":
            bmmsgbox.showerror("错误信息", "请输入" + self.bttype_name + "名称。", parent=self.topwindow)
            return ()
        if btorder == "":
            bmmsgbox.showerror("错误信息", "请输入排序字段。", parent=self.topwindow)
            return ()
        if btid == "":  # 增加记录
            info, btid = self.bmdb.getfieldmaxid('bm_type', 'btid', self.btpre, 10)
            if info != 'OK':
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
            sql = 'insert into bm_type(btid,btpid,btname,btorder,bttype) \
                values(\'' + btid + '\',\'' + btpid + '\',\'' + btname + '\',\'' + btorder + \
                '\',\'' + self.btpre + '\')'
            info = self.bmdb.execsql(sql)
            if info != "OK":
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
        else:       # 修改记录
            sql = 'update bm_type set btname=\'' + btname + '\',btorder=\'' + btorder + \
                '\' where btid=\'' + btid + '\''
            info = self.bmdb.execsql(sql)
            if info != "OK":
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
        self.tree1_btid = ""
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def delete(self):  # 删除类别
        if self.tree1_btid == "":
            return ()
        if bmmsgbox.askyesno("信息", "您确认要删除这个" + self.bttype_name + "吗？", parent=self.topwindow) == False:
            return ()
        sql = 'select btid from bm_type where btpid=\'' + self.tree1_btid + '\''
        info, result = self.bmdb.getresult(sql)
        if info != "OK":
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return ()
        if len(result) > 0:
            bmmsgbox.showerror("错误信息", "该" + self.bttype_name + "下有子项，不能删除。", parent=self.topwindow)
            return ()
        sql = 'select * from ' + self.detailtable + ' where ' + \
            self.detailtable_typeid + '=\'' + self.tree1_btid + '\''
        info, result = self.bmdb.getresult(sql)
        if info != "OK":
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return ()
        if len(result) > 0:
            bmmsgbox.showerror("错误信息", "该" + self.bttype_name + "下有关联子表记录，不能删除。", parent=self.topwindow)
            return ()
        sql = 'delete from bm_type where btid=\'' + self.tree1_btid + '\''
        info = self.bmdb.execsql(sql)
        if info != "OK":
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return ()
        self.tree1_btid = ""
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def menu_pop_cut(self):  # 弹出菜单-剪切
        self.tree_btid_cut=self.tree_btid
        self.tree_btid_copy=""
    def menu_pop_copy(self):  # 弹出菜单-复制
        self.tree_btid_copy=self.tree_btid
        self.tree_btid_cut=""
    def find_childrenitem(self,tree,pid,id):  # 查找子节点是否存在
        for i in tree.get_children(pid):
            if i==id:
                self.have_children_item=True
            self.find_childrenitem(tree,i,id)
    def copy_childrenitem(self,tree,id1,id2,isfirst):  # 复制id1节点及所有子结点到id2下面
        if isfirst==True:
            info,maxid=self.bmdb.getfieldmaxid('bm_type','btid',self.btpre,10)
            if info != "OK":
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()            
            sql='insert into bm_type select \'' + maxid + '\',\''+ id2 + '\',btname,btorder,bttype ' + \
            ' from bm_type where btid=\'' + id1 +'\''
            info=self.bmdb.execsql(sql)
            if info != "OK":
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
            self.copy_childrenitem(self.tree,id1,maxid,False)
        else:
            for i in tree.get_children(id1):
                info,maxid=self.bmdb.getfieldmaxid('bm_type','btid',self.btpre,10)
                if info != "OK":
                    bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                    return ()            
                sql='insert into bm_type select \'' + maxid + '\',\''+ id2 + '\',btname,btorder,bttype ' + \
                ' from bm_type where btid=\'' + i +'\''
                info=self.bmdb.execsql(sql)
                if info != "OK":
                    bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                    return ()
                self.copy_childrenitem(self.tree,i,maxid,False)

    def menu_pop_paste(self):  # 弹出菜单-粘贴
        if self.tree_btid_cut=="" and self.tree_btid_copy=="":
            bmmsgbox.showerror("错误信息","请先剪切或者复制。", parent=self.topwindow)
            return()
        if  self.tree_btid_cut!="":# 剪切
            if self.tree_btid_cut==self.tree_btid:
                bmmsgbox.showerror("错误信息","不能粘贴在结点本身。", parent=self.topwindow)
                return()
            self.find_childrenitem(self.tree,self.tree_btid_cut,self.tree_btid)
            if self.have_children_item==True:
                self.have_children_item=False
                bmmsgbox.showerror("错误信息","不能粘贴在子结点。", parent=self.topwindow)
                return()
            sql='update bm_type set btpid=\''+ self.tree_btid + '\' where btid=\''+ self.tree_btid_cut +'\''
            info=self.bmdb.execsql(sql)
            if info!='OK':
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return()
        else:# 复制
            if self.tree_btid_copy==self.tree_btid:
                bmmsgbox.showerror("错误信息","不能粘贴在结点本身。", parent=self.topwindow)
                return()
            self.find_childrenitem(self.tree,self.tree_btid_copy,self.tree_btid)
            if self.have_children_item==True:
                self.have_children_item=False
                bmmsgbox.showerror("错误信息","不能粘贴在子结点。", parent=self.topwindow)
                return()
            self.copy_childrenitem(self.tree,self.tree_btid_copy,self.tree_btid,True)
        self.tree_btid_cut=""
        self.tree_btid_copy=""
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def refreshtree1(self, btid):  # 刷新self.tree1
        for i in self.tree1.get_children():
            self.tree1.delete(i)
        self.tree_btid = ""
        if len(btid)<=0:
            return()
        aaa = list(btid)
        bbb = str(aaa[0])
        self.tree_btid = bbb
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'' + self.btpre + '\' and btpid=\'' + bbb + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        for i in result:
            self.tree1.insert('', 'end', str(i[0]), values=(str(i[2]), str(i[3])))
        self.refreshentry(self.tree1.selection())
    def refreshentry(self, btid):  # 刷新文本框
        self.tree1_btid = ""
        self.entry_btname.delete(0, tk.END)
        self.entry_btorder.delete(0, tk.END)
        if len(btid)<=0:
            return()
        aaa = list(btid)
        bbb = str(aaa[0])
        self.tree1_btid = bbb
        aaa = list(self.tree1.item(bbb).values())
        bbb = aaa[2]
        self.entry_btname.insert(tk.END, bbb[0])
        self.entry_btorder.insert(tk.END, bbb[1])
    def showwindow(self, rootwindow):  # 显示窗口
        self.getwindow(rootwindow)
        ##########self.frame_tree.place(x=10, y=10, width=300, height=530)###############
        self.topwindow.title(self.bttype_name)
        self.topwindow.geometry('780x560+400+170')
        self.frame_tree = tk.Frame(self.topwindow)
        self.frame_tree.place(x=10, y=10, width=300, height=530)
        self.tree_xscroll = tk.Scrollbar(self.frame_tree,orient=tk.HORIZONTAL)
        self.tree_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_yscroll = tk.Scrollbar(self.frame_tree,orient=tk.VERTICAL)
        self.tree_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree = tk.ttk.Treeview(self.frame_tree,show='tree' ,selectmode = 'browse')
        self.tree.config(xscrollcommand=self.tree_xscroll.set)
        self.tree.config(yscrollcommand=self.tree_yscroll.set)
        self.tree_xscroll.config(command=self.tree.xview)
        self.tree_yscroll.config(command=self.tree.yview)
        self.tree.place(x=0, y=0, width=288, height=518)
        self.tree.bind("<<TreeviewSelect>>", lambda event: self.refreshtree1(self.tree.selection()))  # 绑定TreeViewSelect事件
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.column('#0',width=800,stretch=False)
        ##########self.frame_tree.place(x=10, y=10, width=300, height=530)###############
        ##########self.frame_tree1.place(x=320, y=10, width=450, height=440)#############
        self.frame_tree1 = tk.Frame(self.topwindow)
        self.frame_tree1.place(x=320, y=10, width=450, height=440)
        self.tree1_xscroll = tk.Scrollbar(self.frame_tree1,orient=tk.HORIZONTAL)
        self.tree1_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree1_yscroll = tk.Scrollbar(self.frame_tree1)
        self.tree1_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        columns = ("名称", "排序")
        self.tree1 = tk.ttk.Treeview(self.frame_tree1, show="headings", columns=columns, selectmode = 'browse')   # 创建树状对象
        self.tree1.column("名称", width=335, anchor='center',stretch=False)
        self.tree1.column("排序", width=100, anchor='center',stretch=False)  # 表示列,不显示
        self.tree1.heading("名称", text="名称")
        self.tree1.heading("排序", text="排序")
        self.tree1.place(x=0, y=0, width=438, height=428)
        self.tree1.bind("<<TreeviewSelect>>", lambda event: self.refreshentry(self.tree1.selection()))  # 绑定TreeViewSelect事件
        self.tree1.config(xscrollcommand=self.tree1_xscroll.set)
        self.tree1.config(yscrollcommand=self.tree1_yscroll.set)
        self.tree1_xscroll.config(command=self.tree1.xview)
        self.tree1_yscroll.config(command=self.tree1.yview)
        ##########self.frame_tree1.place(x=320, y=10, width=450, height=440)#############
        ##########self.frame_button.place(x=320, y=460, width=450, height=100)###########
        self.frame_button = tk.Frame(self.topwindow)
        self.frame_button.place(x=320, y=460, width=450, height=100)
        self.lable_btname = tk.Label(self.frame_button, text="名称：", anchor='e')
        self.lable_btname.place(x=0, y=0, width=50, height=30)
        self.entry_btname = tk.Entry(self.frame_button)
        self.entry_btname.place(x=50, y=0, width=250, height=30)
        self.lable_btorder = tk.Label(self.frame_button, text="排序：", anchor='e')
        self.lable_btorder.place(x=300, y=0, width=50, height=30)
        self.entry_btorder = tk.Entry(self.frame_button)
        self.entry_btorder.place(x=350, y=0, width=100, height=30)
        # 按钮
        self.button_add = tk.Button(self.frame_button, text='增加', command=self.add)
        self.button_add.place(x=50, y=40, width=70, height=30)
        self.button_save = tk.Button(self.frame_button, text='保存', command=self.save)
        self.button_save.place(x=140, y=40, width=70, height=30)
        self.button_delete = tk.Button(self.frame_button, text='删除', command=self.delete)
        self.button_delete.place(x=230, y=40, width=70, height=30)
        self.button_exit = tk.Button(self.frame_button, text='退出',command=self.destroywindow)
        self.button_exit.place(x=380, y=40, width=70, height=30)
        ##########self.frame_button.place(x=320, y=460, width=450, height=100)###########
        #################################弹出菜单###################################
        menu_pop = tk.Menu(self.tree,tearoff=False)
        menu_pop.add_command(label="剪切", command=self.menu_pop_cut)
        menu_pop.add_command(label="复制", command=self.menu_pop_copy)
        menu_pop.add_command(label="粘贴", command=self.menu_pop_paste)
        menu_pop.add_separator()# 分割线
        menu_pop.add_command(label="退出", command=menu_pop.unpost)
        def popup_menu(event):
            menu_pop.post(event.x_root, event.y_root)# post在指定的位置显示弹出菜单
        self.tree.bind("<Button-3>", popup_menu)# 绑定鼠标右键,执行popup_Menu函数
        #################################弹出菜单###################################
        # 显示窗口
        self.topwindow.mainloop()

