##########################import的模块###########################################
import tkinter as tk
import tkinter.messagebox as bmmsgbox
import bm_type as bm_type
##########################import的模块###########################################
##########################角色管理类###################################
class bmrole(bm_type.bmtype):  
    def __init__(self):  # 类初始化
        super().__init__()
    def addright(self):  # 显示窗口
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要增加权限的角色。",parent=self.topwindow)
            return()
        if len(self.tree_right.selection())<=0:
            bmmsgbox.showerror("错误信息","请选择要增加的权限。",parent=self.topwindow)
            return()
        aaa=list(self.tree_right.selection())
        bbb=aaa[0]
        sql='delete from rt_relation where reroid=\''+self.tree1_btid + '\' and reriid=\''+ bbb + '\''        
        sql1='insert into rt_relation(reroid,reriid)values(\''+ self.tree1_btid + '\',\''+ bbb + '\')'
        sql=sql+'#*#*#*#*#*'+sql1
        info = self.bmdb.execsql(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree1_btid=self.tree1_btid
        self.tree1.selection_set(tree1_btid)
    def deleteright(self):  # 显示窗口
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要删除权限的角色。",parent=self.topwindow)
            return()
        tree_right1_id=self.tree_right1.selection()
        if len(tree_right1_id)<=0:
            bmmsgbox.showerror("错误信息","请选择要删除的权限。",parent=self.topwindow)
            return()
        aaa=list(tree_right1_id)
        bbb=aaa[0]
        sql='delete from rt_relation where reroid=\''+ self.tree1_btid + '\' and reriid=\''+ bbb + '\''
        info = self.bmdb.execsql(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree1_btid=self.tree1_btid
        self.tree1.selection_set(tree1_btid)
    def refreshtree_right1(self, btid):  # 刷新self.tree_right1
        for i in self.tree_right1.get_children():
            self.tree_right1.delete(i)
        self.refreshentry(btid)
        if len(btid)<=0:
            return()
        aaa = list(btid)
        bbb = str(aaa[0])
        self.tree1_btid = bbb
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'ri\' and btid in (select reriid from rt_relation where reroid=\'' + bbb + '\') order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        for i in result:
            self.tree_right1.insert('', 'end', str(i[0]), values=(str(i[2])))
    def showwindow(self, rootwindow):  # 显示窗口
        self.getwindow(rootwindow)
        #########self.frame_tree.place(x=10, y=10, width=300, height=530)###############
        self.topwindow.title(self.bttype_name)
        self.topwindow.geometry('1000x560+300+170')
        self.frame_tree = tk.Frame(self.topwindow)
        self.frame_tree.place(x=10, y=10, width=300, height=530)
        self.tree_xscroll = tk.Scrollbar(self.frame_tree,orient=tk.HORIZONTAL)
        self.tree_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_yscroll = tk.Scrollbar(self.frame_tree,orient=tk.VERTICAL)
        self.tree_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree = tk.ttk.Treeview(self.frame_tree,show='tree' ,selectmode = 'browse')
        self.tree.config(xscrollcommand=self.tree_xscroll.set)
        self.tree.config(yscrollcommand=self.tree_yscroll.set)
        self.tree_xscroll.config(command=self.tree.xview)
        self.tree_yscroll.config(command=self.tree.yview)
        self.tree.place(x=0, y=0, width=288, height=518)
        self.tree.bind("<<TreeviewSelect>>", lambda event: self.refreshtree1(self.tree.selection()))  # 绑定TreeViewSelect事件
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.column('#0',width=800,stretch=False)
        ##########self.frame_tree.place(x=10, y=10, width=300, height=530)###############
        ##########self.frame_tree1.place(x=320, y=10, width=450, height=440)#############
        self.frame_tree1 = tk.Frame(self.topwindow)
        self.frame_tree1.place(x=320, y=10, width=450, height=440)
        self.tree1_xscroll = tk.Scrollbar(self.frame_tree1,orient=tk.HORIZONTAL)
        self.tree1_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree1_yscroll = tk.Scrollbar(self.frame_tree1)
        self.tree1_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        columns = ("名称", "排序")
        self.tree1 = tk.ttk.Treeview(self.frame_tree1, show="headings", columns=columns, selectmode = 'browse')   # 创建树状对象
        self.tree1.column("名称", width=335, anchor='center',stretch=False)
        self.tree1.column("排序", width=100, anchor='center',stretch=False)  # 表示列,不显示
        self.tree1.heading("名称", text="名称")
        self.tree1.heading("排序", text="排序")
        self.tree1.place(x=0, y=0, width=438, height=428)
        self.tree1.bind("<<TreeviewSelect>>", lambda event: self.refreshtree_right1(self.tree1.selection()))  # 绑定TreeViewSelect事件
        self.tree1.config(xscrollcommand=self.tree1_xscroll.set)
        self.tree1.config(yscrollcommand=self.tree1_yscroll.set)
        self.tree1_xscroll.config(command=self.tree1.xview)
        self.tree1_yscroll.config(command=self.tree1.yview)
        ##########self.frame_tree1.place(x=320, y=10, width=450, height=440)#############
        ##########self.frame_button.place(x=320, y=460, width=450, height=100)###########
        self.frame_button = tk.Frame(self.topwindow)
        self.frame_button.place(x=320, y=460, width=450, height=100)
        self.lable_btname = tk.Label(self.frame_button, text="名称：", anchor='e')
        self.lable_btname.place(x=0, y=0, width=50, height=30)
        self.entry_btname = tk.Entry(self.frame_button)
        self.entry_btname.place(x=50, y=0, width=250, height=30)
        self.lable_btorder = tk.Label(self.frame_button, text="排序：", anchor='e')
        self.lable_btorder.place(x=300, y=0, width=50, height=30)
        self.entry_btorder = tk.Entry(self.frame_button)
        self.entry_btorder.place(x=350, y=0, width=100, height=30)
        # 按钮
        self.button_add = tk.Button(self.frame_button, text='增加', command=self.add)
        self.button_add.place(x=50, y=40, width=70, height=30)
        self.button_save = tk.Button(self.frame_button, text='保存', command=self.save)
        self.button_save.place(x=140, y=40, width=70, height=30)
        self.button_delete = tk.Button(self.frame_button, text='删除', command=self.delete)
        self.button_delete.place(x=230, y=40, width=70, height=30)
        self.button_exit = tk.Button(self.frame_button, text='退出',command=self.destroywindow)
        self.button_exit.place(x=380, y=40, width=70, height=30)
        ##########self.frame_button.place(x=320, y=460, width=450, height=100)###########
        ##########self.frame_tree_right1.place(x=800, y=10, width=190, height=550)###########
        self.frame_tree_right1 = tk.Frame(self.topwindow)
        self.frame_tree_right1.place(x=780, y=10, width=200, height=190)
        self.tree_right1_xscroll = tk.Scrollbar(self.frame_tree_right1,orient=tk.HORIZONTAL)
        self.tree_right1_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_right1_yscroll = tk.Scrollbar(self.frame_tree_right1)
        self.tree_right1_yscroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.frame_button_right1 = tk.Frame(self.topwindow)
        self.frame_button_right1.place(x=780, y=200, width=200, height=50)
        
        self.frame_tree_right = tk.Frame(self.topwindow)
        self.frame_tree_right.place(x=780, y=250, width=200, height=300)
        self.tree_right_xscroll = tk.Scrollbar(self.frame_tree_right,orient=tk.HORIZONTAL)
        self.tree_right_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_right_yscroll = tk.Scrollbar(self.frame_tree_right)
        self.tree_right_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        columns = ("权限名称")
        self.tree_right1 = tk.ttk.Treeview(self.frame_tree_right1, show="headings", columns=columns)   # 创建树状对象
        self.tree_right1.place(x=0, y=0, width=178, height=178)
        self.tree_right1.column("权限名称", width=175, anchor='center')
        self.tree_right1.heading("权限名称", text="权限名称")
        self.tree_right1.config(xscrollcommand=self.tree_right1_xscroll.set)
        self.tree_right1.config(yscrollcommand=self.tree_right1_yscroll.set)
        self.tree_right1_xscroll.config(command=self.tree_right1.xview)
        self.tree_right1_yscroll.config(command=self.tree_right1.yview)
        # 按钮
        self.button_rightadd = tk.Button(self.frame_button_right1, text='增加', command=self.addright)
        self.button_rightadd.place(x=30, y=10, width=50, height=30)
        self.button_rightdelete = tk.Button(self.frame_button_right1, text='删除', command=self.deleteright)
        self.button_rightdelete.place(x=120, y=10, width=50, height=30)
        # self.tree_Right
        self.tree_right = tk.ttk.Treeview(self.frame_tree_right,show='tree' ,selectmode = 'browse')
        self.tree_right.place(x=0, y=0, width=178, height=288)
        self.tree_right.config(xscrollcommand=self.tree_right_xscroll.set)
        self.tree_right.config(yscrollcommand=self.tree_right_yscroll.set)
        self.tree_right_xscroll.config(command=self.tree_right.xview)
        self.tree_right_yscroll.config(command=self.tree_right.yview)
        self.tree_right.column('#0',width=800,stretch=False)
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'ri\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree_right,result)
        ##########self.frame_tree_right.place(x=800, y=10, width=190, height=550)###########
        #################################弹出菜单###################################
        menu_pop = tk.Menu(self.tree,tearoff=False)
        menu_pop.add_command(label="剪切", command=self.menu_pop_cut)
        menu_pop.add_command(label="复制", command=self.menu_pop_copy)
        menu_pop.add_command(label="粘贴", command=self.menu_pop_paste)
        menu_pop.add_separator()# 分割线
        menu_pop.add_command(label="退出", command=menu_pop.unpost)
        def popup_menu(event):
            menu_pop.post(event.x_root, event.y_root)# post在指定的位置显示弹出菜单
        self.tree.bind("<Button-3>", popup_menu)# 绑定鼠标右键,执行popup_Menu函数
        #################################弹出菜单###################################
        # 显示窗口
        self.topwindow.mainloop()
##########################角色管理类###################################

