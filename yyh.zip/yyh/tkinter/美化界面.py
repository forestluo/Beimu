# light
# cosmo - flatly - journal - literal - lumen - minty - pulse - sandstone - united - yeti

# dark
# cyborg - darkly - solar - superhero

# pyinstaller Test.py  -F  -w  --collect-all ttkbootstrap

# apt-get install libjpeg8-dev
# apt-get install zlib1g-dev
# apt-get install libwebp-dev
#  建立软连接

# ln -s /usr/lib/x86_64-linux-gnu/libjpeg.so /usr/lib
# ln -s /usr/lib/x86_64-linux-gnu/libfreetype.so /usr/lib
# ln -s /usr/lib/x86_64-linux-gnu/libz.so /usr/lib
# ln -s /usr/lib/x86_64-linux-gnu/libwebp.so /usr/lib
#  重装PIL

# pip3 install -I pillow


from ttkbootstrap import Style
from tkinter import ttk

style = Style()

window = style.master
ttk.Button(window, text="Submit", style='success.TButton').pack(
    side='left', padx=5, pady=10)
ttk.Button(window, text="Submit", style='success.Outline.TButton').pack(
    side='left', padx=5, pady=10)
window.mainloop()
