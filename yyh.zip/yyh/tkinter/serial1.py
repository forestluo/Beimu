from pickle import TRUE
import serial #导入模块
import serial.tools.list_ports
import threading
import time
import csv
import numpy as np
import matplotlib.pyplot as plt
def find_serial():
  port_list=list(serial.tools.list_ports.comports())
  if len(port_list) == 0:
    print('找不到串口')
  else:
      for i in range(0,len(port_list)):
          print(port_list[i])

POWER_DATA = []
def recive_data(a):
  
  NO=['']
  n=0
  s=True
  while s:
    portx="COM2"
    #波特率，标准值之一：50,75,110,134,150,200,300,600,1200,1800,2400,4800,9600,19200,38400,57600,115200
    bps=115200
    #超时设置,None：永远等待操作，0为立即返回请求结果，其他值为等待超时时间(单位为秒）
    timex=1
    # 打开串口，并得到串口对象
    ser=serial.Serial(portx,bps,timeout=timex)
    data1=ser.readline().decode("gbk")
    if data1 !='':
      #读一个字节//read.hex()
      n+=1
      print(n,type(n))
      text="数据"+str(n)+"已经收到\r\n"
      result=ser.write(text.encode("gbk"))
      print("写总字节数:",result)
      data1=data1.rstrip('\r\n')
      data=data1.split(",")
      print(data)
      POWER_DATA.append(data) 
      print(POWER_DATA)

      if n==10:
          s=0
      #POWER_DATA.clear()
      #print(POWER_DATA)   
    ser.close()#关闭串口

    time.sleep(0.1)

def draw(a):
    y=[]
    for i in a:
        print(i[0])#选取每组数据的第一列
        y.append(i[0])
    # print(type(i[0]))

    x=np.linspace(1,10,10,endpoint=True)

    plt.plot(np.array(x),np.array(y))
    print("ok")
    plt.show()

if __name__=='__main__':
  t1=threading.Thread(target=recive_data, args=("t1",))
  #t2=threading.Thread(target=send_data, args=("t2",))
  t1.start()
  t1.join()

 # global POWER_DATA
  draw(POWER_DATA)
  #t2.start()
  #find_serial()