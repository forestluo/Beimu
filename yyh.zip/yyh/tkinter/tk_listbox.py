from tkinter import *
'''
Listbox组件根据selectmode选项提供了四种不同的选择模式：SINGLE(单选）
BROWSE（也是单选，但推动鼠标或通过方向键可以直接改变选项）
MULTIPLE（多选）和EXTENDED（也是多选，但需要同时按住Shift和Ctrl或拖动鼠标实现
），默认是BROWSE
'''
root = Tk()
#height=11设置listbox组件的高度，默认是10行。
lb = Listbox(root, selectmode=SINGLE, height=3)
lb.pack()
for item in['公鸡','母鸡','小鸡','火鸡','战斗机',]:
    # END表示每插入一个都是在最后一个位置
    lb.insert(END,item)
bt = Button(root, text='删除', command=lambda x=lb:x.delete(ACTIVE))
bt.pack()
mainloop()

