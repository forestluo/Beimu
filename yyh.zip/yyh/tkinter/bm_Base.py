##########################import的模块###########################################
import mysql.connector as mc # mysql数据库连接包
from logging import exception # 异常处理包
##########################import的模块###########################################

##########bm数据库类（提供数据库连接，执行SQL，返回查询结果）########################
class bmDB():
    def __init__(self):
        # 类属性初始化赋值为空
        self.host=""
        self.port=""
        self.charset=""
        self.database=""
        self.user=""
        self.password=""
        try:
            # 读取配置文件信息，并把参数赋值给对应的类属性
            with open('bm.conf','r') as f:
                for i in f.readlines():
                    i=i.strip()
                    if i=="":# 判断是否为空
                        continue
                    if i[0]=='#':# 判断是否是注释行
                        continue
                    if i.find('=')<0:# 判断是否含有"="
                        continue
                    name,value=i.split('=')# 拆分"="两边的字符串
                    name=name.strip()
                    value=value.strip()
                    if value=="":# 判断是否为空
                        continue
                    if name=="":# 判断是否为空
                        continue
                    if value[-1]=='\n':# 判断最后一位是否是换行符
                        value=value[:-1]
                    #给类属性赋值    
                    if name=='host':
                        self.host=value
                    elif name=='port':
                        self.port=value
                    elif name=='charset':
                        self.charset=value
                    elif name=='database':
                        self.database=value
                    elif name=='user':
                        self.user=value
                    elif name=='password':
                        self.password=value
        except Exception as e:
            return(None)# 返回空值

    def connDB(self):# 连接数据库方法
        try:
            # 判断数据库连接参数
            if self.host=="":
                return("数据库连接参数错误:host为空！","")
            if self.port=="":
                return("数据库连接参数错误:port为空！","")
            if self.charset=="":
                return("数据库连接参数错误:charset为空！","")
            if self.database=="":
                return("数据库连接参数错误:database为空！","")
            if self.user=="":
                return("数据库连接参数错误:user为空！","")
            if self.password=="":
                return("数据库连接参数错误:password为空！","")
            db=mc.connect(host=self.host,port=self.port,\
                database=self.database,charset=self.charset,\
                    user=self.user,password=self.password)# 连接数据库
            return('OK',db)# 返回结果
        except Exception as e:
            return("数据库连接错误:"+str(e),"")# 返回错误信息

    def execSQL(self,sql):# 执行SQL方法
        # 连接数据库
        info,db=self.connDB()
        if info!='OK':
            return(info)
        else:
            try:
                # 执行SQL语句
                cursor=db.cursor()
                sql=str(sql).strip()
                sql=sql.split('#*#*#*#*#*')# ‘#*#*#*#*#*’是关键字，用于分隔多个SQL
                for i in sql:
                    i=i.strip()
                    cursor.execute(i)
                db.commit()# 事物提交
                db.close# 关闭数据库连接
                return('OK')# 返回结果
            except Exception as e:
                db.rollback()# 事物回滚
                db.close()# 关闭数据库连接
                return("执行SQL错误："+str(e))# 返回错误信息

    def returnResult(self,sql):# 返回结果集方法
        # 连接数据库
        info,db=self.connDB()
        if info!='OK':
            return(info,"")
        else:
            try:
                # 执行SQL语句
                cursor=db.cursor()
                cursor.execute(sql)
                Result=cursor.fetchall()
                cursor.close()# 关闭游标
                db.close()# 关闭数据库连接
                return('OK',Result)# 返回结果
            except Exception as e:
                cursor.close()# 关闭游标
                db.close()# 关闭数据库连接
                return("返回结果集错误："+str(e),"")# 返回错误信息
##########bm数据库类（提供数据库连接，执行SQL，返回查询结果）########################
