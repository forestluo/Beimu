from tkinter import *
'''
创建一个文本框，在文本框中点击右键弹出“剪切、复制、粘贴”菜单，
并实现其功能。
'''
root = Tk()
root.title("绑定鼠标右键测试")
root.geometry("500x300")
t = Entry(root, width=51, font=("微软雅黑",10))
t.place(x=40, y=100, height="35px")

def callback1(event=None):
    global root
    t.event_generate('<<Cut>>')
    
def callback2(event=None):
    global root
    t.event_generate('<<Copy>>')
    
def callback3(event=None):
    global root
    t.event_generate('<<Paste>>')
    
'''创建一个弹出菜单'''
menu_pop = Menu(root,tearoff=False)
menu_pop.add_command(label="剪切", command=callback1)
menu_pop.add_command(label="复制", command=callback2)
menu_pop.add_command(label="粘贴", command=callback3)

def popup_Menu(event):
    menu_pop.post(event.x_root, event.y_root)   # post在指定的位置显示弹出菜单
t.bind("<Button-3>", popup_Menu)                 # 绑定鼠标右键,执行popup函数
root.mainloop()
