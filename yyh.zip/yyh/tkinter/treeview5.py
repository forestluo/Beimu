import tkinter
import tkinter.messagebox as msgbox
from tkinter import ttk
from turtle import width
import bm_base as bB
bB=bB.bmDB()
wuya = tkinter.Tk()
wuya.title("树形控件例程")
wuya.geometry("1000x600+30+30")

def refreshlist1(event):
    #msgbox.showinfo("信息","OK")
    msgbox.showinfo("信息",tree.selection())
    
# 创建树状对象
tree = ttk.Treeview(wuya,height=50)
tree.place(x = 10,y = 10,width = 100,height = 100)
#tree.bind("<Button-1>", refreshlist1)                 # 绑定鼠标左键,执行refreshlist函数
tree.bind("<<TreeviewSelect>>", refreshlist1)                 # 绑定鼠标左键,执行refreshlist函数

#tree.pack()

# def reorder(id):
#     sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department where rdid=\'' + id + '\' order by rdorder'
#     info,result=bB.returnResult(sql)
#     for i in result:
#         if id==str(i[0]):
#             if item_p==None:
#                 item_p = tree.insert("",'end',text=str(i[2]))
#             sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department where rdpid=\''+ str(i[0]) +'\' order by rdorder'
#             info,result1=bB.returnResult(sql)
#             for j in result1:
#                 tree.insert(item_p,'end',text=str(j[2]))
#                 reorder(result1,str(j[0]),item_p)

# def reorder(pid,item_p):
#     if item_p==None:
#         sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department where rdid=\'' + pid + '\' order by rdorder'
#         info,result=bB.returnResult(sql)
#         item_p = tree.insert("",'end',str(result[0][0]),text=str(result[0][2]))
#         reorder(pid,item_p)
#     else:
#         sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department where rdpid=\'' + pid + '\' order by rdorder'
#         info,result=bB.returnResult(sql)
#         for i in result:
#             item_p1=tree.insert(item_p,'end',str(i[0]),text=str(i[2]))
#             reorder(str(i[0]),item_p1)

def reorder(result,pid,item_p):
    if item_p==None:
        for i in result:
            if str(i[0])==pid:
                item_p = tree.insert("",'end',str(i[0]),text=str(i[2]))
                reorder(result,pid,item_p)
    else:
        for i in result:
            if str(i[1])==pid:
                item_p1=tree.insert(item_p,'end',str(i[0]),text=str(i[2]))
                reorder(result,str(i[0]),item_p1)

sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department order by rdorder'
info,result=bB.returnResult(sql)
if info!='OK':
    msgbox.showerror("错误信息",info)
else:
    reorder(result,"rd00000001",None)
    # for i in result:
    #     tree11 = tree.insert('','end',str(i[0]),text=str(i[2]))
 
# # 添加第二层级列
# tree11_1 = tree.insert(tree11,0,'bj',text='北京')
# tree11_2 = tree.insert(tree11,1,'sh',text='上海')
# tree11_3 = tree.insert(tree11,2,'tj',text='天津')
# tree11_4 = tree.insert(tree11,3,'gd',text='广东')

# tree12_1 = tree.insert(tree12,0,'ny',text='纽约')
# tree12_2 = tree.insert(tree12,1,'hsd',text='华盛顿')
 
 
# # 添加第三级
# tree11_1_1 = tree.insert(tree11_1,0,'xa',text='雄安新区')
# tree11_1_2 = tree.insert(tree11_1,1,'qt',text='其他地区')
 
 
wuya.mainloop()
