# light
# cosmo - flatly - journal - lumen - minty - pulse - sandstone - united - yeti

# dark
# cyborg - darkly - solar - superhero
from logging import exception
from tkinter import *
import tkinter.messagebox
from bm_BaseClass import bm_DB

from ttkbootstrap import Style
#from tkinter import ttk

style = Style(theme = "lumen") # 使用的主题名称

#root = Tk()
root= style.master
root.geometry('660x500')
root.title('北牧第一个图形界面程序')

def getmysqldata():
     sql='select * from aaa'
     tmp=bm_DB()
     info,result=tmp.returnResult(sql)
     if info!='OK':
          msgbox1(info)
     else:
          txt.delete('0.0',END)
          for i in result:
               txt.insert(END,str(i)+"\n")
          msgbox1('取数据成功！')
          

def msgbox():
     answer=tkinter.messagebox.askokcancel('请选择','请选择确定或者取消。')
     txt.delete('0.0',END)
     if answer:
          txt.insert(END,'确定')
     else:
          txt.insert(END,'取消')
def msgbox1(msg):
     #answer=tkinter.messagebox.askokcancel('请选择',msg)
     answer=tkinter.messagebox.showwarning("警告！",msg)
def qingkongtext():
     txt.delete('0.0',END)
def execsql(sql):
     try:
          if len(sql)==0:
               msgbox1("请输入SQL！")   
          else:  
               tmp=bm_DB()
               #msgbox1(sql)
               info=tmp.execSQL(sql)
               if info=='OK':
                    msgbox1('执行成功！')
               else:
                    msgbox1(info)
     except Exception as e:
          msgbox1(str(e))

 
lb1 = Label(root, text='北牧第一个图形界面程序')
lb1.place(relx=0.1, rely=0.1, relwidth=0.6, relheight=0.1)
inp1 = Entry(root)
inp1.place(relx=0.1, rely=0.2, relwidth=0.8, relheight=0.1)
# inp2 = Entry(root)
# inp2.place(relx=0.6, rely=0.2, relwidth=0.3, relheight=0.1)
 
# 方法-直接调用 run1()
btn1 = Button(root, text='取数据库数据', command=getmysqldata)
btn1.place(relx=0.1, rely=0.4, relwidth=0.3, relheight=0.1)
 
# 方法二利用 lambda 传参数调用run2()
btn2 = Button(root, text='执行SQL', command=lambda: execsql(str(inp1.get())))
btn2.place(relx=0.6, rely=0.4, relwidth=0.3, relheight=0.1)

btn3 = Button(root, text='弹出消息对话框', command=msgbox)
btn3.place(relx=0.1, rely=0.6, relwidth=0.3, relheight=0.1)

btn4 = Button(root, text='清空文本框', command=qingkongtext)
btn4.place(relx=0.6, rely=0.6, relwidth=0.3, relheight=0.1)

# 在窗体垂直自上而下位置60%处起，布局相对窗体高度40%高的文本框
txt = Text(root)
txt.place(rely=0.7, relheight=0.3)
 
root.mainloop()