import serial

# 连接
ser = serial.Serial()
ser.port = '/dev/ttyS0'
ser.baudrate = 9600
ser.timeout = 0.2
ser.open()

# 接收返回的信息
while True:
    recv = ser.readline()
    print(str(recv))
    if str(recv) == 'q':
        break
ser.close()
