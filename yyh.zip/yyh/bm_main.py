##########################import的模块##########################
##########################公共的模块#######################
import tkinter as tk
import ttkbootstrap as tbs
import PIL as pil
import time as time
##########################公共的模块#######################
##########################北牧的模块#######################
import bm_base as bm_base
import bm_type as bm_type
import bm_role as bm_role
import bm_user as bm_user
##########################北牧的模块#######################
##########################import的模块##########################
##########################初始化窗体###########################################
bmwindow=bm_base.bmwindow()
style = tbs.Style()
style = tbs.Style(theme='solar')#superhero,solar
rootwindow = style.master
#rootwindow=tk.Tk()
# 登录窗口
loginwindow = bmwindow.getloginwindow(rootwindow,"北牧养殖场管理系统V1.0--用户登录")
rootwindow.wait_window(window=loginwindow)  # 等待直到login销毁，不销毁后面的语句就不执行
# 登录成功后显示主窗口
rootwindow.title('北牧养殖场管理系统V1.0---------当前登录用户：'+bmwindow.runame+'  '+\
                    time.strftime("%Y-%m-%d") + ' '+time.strftime("%H:%M:%S"))
rootwindow.geometry('1600x900+0+0')
rootwindow.resizable(True,True)
# 背景图
canvas = tk.Canvas(rootwindow, width=1600, height=900, bd=0, highlightthickness=0)
imgpath = 'bbb.jpg'
img = pil.Image.open(imgpath)
img = img.resize((1600, 900))
photo = pil.ImageTk.PhotoImage(img, width=1600, height=900)
canvas.create_image(1, 1, anchor='nw', image=photo)
canvas.place(x=0, y=0, width=1600, height=900)
##########################初始化窗体###########################################
##########################实例化类###################
############饲养管理######################
############饲养管理######################
############采购管理######################
############采购管理######################
############库存管理######################
############库存管理######################
############销售管理######################
############销售管理######################
############财务管理######################
# 档案类别
bmsptype = bm_type.bmtype()
bmsptype.btpre = "sp"
bmsptype.bttype_name = "档案类别"
bmsptype.detailtable = "sp_relation"
bmsptype.detailtable_typeid = "srbtid"
# 事件类别
bmsetype = bm_type.bmtype()
bmsetype.btpre = "se"
bmsetype.bttype_name = "事件类别"
bmsetype.detailtable = "sp_event"
bmsetype.detailtable_typeid = "sebtid"
# 收入类别
bmcwshourutype = bm_type.bmtype()
bmcwshourutype.btpre = "sr"
bmcwshourutype.bttype_name = "收入类别"
bmcwshourutype.detailtable = "cw_bill"
bmcwshourutype.detailtable_typeid = "cbbtid"
# 支出类别
bmcwzhichutype = bm_type.bmtype()
bmcwzhichutype.btpre = "zc"
bmcwzhichutype.bttype_name = "支出类别"
bmcwzhichutype.detailtable = "cw_bill"
bmcwzhichutype.detailtable_typeid = "cbbtid"
############财务管理######################
############人力资源######################
# 部门
bmdepartment = bm_type.bmtype()
bmdepartment.btpre = "de"
bmdepartment.bttype_name = "部门"
bmdepartment.detailtable = "rt_relation"
bmdepartment.detailtable_typeid = "redeid"
# 权限
bmright = bm_type.bmtype()
bmright.btpre = "ri"
bmright.bttype_name = "权限"
bmright.detailtable = "rt_relation"
bmright.detailtable_typeid = "reriid"
# 角色
bmrole = bm_role.bmrole()
bmrole.btpre = "ro"
bmrole.bttype_name = "角色"
bmrole.detailtable = "rt_relation"
bmrole.detailtable_typeid = "reroid"
# 用户
bmuser = bm_user.bmuser()
bmuser.btpre = "de"
bmuser.bttype_name = "用户"
bmuser.detailtable = "rt_relation"
bmuser.detailtable_typeid = "reruid"
############人力资源######################
##########################实例化类###################
##########################调用的函数#################
############饲养管理######################
def def_bmachives():  # 档案管理
    #bmachives.showwindow(rootwindow)
    pass
def def_bmevent():  # 事件管理
    #bmevent.showwindow(rootwindow)
    pass
############饲养管理######################
############采购管理######################
############采购管理######################
############库存管理######################
############库存管理######################
############销售管理######################
############销售管理######################
############财务管理######################
def def_bmsptype():  # 档案类别
    bmsptype.showwindow(rootwindow)
def def_bmsetype():  # 事件类别
    bmsetype.showwindow(rootwindow)
def def_bmcwshourutype():  # 收入类别
    bmcwshourutype.showwindow(rootwindow)
def def_bmcwzhichutype():  # 支出类别
    bmcwzhichutype.showwindow(rootwindow)
############财务管理######################
############人力资源######################
def def_bmdepartment():  # 部门管理
    bmdepartment.showwindow(rootwindow)
def def_bmrole():  # 角色管理
    bmrole.showwindow(rootwindow)
def def_bmright():  # 权限管理
    bmright.showwindow(rootwindow)
def def_bmuser():  # 用户管理
    bmuser.showwindow(rootwindow)
############人力资源######################
def msg1():
    pass
##########################调用的函数#################
##########################建立菜单栏###########################################
menu_main = tk.Menu(rootwindow, font=("楷体", 12))
# 饲养管理
menu_siyang = tk.Menu(menu_main)     
menu_main.add_cascade(label="  饲养管理", font=("楷体", 12), menu=menu_siyang)
# 管理羊
menu_yang=tk.Menu(menu_siyang)
menu_siyang.add_cascade(label="  羊管理", font=("楷体", 12), menu=menu_yang)
menu_yang.add_command(label="  档案", font=("楷体", 12), command=msg1)
menu_yang.add_command(label="  事件", font=("楷体", 12), command=def_bmevent)
menu_yang.add_separator()# 分割线
menu_yang.add_command(label="  档案查询", font=("楷体", 12), command=msg1)
menu_yang.add_command(label="  事件查询", font=("楷体", 12), command=msg1)
menu_yang.add_separator()# 分割线
menu_yang.add_command(label="  档案统计", font=("楷体", 12), command=msg1)
menu_yang.add_command(label="  事件统计", font=("楷体", 12), command=msg1)
# 管理料
menu_liao=tk.Menu(menu_siyang)
menu_siyang.add_cascade(label="  料管理", font=("楷体", 12), menu=menu_liao)
menu_liao.add_command(label="  领用", font=("楷体", 12), command=def_bmsptype)
menu_liao.add_command(label="  退回", font=("楷体", 12), command=def_bmsetype)
menu_liao.add_command(label="  报废", font=("楷体", 12), command=def_bmsetype)
menu_liao.add_separator()# 分割线
menu_liao.add_command(label="  领用查询", font=("楷体", 12), command=msg1)
menu_liao.add_command(label="  退回查询", font=("楷体", 12), command=def_bmevent)
menu_liao.add_command(label="  报废查询", font=("楷体", 12), command=def_bmevent)
menu_liao.add_separator()# 分割线
menu_liao.add_command(label="  领用统计", font=("楷体", 12), command=msg1)
menu_liao.add_command(label="  退回统计", font=("楷体", 12), command=def_bmevent)
menu_liao.add_command(label="  报废统计", font=("楷体", 12), command=def_bmevent)
menu_siyang.add_separator()# 分割线
menu_siyang.add_command(label="  退出系统", font=("楷体", 12), command=rootwindow.destroy)
# 采购管理
menu_caigou = tk.Menu(menu_main)     
menu_main.add_cascade(label="  采购管理", font=("楷体", 12), menu=menu_caigou)
menu_caigou.add_command(label="  采购", font=("楷体", 12), command=msg1)
menu_caigou.add_separator()# 分割线
menu_caigou.add_command(label="  采购查询", font=("楷体", 12), command=msg1)
menu_caigou.add_separator()# 分割线
menu_caigou.add_command(label="  采购统计", font=("楷体", 12), command=msg1)
# 库存管理
menu_kucun = tk.Menu(menu_main)     
menu_main.add_cascade(label="  库存管理", font=("楷体", 12), menu=menu_kucun)
menu_kucun.add_command(label="  入库", font=("楷体", 12), command=msg1)
menu_kucun.add_command(label="  出库", font=("楷体", 12), command=msg1)
menu_kucun.add_command(label="  盘点", font=("楷体", 12), command=msg1)
menu_kucun.add_separator()# 分割线
menu_kucun.add_command(label="  入库查询", font=("楷体", 12), command=msg1)
menu_kucun.add_command(label="  出库查询", font=("楷体", 12), command=msg1)
menu_kucun.add_command(label="  盘点查询", font=("楷体", 12), command=msg1)
menu_kucun.add_separator()# 分割线
menu_kucun.add_command(label="  入库统计", font=("楷体", 12), command=msg1)
menu_kucun.add_command(label="  出库统计", font=("楷体", 12), command=msg1)
menu_kucun.add_command(label="  盘点统计", font=("楷体", 12), command=msg1)
# 销售管理
menu_xiaoshou = tk.Menu(menu_main)     
menu_main.add_cascade(label="  销售管理", font=("楷体", 12), menu=menu_xiaoshou)
menu_xiaoshou.add_command(label="  销售", font=("楷体", 12), command=msg1)
menu_xiaoshou.add_separator()# 分割线
menu_xiaoshou.add_command(label="  销售查询", font=("楷体", 12), command=msg1)
menu_xiaoshou.add_separator()# 分割线
menu_xiaoshou.add_command(label="  销售统计", font=("楷体", 12), command=msg1)
# 财务管理
menu_caiwu = tk.Menu(menu_main)   
menu_main.add_cascade(label="  财务管理", font=("楷体", 12), menu=menu_caiwu)
menu_caiwu.add_command(label="  档案类别", font=("楷体", 12), command=def_bmsptype)
menu_caiwu.add_command(label="  事件类别", font=("楷体", 12), command=def_bmsetype)
menu_caiwu.add_command(label="  采购类别", font=("楷体", 12), command=msg1)
menu_caiwu.add_command(label="  销售类别", font=("楷体", 12), command=msg1)
menu_caiwu.add_command(label="  收入类别", font=("楷体", 12), command=def_bmcwshourutype)
menu_caiwu.add_command(label="  支出类别", font=("楷体", 12), command=def_bmcwzhichutype)
menu_caiwu.add_separator()# 分割线
menu_caiwu.add_command(label="  账单", font=("楷体", 12), command=msg1)
menu_caiwu.add_separator()# 分割线
menu_caiwu.add_command(label="  账单查询", font=("楷体", 12), command=msg1)
menu_caiwu.add_separator()# 分割线
menu_caiwu.add_command(label="  账单统计", font=("楷体", 12), command=msg1)
# 人力资源
menu_renliziyuan = tk.Menu(menu_main)     
menu_main.add_cascade(label="  人力资源", font=("楷体", 12), menu=menu_renliziyuan)
menu_renliziyuan.add_command(label="  部门管理", font=("楷体", 12), command=def_bmdepartment)
menu_renliziyuan.add_command(label="  权限管理", font=("楷体", 12), command=def_bmright)
menu_renliziyuan.add_command(label="  角色管理", font=("楷体", 12), command=def_bmrole)
menu_renliziyuan.add_command(label="  用户管理", font=("楷体", 12), command=def_bmuser)
menu_renliziyuan.add_separator()# 分割线
menu_renliziyuan.add_command(label="  相关责任人", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  绩效考核", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  奖励", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  处罚", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_separator()# 分割线
menu_renliziyuan.add_command(label="  相关责任人查询", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  绩效考核查询", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  奖励查询", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  处罚查询", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_separator()# 分割线
menu_renliziyuan.add_command(label="  相关责任人统计", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  绩效考核统计", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  奖励统计", font=("楷体", 12), command=msg1)
menu_renliziyuan.add_command(label="  处罚统计", font=("楷体", 12), command=msg1)
# 删除菜单
#menu_main.delete(0,0)
#menu_yang.delete(0, 0)
##########################建立菜单栏###########################################
##########################建立工具栏1--饲养管理###########################################
toolbar_1 = tk.Frame(rootwindow, relief=tk.RAISED, borderwidth=1)
toolbar_1.pack(side=tk.TOP, fill=tk.X)
# 隐藏工具栏
# toolbar_1.pack_forget()
# 饲养管理
# 羊管理
button_achives = tk.Button(toolbar_1, text="档案", height=1, width=4, command=def_bmachives)
button_achives.pack(side=tk.LEFT, padx=1, pady=1)
button_event = tk.Button(toolbar_1, text="事件", height=1, width=4, command=def_bmevent)
button_event.pack(side=tk.LEFT, padx=1, pady=1)
button_achiveschaxun = tk.Button(toolbar_1, text="档案查询", height=1, width=4, command=msg1)
button_achiveschaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_eventchaxun = tk.Button(toolbar_1, text="事件查询", height=1, width=4, command=msg1)
button_eventchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_achivestongji = tk.Button(toolbar_1, text="档案统计", height=1, width=4, command=msg1)
button_achivestongji.pack(side=tk.LEFT, padx=1, pady=1)
button_eventtongji = tk.Button(toolbar_1, text="事件统计", height=1, width=4, command=msg1)
button_eventtongji.pack(side=tk.LEFT, padx=1, pady=1)
button_spseparator = tk.ttk.Separator(toolbar_1, orient='vertical')
button_spseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 料管理
button_lingyong = tk.Button(toolbar_1, text="领用", height=1, width=4, command=msg1)
button_lingyong.pack(side=tk.LEFT, padx=1, pady=1)
button_tuihui = tk.Button(toolbar_1, text="退回", height=1, width=4, command=msg1)
button_tuihui.pack(side=tk.LEFT, padx=1, pady=1)
button_baofei = tk.Button(toolbar_1, text="报废", height=1, width=4, command=msg1)
button_baofei.pack(side=tk.LEFT, padx=1, pady=1)
button_lingyongchaxun = tk.Button(toolbar_1, text="领用查询", height=1, width=4, command=msg1)
button_lingyongchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_tuihuichaxun = tk.Button(toolbar_1, text="退回查询", height=1, width=4, command=msg1)
button_tuihuichaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_baofeichaxun = tk.Button(toolbar_1, text="报废查询", height=1, width=4, command=msg1)
button_baofeichaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_lingyongtongji = tk.Button(toolbar_1, text="领用统计", height=1, width=4, command=msg1)
button_lingyongtongji.pack(side=tk.LEFT, padx=1, pady=1)
button_tuihuitongji = tk.Button(toolbar_1, text="退回统计", height=1, width=4, command=msg1)
button_tuihuitongji.pack(side=tk.LEFT, padx=1, pady=1)
button_baofeitongji = tk.Button(toolbar_1, text="报废统计", height=1, width=4, command=msg1)
button_baofeitongji.pack(side=tk.LEFT, padx=1, pady=1)
button_spseparator = tk.ttk.Separator(toolbar_1, orient='vertical')
button_spseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 退出系统
button_exit1 = tk.Button(toolbar_1, text="退出系统", height=1,width=4, \
                            command=rootwindow.destroy)
button_exit1.pack(side=tk.LEFT, padx=1, pady=1)
##########################建立工具栏1--饲养管理###########################################
##########################建立工具栏2--采购管理###########################################
toolbar_2 = tk.Frame(rootwindow, relief=tk.RAISED, borderwidth=1)
toolbar_2.pack(side=tk.TOP, fill=tk.X)
# 隐藏工具栏
# toolbar_2.pack_forget()
# 采购
button_caigou = tk.Button(toolbar_2, text="采购", height=1,width=4, command=msg1)
button_caigou.pack(side=tk.LEFT, padx=1, pady=1)
button_caigouchaxun = tk.Button(toolbar_2, text="采购查询", height=1,width=4, command=msg1)
button_caigouchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_caigoutongji = tk.Button(toolbar_2, text="采购统计", height=1,width=4, command=msg1)
button_caigoutongji.pack(side=tk.LEFT, padx=1, pady=1)
button_spseparator = tk.ttk.Separator(toolbar_2, orient='vertical')
button_spseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 退出系统
button_exit2 = tk.Button(toolbar_2, text="退出系统", height=1,width=4, \
                            command=rootwindow.destroy)
button_exit2.pack(side=tk.LEFT, padx=1, pady=1)
##########################建立工具栏2--采购管理###########################################
##########################建立工具栏3--库存管理###########################################
toolbar_3 = tk.Frame(rootwindow, relief=tk.RAISED, borderwidth=1)
toolbar_3.pack(side=tk.TOP, fill=tk.X)
# 隐藏工具栏
# toolbar_3.pack_forget()
# 库存管理
button_ruku = tk.Button(toolbar_3, text="入库", height=1,width=4, command=msg1)
button_ruku.pack(side=tk.LEFT, padx=1, pady=1)
button_chuku = tk.Button(toolbar_3, text="出库", height=1,width=4, command=msg1)
button_chuku.pack(side=tk.LEFT, padx=1, pady=1)
button_pandian = tk.Button(toolbar_3, text="盘点", height=1,width=4, command=msg1)
button_pandian.pack(side=tk.LEFT, padx=1, pady=1)
button_rukuchaxun = tk.Button(toolbar_3, text="入库查询", height=1,width=4, command=msg1)
button_rukuchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_chukuchaxun = tk.Button(toolbar_3, text="出库查询", height=1,width=4, command=msg1)
button_chukuchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_pandianchaxun = tk.Button(toolbar_3, text="盘点查询", height=1,width=4, command=msg1)
button_pandianchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_rukutongji = tk.Button(toolbar_3, text="入库统计", height=1,width=4, command=msg1)
button_rukutongji.pack(side=tk.LEFT, padx=1, pady=1)
button_chukutongji = tk.Button(toolbar_3, text="出库统计", height=1,width=4, command=msg1)
button_chukutongji.pack(side=tk.LEFT, padx=1, pady=1)
button_pandiantongji = tk.Button(toolbar_3, text="盘点统计", height=1,width=4, command=msg1)
button_pandiantongji.pack(side=tk.LEFT, padx=1, pady=1)
button_spseparator = tk.ttk.Separator(toolbar_3, orient='vertical')
button_spseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 退出系统
button_exit3 = tk.Button(toolbar_3, text="退出系统", height=1,width=4, \
                            command=rootwindow.destroy)
button_exit3.pack(side=tk.LEFT, padx=1, pady=1)
##########################建立工具栏3--库存管理###########################################
##########################建立工具栏4--销售管理###########################################
toolbar_4 = tk.Frame(rootwindow, relief=tk.RAISED, borderwidth=1)
toolbar_4.pack(side=tk.TOP, fill=tk.X)
# 隐藏工具栏
# toolbar_4.pack_forget()
# 销售管理
button_xiaoshou = tk.Button(toolbar_4, text="销售", height=1,width=4, command=msg1)
button_xiaoshou.pack(side=tk.LEFT, padx=1, pady=1)
button_xiaoshouchaxun = tk.Button(toolbar_4, text="销售查询", height=1,width=4, command=msg1)
button_xiaoshouchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_xiaoshoutongji = tk.Button(toolbar_4, text="销售统计", height=1,width=4, command=msg1)
button_xiaoshoutongji.pack(side=tk.LEFT, padx=1, pady=1)
button_spseparator = tk.ttk.Separator(toolbar_4, orient='vertical')
button_spseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 退出系统
button_exit4 = tk.Button(toolbar_4, text="退出系统", height=1,width=4, \
                            command=rootwindow.destroy)
button_exit4.pack(side=tk.LEFT, padx=1, pady=1)
##########################建立工具栏4--销售管理###########################################
##########################建立工具栏5--财务管理###########################################
toolbar_5 = tk.Frame(rootwindow, relief=tk.RAISED, borderwidth=1)
toolbar_5.pack(side=tk.TOP, fill=tk.X)
# 隐藏工具栏
# toolbar_5.pack_forget()
# 财务管理
button_sptype = tk.Button(toolbar_5, text="档案类别", height=1,width=4, command=def_bmsptype)
button_sptype.pack(side=tk.LEFT, padx=1, pady=1)
button_setype = tk.Button(toolbar_5, text="事件类别", height=1,width=4, command=def_bmsetype)
button_setype.pack(side=tk.LEFT, padx=1, pady=1)
button_cgtype = tk.Button(toolbar_5, text="采购类别", height=1,width=4, command=def_bmsptype)
button_cgtype.pack(side=tk.LEFT, padx=1, pady=1)
button_xstype = tk.Button(toolbar_5, text="销售类别", height=1,width=4, command=def_bmsetype)
button_xstype.pack(side=tk.LEFT, padx=1, pady=1)
button_cwshourutype = tk.Button(toolbar_5, text="收入类别", height=1,width=4, command=def_bmcwshourutype)
button_cwshourutype.pack(side=tk.LEFT, padx=1, pady=1)
button_cwzhichutype = tk.Button(toolbar_5, text="支出类别", height=1,width=4, command=def_bmcwzhichutype)
button_cwzhichutype.pack(side=tk.LEFT, padx=1, pady=1)
button_cwbill = tk.Button(toolbar_5, text="账单", height=1, width=4, command=msg1)
button_cwbill.pack(side=tk.LEFT, padx=1, pady=1)
button_cwchaxunbill = tk.Button(toolbar_5, text="账单查询", height=1, width=4, command=msg1)
button_cwchaxunbill.pack(side=tk.LEFT, padx=1, pady=1)
button_cwtongjibill = tk.Button(toolbar_5, text="账单统计", height=1, width=4, command=msg1)
button_cwtongjibill.pack(side=tk.LEFT, padx=1, pady=1)
button_cwseparator = tk.ttk.Separator(toolbar_5, orient='vertical')
button_cwseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 退出系统
button_exit5 = tk.Button(toolbar_5, text="退出系统", height=1,width=4, \
                            command=rootwindow.destroy)
button_exit5.pack(side=tk.LEFT, padx=1, pady=1)
##########################建立工具栏5--财务管理###########################################
##########################建立工具栏6--人力资源###########################################
toolbar_6 = tk.Frame(rootwindow, relief=tk.RAISED, borderwidth=1)
toolbar_6.pack(side=tk.TOP, fill=tk.X)
# 隐藏工具栏
# toolbar_6.pack_forget()
# 人力资源
button_department = tk.Button(toolbar_6, text="部门管理", height=1,width=8, command=def_bmdepartment)
button_department.pack(side=tk.LEFT, padx=1, pady=1)
button_right = tk.Button(toolbar_6, text="权限管理", height=1,width=8, command=def_bmright)
button_right.pack(side=tk.LEFT, padx=1, pady=1)
button_role = tk.Button(toolbar_6, text="角色管理", height=1,width=8, command=def_bmrole)
button_role.pack(side=tk.LEFT, padx=1, pady=1)
button_user = tk.Button(toolbar_6, text="用户管理", height=1,width=8, command=def_bmuser)
button_user.pack(side=tk.LEFT, padx=1, pady=1)
button_xg = tk.Button(toolbar_6, text="相关责任人", height=1,width=8, command=msg1)
button_xg.pack(side=tk.LEFT, padx=1, pady=1)
button_kh = tk.Button(toolbar_6, text="绩效考核", height=1,width=8, command=msg1)
button_kh.pack(side=tk.LEFT, padx=1, pady=1)
button_jl = tk.Button(toolbar_6, text="奖励", height=1,width=8, command=msg1)
button_jl.pack(side=tk.LEFT, padx=1, pady=1)
button_cf = tk.Button(toolbar_6, text="处罚", height=1,width=8, command=msg1)
button_cf.pack(side=tk.LEFT, padx=1, pady=1)
button_khchaxun = tk.Button(toolbar_6, text="绩效考核查询", height=1,width=8, command=msg1)
button_khchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_jlchaxun = tk.Button(toolbar_6, text="奖励查询", height=1,width=8, command=msg1)
button_jlchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_cfchaxun = tk.Button(toolbar_6, text="处罚查询", height=1,width=8, command=msg1)
button_cfchaxun.pack(side=tk.LEFT, padx=1, pady=1)
button_khtongji = tk.Button(toolbar_6, text="绩效考核统计", height=1,width=8, command=msg1)
button_khtongji.pack(side=tk.LEFT, padx=1, pady=1)
button_jltongji = tk.Button(toolbar_6, text="奖励统计", height=1,width=8, command=msg1)
button_jltongji.pack(side=tk.LEFT, padx=1, pady=1)
button_cftongji = tk.Button(toolbar_6, text="处罚统计", height=1,width=8, command=msg1)
button_cftongji.pack(side=tk.LEFT, padx=1, pady=1)
button_rtseparator = tk.ttk.Separator(toolbar_6, orient='vertical')
button_rtseparator.pack(side=tk.LEFT, padx=2, pady=1)
# 退出系统
button_exit6 = tk.Button(toolbar_6, text="退出系统", height=1,width=8, \
                            command=rootwindow.destroy)
button_exit6.pack(side=tk.LEFT, padx=1, pady=1)
##########################建立工具栏6--人力资源###########################################
##########################建立状态栏###########################################
def def_showtime():  # 状态栏显示时间
    string = "日期： "+time.strftime("%Y-%m-%d") + "  时间:  "+time.strftime("%H:%M:%S")+"    "
    statusbar.config(text=string)
    statusbar.after(1000, def_showtime)
statusbar = tk.Label(rootwindow, text="北牧养殖场管理系统V1.0", font=("楷体",12), \
                    bd=1, relief=tk.SUNKEN, anchor='e')
statusbar.pack(side=tk.BOTTOM, fill=tk.X)
def_showtime()
##########################建立状态栏###########################################
##########################设置窗体###########################################
rootwindow.config(menu=menu_main)
rootwindow.mainloop()
##########################设置窗体###########################################