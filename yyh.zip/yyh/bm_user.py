##########################import的模块###########################################
import tkinter as tk
import tkinter.messagebox as bmmsgbox
import bm_type as bm_type
##########################import的模块###########################################
##########################用户管理类###################################
class bmuser(bm_type.bmtype):  
    def __init__(self):  # 类初始化
        super().__init__()
        self.tree1_btid_cut=""
        self.tree1_btid_copy=""
    def menu_pop1_cut(self):  # 弹出菜单-剪切
        self.tree1_btid_cut=self.tree1_btid
        self.tree_btid_cut=self.tree_btid
        self.tree1_btid_copy=""
        self.tree_btid_copy=""
    def menu_pop1_copy(self):  # 弹出菜单-复制
        self.tree1_btid_copy=self.tree1_btid
        self.tree_btid_copy=self.tree_btid
        self.tree1_btid_cut=""
        self.tree_btid_cut=""
    def menu_pop1_delete(self):  # 弹出菜单-从当前部门删除
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要删除的用户。", parent=self.topwindow)
            return()
        if bmmsgbox.askyesno("信息","您确认要从当前部门删除该用户吗？",parent=self.topwindow)==True:
            sql='select * from rt_relation where redeid<>\''+self.tree_btid+'\' and reruid=\''+ self.tree1_btid +'\''
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        if len(result)<=0:
            bmmsgbox.showerror("错误信息","该用户目前只在当前一个部门，不能删除。", parent=self.topwindow)
            return()
        sql='delete from rt_relation where redeid=\''+self.tree_btid+'\' and reruid=\''+ self.tree1_btid +'\''
        info=self.bmdb.execsql(sql)
        if info!='OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def menu_pop_paste(self):  # 弹出菜单-粘贴
        if self.tree1_btid_cut=="" and self.tree1_btid_copy=="":
            bmmsgbox.showerror("错误信息","请先剪切或者复制。", parent=self.topwindow)
            return()
        if self.tree1_btid_cut!="": # 剪切
            sql='update rt_relation set redeid=\''+ self.tree_btid + '\' where redeid=\''+self.tree_btid_cut+'\' and reruid=\''+ self.tree1_btid_cut +'\''
            info=self.bmdb.execsql(sql)
            if info!='OK':
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return()
            self.tree1_btid_cut=""
            self.tree_btid_cut=""
        else: # 复制
            sql='delete from rt_relation where redeid=\''+self.tree_btid+'\' and reruid=\''+ self.tree1_btid_copy +'\''
            sql=sql+'#*#*#*#*#*'+'insert into rt_relation(redeid,reruid)values(\''+ self.tree_btid + '\',\''+self.tree1_btid_copy+'\')'
            info=self.bmdb.execsql(sql)
            if info!='OK':
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return()
            self.tree1_btid_copy=""
            self.tree_btid_copy=""
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def add(self):  # 增加用户
        self.tree1_btid = ""
        self.entry_runame.delete(0, tk.END)
        self.entry_ruloid.delete(0, tk.END)
        self.entry_rupwd.delete(0, tk.END)
        self.entry_rupinyin.delete(0, tk.END)
        self.entry_rugonghao.delete(0, tk.END)
        self.entry_rushouji.delete(0, tk.END)
        self.entry_rushenfenzheng.delete(0, tk.END)
        self.entry_ruzhiwei.delete(0, tk.END)
        self.entry_rugongzi.delete(0, tk.END)
        self.combobox_ruxueli.current(2)
        self.combobox_ruxingbie.current(0)
        self.combobox_rulogflag.current(0)
        self.combobox_ruzaizhiflag.current(0)
        self.entry_ruruzhidate.delete(0, tk.END)
        self.entry_rulizhidate.delete(0, tk.END)
        self.entry_rubirthday.delete(0, tk.END)
        self.entry_ruzhuanye.delete(0, tk.END)
        self.entry_rutechang.delete(0, tk.END)
        self.entry_rugongzika.delete(0, tk.END)
        self.entry_rujiatingzhuzhi.delete(0, tk.END)
        self.entry_ruxianzhuzhi.delete(0, tk.END)
    def save(self):  # 保存用户
        ruid = self.tree1_btid
        redeid = self.tree_btid
        runame = self.entry_runame.get()
        rulogid = self.entry_ruloid.get()
        rupwd=self.entry_rupwd.get()
        rupinyin=self.entry_rupinyin.get()
        rugonghao=self.entry_rugonghao.get()
        rushouji=self.entry_rushouji.get()
        rushenfenzheng=self.entry_rushenfenzheng.get()
        ruzhiwei=self.entry_ruzhiwei.get()
        rugongzi=self.entry_rugongzi.get()
        try:
            float(rugongzi)
        except:
            bmmsgbox.showerror("错误信息","工资输入的不是数字。",parent=self.topwindow)
            return()
        ruxueli=self.var_combobox_ruxueli.get()
        ruxingbie=self.var_combobox_ruxingbie.get()
        rulogflag=self.var_combobox_rulogflag.get()
        ruzaizhiflag=self.var_combobox_ruzaizhiflag.get()
        ruruzhidate=self.entry_ruruzhidate.get()
        rulizhidate=self.entry_rulizhidate.get()
        rubirthday=self.entry_rubirthday.get()
        ruzhuanye=self.entry_ruzhuanye.get()
        rutechang=self.entry_rutechang.get()
        rugongzika=self.entry_rugongzika.get()
        rujiatingzhuzhi=self.entry_rujiatingzhuzhi.get()
        ruxianzhuzhi=self.entry_ruxianzhuzhi.get()
        if redeid == "":
            bmmsgbox.showerror("错误信息", "请选择部门。", parent=self.topwindow)
            return ()
        if runame == "":
            bmmsgbox.showerror("错误信息", "请输入姓名。", parent=self.topwindow)
            return ()
        if rulogid == "":
            bmmsgbox.showerror("错误信息", "请输入登录ID。", parent=self.topwindow)
            return ()
        if rupwd == "":
            bmmsgbox.showerror("错误信息", "请输入密码。", parent=self.topwindow)
            return ()
        if ruid == "":  # 增加记录
            info, ruid = self.bmdb.getfieldmaxid('rt_user', 'ruid','ru', 10)
            if info != 'OK':
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
            sql = 'insert into rt_user(ruid,runame,rulogid,rupwd,rupinyin,rugonghao,rushouji,rushenfenzheng,ruzhiwei,rugongzi,\
                   ruxueli,ruxingbie,rulogflag,ruzaizhiflag,ruruzhidate,rulizhidate,rubirthday,ruzhuanye,rutechang,rugongzika,rujiatingzhuzhi,ruxianzhuzhi)\
                values(\'' + ruid + '\',\'' + runame + '\',\'' + rulogid + '\',\'' + rupwd + '\',\'' + rupinyin + '\',\'' + rugonghao + \
                '\',\'' + rushouji + '\',\'' + rushenfenzheng + '\',\'' + ruzhiwei + '\',' + rugongzi + ',\'' + ruxueli + \
                '\',\'' + ruxingbie + '\',\'' + rulogflag + '\',\'' + ruzaizhiflag + '\',\'' + ruruzhidate + '\',\'' + rulizhidate + \
                '\',\'' + rubirthday + '\',\'' + ruzhuanye + '\',\'' + rutechang + '\',\'' + rugongzika + '\',\'' + rujiatingzhuzhi + \
                '\',\'' + ruxianzhuzhi + '\')'
            sql1 = 'insert into rt_relation(reruid,redeid)values(\'' + ruid + '\',\'' + redeid + '\')'
            sql=sql+'#*#*#*#*#*'+sql1
            info = self.bmdb.execsql(sql)
            if info != "OK":
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
        else:       # 修改记录
            #pass
            sql = 'update rt_user set runame=\'' + runame + '\',rulogid=\'' + rulogid  + '\',rupwd=\'' + rupwd + '\',rupinyin=\'' + rupinyin\
                 + '\',rugonghao=\'' + rugonghao + '\',rushouji=\'' + rushouji + '\',rushenfenzheng=\'' + rushenfenzheng\
                 + '\',ruzhiwei=\'' + ruzhiwei + '\',rugongzi=' + rugongzi + ',ruxueli=\'' + ruxueli + '\',ruxingbie=\'' + ruxingbie\
                 + '\',rulogflag=\'' + rulogflag + '\',ruzaizhiflag=\'' + ruzaizhiflag + '\',ruruzhidate=\'' + ruruzhidate\
                 + '\',rulizhidate=\'' + rulizhidate + '\',rubirthday=\'' + rubirthday + '\',ruzhuanye=\'' + ruzhuanye \
                 + '\',rutechang=\'' + rutechang + '\',rugongzika=\'' + rugongzika + '\',rujiatingzhuzhi=\'' + rujiatingzhuzhi\
                 + '\',ruxianzhuzhi=\'' + ruxianzhuzhi + '\' where ruid=\'' + ruid + '\''
            info = self.bmdb.execsql(sql)
            if info != "OK":
                bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
                return ()
        self.tree1_btid = ""
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def delete(self):  # 删除用户
        if self.tree1_btid == "":
            return ()
        if bmmsgbox.askyesno("信息", "您确认要删除这个用户吗？", parent=self.topwindow) == False:
            return ()
        # 判断该用户是否有财务流水记录
        sql = 'select cbid from cw_bill where cbruid=\'' + self.tree1_btid + '\''
        info, result = self.bmdb.getresult(sql)
        if info != "OK":
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return ()
        if len(result) > 0:
            bmmsgbox.showerror("错误信息", "该用户有财务流水记录，不能删除。", parent=self.topwindow)
            return ()
        # sql = 'select * from ' + self.detailtable + ' where ' + \
        #     self.detailtable_typeid + '=\'' + self.tree1_btid + '\''
        # info, result = self.bmdb.getresult(sql)
        # if info != "OK":
        #     bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
        #     return ()
        # if len(result) > 0:
        #     bmmsgbox.showerror("错误信息", "该" + self.bttype_name + "下有关联子表记录，不能删除。", parent=self.topwindow)
        #     return ()
        sql = 'delete from rt_user where ruid=\'' + self.tree1_btid + '\''
        sql=sql+'#*#*#*#*#*'+'delete from rt_relation where reruid=\'' + self.tree1_btid + '\''
        info = self.bmdb.execsql(sql)
        if info != "OK":
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return ()            
        self.tree1_btid = ""
        tree_btid = self.tree.selection()
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.selection_set(tree_btid)
        self.tree.see(self.tree.selection())
    def addright(self):  # 增加权限
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要增加权限的用户。",parent=self.topwindow)
            return()
        if len(self.tree_right.selection())<=0:
            bmmsgbox.showerror("错误信息","请选择要增加的权限。",parent=self.topwindow)
            return()
        aaa=list(self.tree_right.selection())
        bbb=aaa[0]
        sql='delete from rt_relation where reruid=\''+self.tree1_btid+'\' and reriid=\''+bbb+'\''
        sql1='insert into rt_relation(reruid,reriid)values(\''+ self.tree1_btid + '\',\''+ bbb + '\')'
        sql=sql+'#*#*#*#*#*'+sql1
        info = self.bmdb.execsql(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree1_btid=self.tree1_btid
        self.tree1.selection_set(tree1_btid)
    def deleteright(self):  # 删除权限
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要删除权限的用户。",parent=self.topwindow)
            return()
        tree_right1_id=self.tree_right1.selection()
        if len(tree_right1_id)<=0:
            bmmsgbox.showerror("错误信息","请选择要删除的权限。",parent=self.topwindow)
            return()
        aaa=list(tree_right1_id)
        bbb=aaa[0]
        sql='delete from rt_relation where reruid=\''+ self.tree1_btid + '\' and reriid=\''+ bbb + '\''
        info = self.bmdb.execsql(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree1_btid=self.tree1_btid
        self.tree1.selection_set(tree1_btid)
    def addrole(self):  # 增加角色
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要增加角色的用户。",parent=self.topwindow)
            return()
        if len(self.tree_role.selection())<=0:
            bmmsgbox.showerror("错误信息","请选择要增加的角色。",parent=self.topwindow)
            return()
        aaa=list(self.tree_role.selection())
        bbb=aaa[0]
        sql='delete from rt_relation where reruid=\''+self.tree1_btid+'\' and reroid=\''+bbb+'\''
        sql1='insert into rt_relation(reruid,reroid)values(\''+ self.tree1_btid + '\',\''+ bbb + '\')'
        sql=sql+'#*#*#*#*#*'+sql1
        info = self.bmdb.execsql(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree1_btid=self.tree1_btid
        self.tree1.selection_set(tree1_btid)
    def deleterole(self):  # 删除角色
        if self.tree1_btid=="":
            bmmsgbox.showerror("错误信息","请选择要删除角色的用户。",parent=self.topwindow)
            return()
        tree_role1_id=self.tree_role1.selection()
        if len(tree_role1_id)<=0:
            bmmsgbox.showerror("错误信息","请选择要删除的角色。",parent=self.topwindow)
            return()
        aaa=list(tree_role1_id)
        bbb=aaa[0]
        sql='delete from rt_relation where reruid=\''+ self.tree1_btid + '\' and reroid=\''+ bbb + '\''
        info = self.bmdb.execsql(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        tree1_btid=self.tree1_btid
        self.tree1.selection_set(tree1_btid)
    def searchuser(self):  # 查询用户
        for i in self.tree1.get_children():
            self.tree1.delete(i)
        rulogflag=self.var_combobox_logflag.get()
        ruzaizhiflag=self.var_combobox_zaizhiflag.get()
        runame=self.entry_search.get()
        sql = 'select * from rt_user where ruid in (select reruid from rt_relation where reruid!=\'\' and redeid=\'' + self.tree_btid + '\')'
        if rulogflag!="全部":
            sql=sql+' and rulogflag=\''+rulogflag+'\''
        if ruzaizhiflag!="全部":
            sql=sql+' and ruzaizhiflag=\''+ruzaizhiflag+'\''
        if runame!="":
            sql=sql+' and runame like \'%'+runame+'%\''
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        for i in result:
            self.tree1.insert('', 'end', str(i[0]), values=(str(i[1]),str(i[2]),str(i[3]),str(i[4]),str(i[5]),str(i[6])\
                ,str(i[7]),str(i[8]),str(i[9]),str(i[10]),str(i[11]),str(i[12]),str(i[13]),str(i[14]),str(i[15])\
                ,str(i[16]),str(i[17]),str(i[18]),str(i[19]),str(i[20]),str(i[21])))
        self.add()
    def refreshtree1(self, btid):  # 刷新self.tree1
        for i in self.tree1.get_children():
            self.tree1.delete(i)
        if len(btid)<=0:
            return()
        aaa = list(btid)
        bbb = str(aaa[0])
        self.tree_btid = bbb
        sql = 'select * from rt_user where ruid in (select reruid from rt_relation where reruid!=\'\' and redeid=\'' + bbb + '\')'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        for i in result:
            self.tree1.insert('', 'end', str(i[0]), values=(str(i[1]),str(i[2]),str(i[3]),str(i[4]),str(i[5]),str(i[6])\
                ,str(i[7]),str(i[8]),str(i[9]),str(i[10]),str(i[11]),str(i[12]),str(i[13]),str(i[14]),str(i[15])\
                ,str(i[16]),str(i[17]),str(i[18]),str(i[19]),str(i[20]),str(i[21])))
    def refreshtree_right1_role1_entrys(self, btid):  # 刷新self.tree_right1,self.tree_role1,entrys
        ############################清空控件############################################
        self.entry_runame.delete(0, tk.END)
        self.entry_ruloid.delete(0, tk.END)
        self.entry_rupwd.delete(0, tk.END)
        self.entry_rupinyin.delete(0, tk.END)
        self.entry_rugonghao.delete(0, tk.END)
        self.entry_rushouji.delete(0, tk.END)
        self.entry_rushenfenzheng.delete(0, tk.END)
        self.entry_ruzhiwei.delete(0, tk.END)
        self.entry_rugongzi.delete(0, tk.END)
        self.combobox_ruxueli.current(2)
        self.combobox_ruxingbie.current(0)
        self.combobox_rulogflag.current(0)
        self.combobox_ruzaizhiflag.current(0)
        self.entry_ruruzhidate.delete(0, tk.END)
        self.entry_rulizhidate.delete(0, tk.END)
        self.entry_rubirthday.delete(0, tk.END)
        self.entry_ruzhuanye.delete(0, tk.END)
        self.entry_rutechang.delete(0, tk.END)
        self.entry_rugongzika.delete(0, tk.END)
        self.entry_rujiatingzhuzhi.delete(0, tk.END)
        self.entry_ruxianzhuzhi.delete(0, tk.END)
        ############################清空控件############################################
        ############################清空self.tree_right1############################################
        for i in self.tree_right1.get_children():
            self.tree_right1.delete(i)
        ############################清空self.tree_right1############################################
        ############################清空self.tree_role1############################################
        for i in self.tree_role1.get_children():
            self.tree_role1.delete(i)
        ############################清空self.tree_role1############################################
        self.tree1_btid =""
        if len(btid)<=0:
            return()
        aaa = list(btid)
        bbb = str(aaa[0])
        self.tree1_btid = bbb
        ############################refresh entrys#######################################
        aaa = list(self.tree1.item(bbb).values())
        bbb = aaa[2]
        self.entry_runame.insert(tk.END, bbb[0])
        self.entry_ruloid.insert(tk.END, bbb[1])
        self.entry_rupwd.insert(tk.END, bbb[2])
        self.entry_rupinyin.insert(tk.END, bbb[3])
        self.entry_rugonghao.insert(tk.END, bbb[4])
        self.entry_rushouji.insert(tk.END, bbb[5])
        self.entry_rushenfenzheng.insert(tk.END, bbb[6])
        self.entry_ruzhiwei.insert(tk.END, bbb[7])
        self.entry_rugongzi.insert(tk.END, bbb[8])
        ccc=list(self.combobox_ruxueli['values'])
        for i in ccc:
            if i==bbb[9]:
                self.combobox_ruxueli.current(ccc.index(i))
        ccc=list(self.combobox_ruxingbie['values'])
        for i in ccc:
            if i==bbb[10]:
                self.combobox_ruxingbie.current(ccc.index(i))
        ccc=list(self.combobox_rulogflag['values'])
        for i in ccc:
            if i==bbb[11]:
                self.combobox_rulogflag.current(ccc.index(i))
        ccc=list(self.combobox_ruzaizhiflag['values'])
        for i in ccc:
            if i==bbb[12]:
                self.combobox_ruzaizhiflag.current(ccc.index(i))
        self.entry_ruruzhidate.insert(tk.END, bbb[13])
        self.entry_rulizhidate.insert(tk.END, bbb[14])
        self.entry_rubirthday.insert(tk.END, bbb[15])
        self.entry_ruzhuanye.insert(tk.END, bbb[16])
        self.entry_rutechang.insert(tk.END, bbb[17])
        self.entry_rugongzika.insert(tk.END, bbb[18])
        self.entry_rujiatingzhuzhi.insert(tk.END, bbb[19])
        self.entry_ruxianzhuzhi.insert(tk.END, bbb[20])
        ############################refresh entrys#######################################
        ############################refresh tree_right1#######################################
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'ri\' and btid in (select reriid from rt_relation where reruid=\'' + self.tree1_btid + '\') order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        for i in result:
            self.tree_right1.insert('', 'end', str(i[0]), values=(str(i[2])))
        ############################refresh tree_right1#######################################
        ############################refresh tree_role1#######################################
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'ro\' and btid in (select reroid from rt_relation where reruid=\'' + self.tree1_btid + '\') order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        for i in result:
            self.tree_role1.insert('', 'end', str(i[0]), values=(str(i[2])))
        ############################refresh tree_role1#######################################
    def showwindow(self, rootwindow):  # 显示窗口
        self.getwindow(rootwindow)
        #########self.frame_tree.place(x=10, y=10, width=250, height=770)###############
        self.topwindow.title(self.bttype_name)
        self.topwindow.geometry('1400x800+100+50')
        self.frame_tree = tk.Frame(self.topwindow)
        self.frame_tree.place(x=10, y=10, width=250, height=770)
        self.tree_xscroll = tk.Scrollbar(self.frame_tree,orient=tk.HORIZONTAL)
        self.tree_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_yscroll = tk.Scrollbar(self.frame_tree,orient=tk.VERTICAL)
        self.tree_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree = tk.ttk.Treeview(self.frame_tree,show='tree' ,selectmode = 'browse')
        self.tree.config(xscrollcommand=self.tree_xscroll.set)
        self.tree.config(yscrollcommand=self.tree_yscroll.set)
        self.tree_xscroll.config(command=self.tree.xview)
        self.tree_yscroll.config(command=self.tree.yview)
        self.tree.place(x=0, y=0, width=238, height=758)
        self.tree.bind("<<TreeviewSelect>>", lambda event: self.refreshtree1(self.tree.selection()))  # 绑定TreeViewSelect事件
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            'bttype=\'' + self.btpre + '\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree,result)
        self.tree.column('#0',width=800,stretch=False)
        ##########self.frame_tree.place(x=10, y=10, width=250, height=770)###############
        ##########self.frame_search.place(x=270, y=10, width=1120, height=50)#############
        self.frame_search = tk.Frame(self.topwindow)
        self.frame_search.place(x=270, y=10, width=1120, height=50)
        self.lable_combobox_logflag = tk.Label(self.frame_search, text="登录状态：", anchor='e')
        self.lable_combobox_logflag.place(x=0, y=10, width=80, height=30)
        self.var_combobox_logflag=tk.StringVar()
        self.combobox_logflag=tk.ttk.Combobox(self.frame_search,textvariable=self.var_combobox_logflag)
        self.combobox_logflag.place(x=80, y=10, width=60, height=30)
        self.combobox_logflag['values']=('全部','正常','禁用')
        self.combobox_logflag.current(0)
        self.lable_combobox_zaizhiflag = tk.Label(self.frame_search, text="在职状态：", anchor='e')
        self.lable_combobox_zaizhiflag.place(x=140, y=10, width=80, height=30)
        self.var_combobox_zaizhiflag=tk.StringVar()
        self.combobox_zaizhiflag=tk.ttk.Combobox(self.frame_search,textvariable=self.var_combobox_zaizhiflag)
        self.combobox_zaizhiflag.place(x=220, y=10, width=60, height=30)
        self.combobox_zaizhiflag['values']=('全部','在职','离职')
        self.combobox_zaizhiflag.current(0)
        self.lable_search = tk.Label(self.frame_search, text="请输入：", anchor='e')
        self.lable_search.place(x=280, y=10, width=60, height=30)
        self.entry_search = tk.Entry(self.frame_search)
        self.entry_search.place(x=340, y=10, width=300, height=30)   
        self.button_add = tk.Button(self.frame_search, text='查询', command=self.searchuser)
        self.button_add.place(x=660, y=10, width=70, height=30)
        ##########self.frame_search.place(x=270, y=10, width=1120, height=50)#############
        ##########self.frame_tree1.place(x=270, y=60, width=1120, height=260)#############
        self.frame_tree1 = tk.Frame(self.topwindow)
        self.frame_tree1.place(x=270, y=60, width=1120, height=260)
        self.tree1_xscroll = tk.Scrollbar(self.frame_tree1,orient=tk.HORIZONTAL)
        self.tree1_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree1_yscroll = tk.Scrollbar(self.frame_tree1)
        self.tree1_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        columns = ("姓名","登录ID","密码","拼音码","工号","手机","身份证","职位", \
                    "工资","学历","性别","登录状态","在职状态","入职日期","离职日期","生日", \
                  "专业","特长","工资卡","家庭住址","现住址")
        self.tree1 = tk.ttk.Treeview(self.frame_tree1, show="headings", columns=columns, selectmode = 'browse')   # 创建树状对象
        self.tree1.column("姓名", width=80, anchor='center',stretch=False)
        self.tree1.column("登录ID", width=80, anchor='center',stretch=False)  # 表示列,不显示
        self.tree1.column("密码", width=80, anchor='center',stretch=False)
        self.tree1.column("拼音码", width=80, anchor='center',stretch=False)
        self.tree1.column("工号", width=80, anchor='center',stretch=False)
        self.tree1.column("手机", width=120, anchor='center',stretch=False)
        self.tree1.column("身份证", width=180, anchor='center',stretch=False)
        self.tree1.column("职位", width=80, anchor='center',stretch=False)
        self.tree1.column("工资", width=80, anchor='center',stretch=False)
        self.tree1.column("学历", width=80, anchor='center',stretch=False)
        self.tree1.column("性别", width=80, anchor='center',stretch=False)
        self.tree1.column("登录状态", width=80, anchor='center',stretch=False)
        self.tree1.column("在职状态", width=80, anchor='center',stretch=False)
        self.tree1.column("入职日期", width=90, anchor='center',stretch=False)
        self.tree1.column("离职日期", width=90, anchor='center',stretch=False)
        self.tree1.column("生日", width=90, anchor='center',stretch=False)
        self.tree1.column("专业", width=80, anchor='center',stretch=False)
        self.tree1.column("特长", width=80, anchor='center',stretch=False)
        self.tree1.column("工资卡", width=200, anchor='center',stretch=False)
        self.tree1.column("家庭住址", width=300, anchor='center',stretch=False)
        self.tree1.column("现住址", width=300, anchor='center',stretch=False)

        self.tree1.heading("姓名", text="姓名")
        self.tree1.heading("登录ID", text="登录ID")
        self.tree1.heading("密码", text="密码")
        self.tree1.heading("拼音码", text="拼音码")
        self.tree1.heading("工号", text="工号")
        self.tree1.heading("手机", text="手机")
        self.tree1.heading("身份证", text="身份证")
        self.tree1.heading("职位", text="职位")
        self.tree1.heading("工资", text="工资")
        self.tree1.heading("学历", text="学历")
        self.tree1.heading("性别", text="性别")
        self.tree1.heading("登录状态", text="登录状态")
        self.tree1.heading("在职状态", text="在职状态")
        self.tree1.heading("入职日期", text="入职日期")
        self.tree1.heading("离职日期", text="离职日期")
        self.tree1.heading("生日", text="生日")
        self.tree1.heading("专业", text="专业")
        self.tree1.heading("特长", text="特长")
        self.tree1.heading("工资卡", text="工资卡")
        self.tree1.heading("家庭住址", text="家庭住址")
        self.tree1.heading("现住址", text="现住址")
        self.tree1.place(x=0, y=0, width=1108, height=248)
        self.tree1.bind("<<TreeviewSelect>>", lambda event: self.refreshtree_right1_role1_entrys(self.tree1.selection()))  # 绑定TreeViewSelect事件
        self.tree1.config(xscrollcommand=self.tree1_xscroll.set)
        self.tree1.config(yscrollcommand=self.tree1_yscroll.set)
        self.tree1_xscroll.config(command=self.tree1.xview)
        self.tree1_yscroll.config(command=self.tree1.yview)
        ##########self.frame_tree1.place(x=270, y=60, width=1120, height=260)#############
        ##########self.frame_edit.place(x=270, y=340, width=1120, height=150)###########
        # 第一行控件
        self.frame_edit = tk.Frame(self.topwindow)
        self.frame_edit.place(x=270, y=340, width=1120, height=150)
        self.lable_runame = tk.Label(self.frame_edit, text="姓名：", anchor='e')
        self.lable_runame.place(x=0, y=0, width=60, height=30)
        self.entry_runame = tk.Entry(self.frame_edit)
        self.entry_runame.place(x=60, y=0, width=60, height=30)
        self.lable_rulogid = tk.Label(self.frame_edit, text="登录ID：", anchor='e')
        self.lable_rulogid.place(x=120, y=0, width=60, height=30)
        self.entry_ruloid = tk.Entry(self.frame_edit)
        self.entry_ruloid.place(x=180, y=0, width=60, height=30)
        self.lable_rupwd = tk.Label(self.frame_edit, text="密码：", anchor='e')
        self.lable_rupwd.place(x=240, y=0, width=60, height=30)
        self.entry_rupwd = tk.Entry(self.frame_edit)
        self.entry_rupwd.place(x=300, y=0, width=60, height=30)
        self.lable_rupinyin = tk.Label(self.frame_edit, text="拼音码：", anchor='e')
        self.lable_rupinyin.place(x=360, y=0, width=60, height=30)
        self.entry_rupinyin = tk.Entry(self.frame_edit)
        self.entry_rupinyin.place(x=420, y=0, width=60, height=30)
        self.lable_rugonghao = tk.Label(self.frame_edit, text="工号：", anchor='e')
        self.lable_rugonghao.place(x=480, y=0, width=60, height=30)
        self.entry_rugonghao = tk.Entry(self.frame_edit)
        self.entry_rugonghao.place(x=540, y=0, width=60, height=30)
        self.lable_rushouji = tk.Label(self.frame_edit, text="手机：", anchor='e')
        self.lable_rushouji.place(x=600, y=0, width=60, height=30)
        self.entry_rushouji = tk.Entry(self.frame_edit)
        self.entry_rushouji.place(x=660, y=0, width=100, height=30)
        self.lable_rushenfenzheng = tk.Label(self.frame_edit, text="身份证：", anchor='e')
        self.lable_rushenfenzheng.place(x=760, y=0, width=60, height=30)
        self.entry_rushenfenzheng = tk.Entry(self.frame_edit)
        self.entry_rushenfenzheng.place(x=820, y=0, width=160, height=30)
        self.lable_ruzhiwei = tk.Label(self.frame_edit, text="职位：", anchor='e')
        self.lable_ruzhiwei.place(x=980, y=0, width=60, height=30)
        self.entry_ruzhiwei = tk.Entry(self.frame_edit)
        self.entry_ruzhiwei.place(x=1040, y=0, width=70, height=30)
        # 第二行控件
        self.lable_rugongzi = tk.Label(self.frame_edit, text="工资：", anchor='e')
        self.lable_rugongzi.place(x=0, y=40, width=60, height=30)
        self.entry_rugongzi = tk.Entry(self.frame_edit)
        self.entry_rugongzi.place(x=60, y=40, width=60, height=30)
        self.lable_ruxueli = tk.Label(self.frame_edit, text="学历：", anchor='e')
        self.lable_ruxueli.place(x=120, y=40, width=60, height=30)
        self.var_combobox_ruxueli=tk.StringVar()
        self.combobox_ruxueli=tk.ttk.Combobox(self.frame_edit,textvariable=self.var_combobox_ruxueli)
        self.combobox_ruxueli.place(x=180, y=40, width=60, height=30)
        self.combobox_ruxueli['values']=('博士','硕士','本科','大专','中专','高中','初中','小学','文盲')
        self.combobox_ruxueli.current(2)
        self.lable_ruxingbie = tk.Label(self.frame_edit, text="性别：", anchor='e')
        self.lable_ruxingbie.place(x=240, y=40, width=60, height=30)
        self.var_combobox_ruxingbie=tk.StringVar()
        self.combobox_ruxingbie=tk.ttk.Combobox(self.frame_edit,textvariable=self.var_combobox_ruxingbie)
        self.combobox_ruxingbie.place(x=300, y=40, width=60, height=30)
        self.combobox_ruxingbie['values']=('男','女')
        self.combobox_ruxingbie.current(0)
        self.lable_rulogflag = tk.Label(self.frame_edit, text="登录状态：", anchor='e')
        self.lable_rulogflag.place(x=360, y=40, width=80, height=30)
        self.var_combobox_rulogflag=tk.StringVar()
        self.combobox_rulogflag=tk.ttk.Combobox(self.frame_edit,textvariable=self.var_combobox_rulogflag)
        self.combobox_rulogflag.place(x=440, y=40, width=60, height=30)
        self.combobox_rulogflag['values']=('正常','禁用')
        self.combobox_rulogflag.current(0)
        self.lable_ruzaizhiflag = tk.Label(self.frame_edit, text="在职状态：", anchor='e')
        self.lable_ruzaizhiflag.place(x=500, y=40, width=80, height=30)
        self.var_combobox_ruzaizhiflag=tk.StringVar()
        self.combobox_ruzaizhiflag=tk.ttk.Combobox(self.frame_edit,textvariable=self.var_combobox_ruzaizhiflag)
        self.combobox_ruzaizhiflag.place(x=580, y=40, width=60, height=30)
        self.combobox_ruzaizhiflag['values']=('在职','离职')
        self.combobox_ruzaizhiflag.current(0)
        self.lable_ruruzhidate = tk.Label(self.frame_edit, text="入职日期：", anchor='e')
        self.lable_ruruzhidate.place(x=640, y=40, width=80, height=30)
        self.entry_ruruzhidate = tk.Entry(self.frame_edit)
        self.entry_ruruzhidate.place(x=720, y=40, width=80, height=30)
        self.lable_rulizhidate = tk.Label(self.frame_edit, text="离职日期：", anchor='e')
        self.lable_rulizhidate.place(x=800, y=40, width=80, height=30)
        self.entry_rulizhidate = tk.Entry(self.frame_edit)
        self.entry_rulizhidate.place(x=880, y=40, width=80, height=30)
        self.lable_rubirthday = tk.Label(self.frame_edit, text="生日：", anchor='e')
        self.lable_rubirthday.place(x=960, y=40, width=60, height=30)
        self.entry_rubirthday = tk.Entry(self.frame_edit)
        self.entry_rubirthday.place(x=1020, y=40, width=90, height=30)
        # 第三行控件
        self.lable_ruzhuanye = tk.Label(self.frame_edit, text="专业：", anchor='e')
        self.lable_ruzhuanye.place(x=0, y=80, width=60, height=30)
        self.entry_ruzhuanye = tk.Entry(self.frame_edit)
        self.entry_ruzhuanye.place(x=60, y=80, width=60, height=30)
        self.lable_rutechang = tk.Label(self.frame_edit, text="特长：", anchor='e')
        self.lable_rutechang.place(x=120, y=80, width=60, height=30)
        self.entry_rutechang = tk.Entry(self.frame_edit)
        self.entry_rutechang.place(x=180, y=80, width=100, height=30)
        self.lable_rugongzika = tk.Label(self.frame_edit, text="工资卡：", anchor='e')
        self.lable_rugongzika.place(x=280, y=80, width=60, height=30)
        self.entry_rugongzika = tk.Entry(self.frame_edit)
        self.entry_rugongzika.place(x=340, y=80, width=200, height=30)
        self.lable_rujiatingzhuzhi = tk.Label(self.frame_edit, text="家庭住址：", anchor='e')
        self.lable_rujiatingzhuzhi.place(x=540, y=80, width=80, height=30)
        self.entry_rujiatingzhuzhi = tk.Entry(self.frame_edit)
        self.entry_rujiatingzhuzhi.place(x=620, y=80, width=210, height=30)
        self.lable_ruxianzhuzhi = tk.Label(self.frame_edit, text="现住址：", anchor='e')
        self.lable_ruxianzhuzhi.place(x=830, y=80, width=60, height=30)
        self.entry_ruxianzhuzhi = tk.Entry(self.frame_edit)
        self.entry_ruxianzhuzhi.place(x=890, y=80, width=220, height=30)
        # 按钮
        self.button_add = tk.Button(self.frame_edit, text='增加', command=self.add)
        self.button_add.place(x=690, y=120, width=70, height=30)
        self.button_save = tk.Button(self.frame_edit, text='保存', command=self.save)
        self.button_save.place(x=780, y=120, width=70, height=30)
        self.button_delete = tk.Button(self.frame_edit, text='删除', command=self.delete)
        self.button_delete.place(x=870, y=120, width=70, height=30)
        self.button_exit = tk.Button(self.frame_edit, text='退出',command=self.destroywindow)
        self.button_exit.place(x=1040, y=120, width=70, height=30)
        ##########self.frame_edit.place(x=270, y=340, width=1120, height=150)###########
        ##########self.frame_tree_right.place(x=270, y=500, width=215, height=280)###########
        self.frame_tree_right = tk.Frame(self.topwindow)
        self.frame_tree_right.place(x=270, y=500, width=215, height=280)
        self.tree_right_xscroll = tk.Scrollbar(self.frame_tree_right,orient=tk.HORIZONTAL)
        self.tree_right_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_right_yscroll = tk.Scrollbar(self.frame_tree_right)
        self.tree_right_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_right = tk.ttk.Treeview(self.frame_tree_right,show='tree' ,selectmode = 'browse')
        self.tree_right.place(x=0, y=0, width=203, height=268)
        self.tree_right.config(xscrollcommand=self.tree_right_xscroll.set)
        self.tree_right.config(yscrollcommand=self.tree_right_yscroll.set)
        self.tree_right_xscroll.config(command=self.tree_right.xview)
        self.tree_right_yscroll.config(command=self.tree_right.yview)
        self.tree_right.column('#0',width=800,stretch=False)
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'ri\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree_right,result)
        ##########self.frame_tree_right.place(x=270, y=500, width=215, height=280)###########
        ##########self.frame_button_right.place(x=485, y=500, width=120, height=280)###########
        self.frame_button_right = tk.Frame(self.topwindow)
        self.frame_button_right.place(x=485, y=500, width=120, height=280)
        self.button_rightadd = tk.Button(self.frame_button_right, text='增加', command=self.addright)
        self.button_rightadd.place(x=25, y=80, width=70, height=30)
        self.button_rightdelete = tk.Button(self.frame_button_right, text='删除', command=self.deleteright)
        self.button_rightdelete.place(x=25, y=170, width=70, height=30)
        ##########self.frame_button_right.place(x=485, y=500, width=120, height=280)###########
        ##########self.frame_tree_right1.place(x=605, y=500, width=215, height=280)###########
        self.frame_tree_right1 = tk.Frame(self.topwindow)
        self.frame_tree_right1.place(x=605, y=500, width=215, height=280)
        self.tree_right1_xscroll = tk.Scrollbar(self.frame_tree_right1,orient=tk.HORIZONTAL)
        self.tree_right1_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_right1_yscroll = tk.Scrollbar(self.frame_tree_right1)
        self.tree_right1_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        columns = ("权限名称")
        self.tree_right1 = tk.ttk.Treeview(self.frame_tree_right1, show="headings", columns=columns)   # 创建树状对象
        self.tree_right1.place(x=0, y=0, width=203, height=268)
        self.tree_right1.column("权限名称", width=203, anchor='center')
        self.tree_right1.heading("权限名称", text="权限名称")
        self.tree_right1.config(xscrollcommand=self.tree_right1_xscroll.set)
        self.tree_right1.config(yscrollcommand=self.tree_right1_yscroll.set)
        self.tree_right1_xscroll.config(command=self.tree_right1.xview)
        self.tree_right1_yscroll.config(command=self.tree_right1.yview)
        ##########self.frame_tree_right1.place(x=605, y=500, width=215, height=280)###########
        ##########self.frame_tree_role.place(x=840, y=500, width=215, height=280)###########
        self.frame_tree_role = tk.Frame(self.topwindow)
        self.frame_tree_role.place(x=840, y=500, width=215, height=280)
        self.tree_role_xscroll = tk.Scrollbar(self.frame_tree_role,orient=tk.HORIZONTAL)
        self.tree_role_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_role_yscroll = tk.Scrollbar(self.frame_tree_role)
        self.tree_role_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_role = tk.ttk.Treeview(self.frame_tree_role,show='tree' ,selectmode = 'browse')
        self.tree_role.place(x=0, y=0, width=203, height=268)
        self.tree_role.config(xscrollcommand=self.tree_role_xscroll.set)
        self.tree_role.config(yscrollcommand=self.tree_role_yscroll.set)
        self.tree_role_xscroll.config(command=self.tree_role.xview)
        self.tree_role_yscroll.config(command=self.tree_role.yview)
        self.tree_role.column('#0',width=800,stretch=False)
        sql = 'select btid,btpid,btname,btorder from bm_type where ' +  \
            ' bttype=\'ro\' order by btorder'
        info, result = self.bmdb.getresult(sql)
        if info != 'OK':
            bmmsgbox.showerror("错误信息", info, parent=self.topwindow)
            return()
        self.refreshtree(self.tree_role,result)
        ##########self.frame_tree_role.place(x=840, y=500, width=215, height=280)###########
        ##########self.frame_button_right.place(x=1055, y=500, width=120, height=280)###########
        self.frame_button_role = tk.Frame(self.topwindow)
        self.frame_button_role.place(x=1055, y=500, width=120, height=280)
        self.button_roleadd = tk.Button(self.frame_button_role, text='增加', command=self.addrole)
        self.button_roleadd.place(x=25, y=80, width=70, height=30)
        self.button_roledelete = tk.Button(self.frame_button_role, text='删除', command=self.deleterole)
        self.button_roledelete.place(x=25, y=170, width=70, height=30)
        ##########self.frame_button_role.place(x=1055, y=500, width=120, height=280)###########
        ##########self.frame_tree_role1.place(x=1175, y=500, width=215, height=280)###########
        self.frame_tree_role1 = tk.Frame(self.topwindow)
        self.frame_tree_role1.place(x=1175, y=500, width=215, height=280)
        self.tree_role1_xscroll = tk.Scrollbar(self.frame_tree_role1,orient=tk.HORIZONTAL)
        self.tree_role1_xscroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.tree_role1_yscroll = tk.Scrollbar(self.frame_tree_role1)
        self.tree_role1_yscroll.pack(side=tk.RIGHT, fill=tk.Y)
        columns = ("角色名称")
        self.tree_role1 = tk.ttk.Treeview(self.frame_tree_role1, show="headings", columns=columns)   # 创建树状对象
        self.tree_role1.place(x=0, y=0, width=203, height=268)
        self.tree_role1.column("角色名称", width=203, anchor='center')
        self.tree_role1.heading("角色名称", text="角色名称")
        self.tree_role1.config(xscrollcommand=self.tree_role1_xscroll.set)
        self.tree_role1.config(yscrollcommand=self.tree_role1_yscroll.set)
        self.tree_role1_xscroll.config(command=self.tree_role1.xview)
        self.tree_role1_yscroll.config(command=self.tree_role1.yview)
        ##########self.frame_tree_role1.place(x=1175, y=500, width=215, height=280)###########
        #################################弹出菜单###################################
        menu_pop = tk.Menu(self.tree,tearoff=False)
        menu_pop.add_command(label="粘贴", command=self.menu_pop_paste)
        menu_pop.add_separator()# 分割线
        menu_pop.add_command(label="退出", command=menu_pop.unpost)
        def popup_menu(event):
            menu_pop.post(event.x_root, event.y_root)# post在指定的位置显示弹出菜单
        self.tree.bind("<Button-3>", popup_menu)# 绑定鼠标右键,执行popup_Menu函数

        menu_pop1 = tk.Menu(self.tree1,tearoff=False)
        menu_pop1.add_command(label="剪切", command=self.menu_pop1_cut)
        menu_pop1.add_command(label="复制", command=self.menu_pop1_copy)
        menu_pop1.add_command(label="从当前部门删除", command=self.menu_pop1_delete)
        menu_pop1.add_separator()# 分割线
        menu_pop1.add_command(label="退出", command=menu_pop1.unpost)
        def popup_menu1(event):
            menu_pop1.post(event.x_root, event.y_root)# post在指定的位置显示弹出菜单
        self.tree1.bind("<Button-3>", popup_menu1)# 绑定鼠标右键,执行popup_Menu函数
        #################################弹出菜单###################################
        # 显示窗口
        self.topwindow.mainloop()
##########################用户管理类###################################

