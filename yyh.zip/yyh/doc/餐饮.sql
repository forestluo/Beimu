-------------------------------�������ݲ��ֵı�--------------------------------------------------------------
--��ҵ��Ϣ�� 
create table unitech_qyxx(
uqrfnbr 		varchar(10)  not null primary key, 
uqname_cn 		varchar(50), 
uqname_en 		varchar(100), 
uqaddress_cn 		varchar(100), 
uqaddress_en		varchar(100),
uqzhuying 		varchar(50),
uqfaren 		varchar(50), 
uqlinkphone 		varchar(50), 
uqkhh			varchar(50), 
uqshuihao		varchar(50)
); 

--��Ʒ���� 
drop table unitech_splb;
create table unitech_splb( 
usrfnbr 		varchar(10) not null primary key, 
ustype			varchar(50), 
usname 			varchar(50),
usorder			int,
usggsl			varchar(10)
);

--��Ʒ��
drop table unitech_sp��
create table unitech_sp(
sprfnbr 		varchar(10)  not null primary key,
spusnbr 		varchar(10),
spyxnum 		varchar(10),
spzjnum 		varchar(10),
spname_cn 		varchar(50),
spname_en 		varchar(100),
spunit 			varchar(10),
spunit2 		varchar(10),
spprice			decimal(12,2) default 0,
spticheng		decimal(12,2) default 0,
spjqprice		decimal(12,2) default 0,
spdazhe                 varchar(10),
sptype			varchar(10),
spkjflag		varchar(10),
spsctime		decimal(12,2) default 0,
constraint sp_spusnbr foreign key(spusnbr) references unitech_splb(usrfnbr) on delete cascade
);

--��Ʒ���ϱ�
drop table unitech_sppl;
create table unitech_sppl(
slrfnbr 		varchar(10)  not null primary key,
slspnbr 		varchar(10),
slylnbr 		varchar(10),
slylname		varchar(50),
slunit	 		varchar(10),
slmany			decimal(9,2) default 0,
slunit2	 		varchar(10),
slmany2			decimal(9,2) default 0,
constraint sppl_slspnbr foreign key(slspnbr) references unitech_sp(sprfnbr) on delete cascade
);
--�۸񷽰����� 
drop table unitech_prices;
create table unitech_prices( 
psrfnbr 		varchar(10) not null primary key, 
psname 			varchar(50),
psselect		varchar(10)
);
--�۸񷽰��ӱ� 
drop table unitech_pricedetail;
create table unitech_pricedetail( 
pdrfnbr 		varchar(10) not null primary key, 
pdpsnbr			varchar(10),
pdspnbr			varchar(10),
pdprice 		decimal(10,2) default 0,
constraint pdps_pdpsnbr foreign key(pdpsnbr) references unitech_prices(psrfnbr) on delete cascade
);
--�ײ���ϸ��
drop table unitech_tcmx;
create table unitech_tcmx(
tcrfnbr 		varchar(10)  not null primary key,
tcspnbr 		varchar(10),
tcmxnbr 		varchar(10),
tcmany			decimal(10,2) default 0,
tcmany2			decimal(10,2) default 0,
constraint tcmx_tcspnbr foreign key(tcspnbr) references unitech_sp(sprfnbr) on delete cascade
);

--�������
create table unitech_sy(
syrfnbr 		varchar(10)  not null primary key,
syname 			varchar(50),
syprnbr 		varchar(10),
syprname 		varchar(100),
syorder			int
);

--̨�ű�
create table unitech_th(
thrfnbr 		varchar(10)  not null primary key,
thzjmnum 		varchar(10),
thsynbr 		varchar(10),
thtainum 		varchar(10),
thwaiter 		varchar(20),
thtaiweiflag		varchar(20),
thtop			dec(12,0) default 0,
thleft			dec(12,0) default 0,
thicon 			varchar(20) default '',
constraint th_thsynbr foreign key(thsynbr) references unitech_sy(syrfnbr) on delete cascade
);

--̨λ���ַ�����
create table unitech_thposition(
tprfnbr 		varchar(10)  not null primary key,
tpname 			varchar(100),
tpbkpicture 		varchar(200),
tptitle_color 		varchar(20),
tptitle_size 		varchar(20),
tptitle_font 		varchar(20),
tpbdbj_color		varchar(20),
tpbdfont_color		varchar(20),
tpct_color		varchar(20),
tptwzy			varchar(200),
tptwkt			varchar(200)
);

--̨λ���ַ�����ϸ��
create table unitech_thdetail(
tdrfnbr 		varchar(10)  not null primary key,
tdtpnbr 		varchar(10),
tdthnbr 		varchar(10),
tdtop			dec(12,0) default 0,
tdleft			dec(12,0) default 0,
constraint td_tdtpnbr foreign key(tdtpnbr) references unitech_thposition(tprfnbr) on delete cascade,
constraint td_tdthnbr foreign key(tdthnbr) references unitech_th(thrfnbr) on delete cascade
);

--PDĄλ���ַ�����
drop table unitech_thpositionPDA;
create table unitech_thpositionPDA(
tprfnbr 		varchar(10)  not null primary key,
tpname 			varchar(100),
tpbkpicture 		varchar(200),
tptitle_color 		varchar(20),
tptitle_size 		varchar(20),
tptitle_font 		varchar(20),
tpbdbj_color		varchar(20),
tpbdfont_color		varchar(20),
tpct_color		varchar(20),
tptwzy			varchar(200),
tptwkt			varchar(200)
);

--PDĄλ���ַ�����ϸ��
create table unitech_thdetailPDA(
tdrfnbr 		varchar(10)  not null primary key,
tdtpnbr 		varchar(10),
tdthnbr 		varchar(10),
tdtop			dec(12,0) default 0,
tdleft			dec(12,0) default 0,
constraint td_tdtpnbrPDA foreign key(tdtpnbr) references unitech_thpositionPDA(tprfnbr) on delete cascade,
constraint td_tdthnbrPDA foreign key(tdthnbr) references unitech_th(thrfnbr) on delete cascade
);


--���ʷ�ʽ��
create table unitech_jsfs(
ujrfnbr 		varchar(10)  not null primary key,
ujname	 		varchar(50),
ujsx			int
);

--������
create table unitech_zf(
zfrfnbr 		varchar(10) not null primary key,
zfname	 		varchar(50),
zforder			int default 0	
);


--�ۿ��ʹ�����
create table unitech_zkl(
zkrfnbr			varchar(10) not null primary key,
zkbigname 		varchar(50),
zksmallname		int,
zksx			int
);

--�ۿ۱�����ʱ��
drop table unitech_zkls;
create table unitech_zkls(
zkspname		varchar(50),
zkpjzqjine		decimal(12,2) default 0,
zkpjzhjine		decimal(12,2) default 0,
zkpjzkl			decimal(12,2) default 0,
);

--�˲�ԭ���
create table unitech_tcyy(
utrfnbr 		varchar(10) not null primary key,
utchengben		varchar(10),
utname			varchar(100),
utorder			int
);

create table unitech_zs(
zsrfnbr 		varchar(10) not null primary key,
zsname			varchar(100)
);

--�ⷿ��
create table unitech_fkf(
fkrfnbr	 		varchar(10) not null primary key,
fkname			varchar(50),
fkprnbr 		varchar(10),
fkprname 		varchar(100),
fkdesc			varchar(50),
fkorder			int
);

--���˲���
create table unitech_ccb(
ccbrfnbr	 	varchar(10) not null primary key,
ccbname			varchar(50),
ccbprnbr 		varchar(10),
ccbprname 		varchar(100),
ccbdesc			varchar(50)
);

--��Ʒ����ⷿ��ϵ������ӡ���ã�
drop table unitech_sfrelation;
create table unitech_sfrelation(
sffknbr	 		varchar(10),
constraint sf_sffknbr foreign key(sffknbr) references unitech_fkf(fkrfnbr) on delete cascade,
sfusnbr			varchar(10),
constraint sf_sfusnbr foreign key(sfusnbr) references unitech_splb(usrfnbr) on delete cascade
);
--��Ʒ����ⷿ��ϵ������ѯͳ�����ã�
drop table unitech_sfrelation1;
create table unitech_sfrelation1(
sffknbr	 		varchar(10),
constraint sf_sffknbr1 foreign key(sffknbr) references unitech_fkf(fkrfnbr) on delete cascade,
sfusnbr			varchar(10),
constraint sf_sfusnbr1 foreign key(sfusnbr) references unitech_splb(usrfnbr) on delete cascade
);

--��������ⷿ��ϵ��
create table unitech_syfrelation(
syffknbr	 	varchar(10),
constraint sy_syffknbr foreign key(syffknbr) references unitech_fkf(fkrfnbr) on delete cascade,
syfsynbr		varchar(10),
constraint sy_syfsynbr foreign key(syfsynbr) references unitech_sy(syrfnbr) on delete cascade
);

--���˲���ⷿ��ϵ��
create table unitech_ckrelation(
ckfknbr		 	varchar(10),
constraint ck_ckfknbr foreign key(ckfknbr) references unitech_fkf(fkrfnbr) on delete cascade,
ckccbnbr		varchar(10),
constraint ck_ckccbnbr foreign key(ckccbnbr) references unitech_ccb(ccbrfnbr) on delete cascade
);

--��Ӧ������
create table unitech_gyslb( 
ugrfnbr 		varchar(10) not null primary key, 
ugname 			varchar(50) 
);

--��Ӧ�̱�
drop table unitech_ghs
create table unitech_ghs(
hgrfnbr 		varchar(10) not null primary key,
hgugnbr			varchar(10),
hgname	 		varchar(100),
hgtel			varchar(50),
hgaddress		varchar(200),
hgdate			datetime,
hgdesc			varchar(200),
hgmobile		varchar(50),
hglink			varchar(50),
hgyfye			dec(12,2),
hgemail			Varchar(100),
hgtex			varchar(50),
hgyb			Varchar(10),
constraint ghs_hgugnbr foreign key(hgugnbr) references unitech_gyslb(ugrfnbr) on delete cascade
);



--��λ��
create table unitech_unit(
uurfnbr 		varchar(10) not null primary key,
uuname	 		varchar(50)	
);

--��������
drop table unitech_cxlb;
create table unitech_cxlb(
cxrfnbr			varchar(10) not null primary key,
cxname	 		varchar(50)	
);

--������Ʒ������
drop table unitech_cxspgl;
create table unitech_cxspgl(
ucrfnbr 		varchar(10) not null primary key,
uccxnbr	 		varchar(10),	
ucusnbr 		varchar(10),	
constraint uc_uccxnbr foreign key(uccxnbr) references unitech_cxlb(cxrfnbr) on delete cascade,
constraint uc_ucusnbr foreign key(ucusnbr) references unitech_splb(usrfnbr) on delete cascade
);

--�����ӱ�����������Ĺ�ϵ��
drop table unitech_screlation;
create table unitech_screlation(
scdenbr 		varchar(20),
sccxnbr	 		varchar(10),	
constraint sc_scdenbr foreign key(scdenbr) references unitech_detail(derfnbr) on delete cascade,
constraint sc_sccxnbr foreign key(sccxnbr) references unitech_cxlb(cxrfnbr) on delete cascade
);

--��ʷ�����ӱ�����������Ĺ�ϵ��
drop table unitech_screlation1;
create table unitech_screlation1;




--�����ֵ��
drop table unitech_dict;
create table unitech_dict(
dttype		varchar(50),
dtnbr		varchar(20)
);

--��Ʒ�������
create table unitech_splbfz(
szrfnbr			varchar(10)  not null primary key,
szname	 		varchar(50),
szorder 		int
);


--��Ʒ����������Ʒ����ϵ����unitech_ssrelation��
create table unitech_ssrelation(
ssrfnbr			varchar(10)  not null primary key,
sssznbr	 		varchar(10),
ssusnbr 		varchar(10),
constraint ss_sssznbr foreign key(sssznbr) references unitech_splbfz(szrfnbr) on delete cascade,
constraint ss_ssusnbr foreign key(ssusnbr) references unitech_splb(usrfnbr) on delete cascade
);

--ԭ���������
create table unitech_splbfz1(
szrfnbr			varchar(20)  not null primary key,
szname	 		varchar(50),
szorder 		int
);

--��Ʒ����������Ʒ����ϵ����unitech_ssrelation1��
create table unitech_ssrelation1(
ssrfnbr			varchar(10)  not null primary key,
sssznbr	 		varchar(10),
ssusnbr 		varchar(10),
constraint ss1_sssznbr foreign key(sssznbr) references unitech_splbfz1(szrfnbr) on delete cascade,
constraint ss1_ssusnbr foreign key(ssusnbr) references unitech_splb(usrfnbr) on delete cascade
);

--��������
create table unitech_syfz(
sfrfnbr			varchar(10)  not null primary key,
sfname	 		varchar(50),
sforder 		int
);

--��������������ϵ
create table unitech_sfrelation2(
S2rfnbr			varchar(10)  not null primary key,
S2sfnbr	 		varchar(10),
S2synbr 		varchar(10),
constraint s2_S2sfnbr foreign key(S2sfnbr) references unitech_syfz(sfrfnbr) on delete cascade,
constraint s2_S2synbr foreign key(S2synbr) references unitech_sy(syrfnbr) on delete cascade
);

--̨λ����Ʒ��ϵ��
drop table unitech_tsrelation;
create table unitech_tsrelation(
tsrfnbr			varchar(10)  not null primary key,
tsthnbr	 		varchar(10),
tsspnbr 		varchar(10),
tsmany			dec(9,2),
tsmany2			dec(9,2),
constraint ts_tsthnbr foreign key(tsthnbr) references unitech_th(thrfnbr) on delete cascade,
constraint ts_tsspnbr foreign key(tsspnbr) references unitech_sp(sprfnbr) on delete cascade
);

--��Ʒ��������ϵ��
drop table unitech_szrelation;
create table unitech_szrelation(
szrfnbr			varchar(10)  not null primary key,
szspnbr	 		varchar(10),
szzfnbr 		varchar(10),
constraint sz_szspnbr foreign key(szspnbr) references unitech_sp(sprfnbr) on delete cascade,
constraint sz_szzfnbr foreign key(szzfnbr) references unitech_zf(zfrfnbr) on delete cascade
);
--��Ʒ�����������ϵ��
drop table unitech_pzrelation;
create table unitech_pzrelation(
pzrfnbr			varchar(10)  not null primary key,
pzusnbr	 		varchar(10),
pzzfnbr 		varchar(10),
constraint pz_pzusnbr foreign key(pzusnbr) references unitech_splb(usrfnbr) on delete cascade,
constraint pz_pzzfnbr foreign key(pzzfnbr) references unitech_zf(zfrfnbr) on delete cascade
);




--�۸񷽰���
create table unitech_prices( 
psrfnbr 		varchar(10) not null primary key, 
psname 			varchar(50),
psselect		varchar(10)
);
--�۸񷽰���ϸ��
create table unitech_pricedetail( 
pdrfnbr 		varchar(10) not null primary key, 
pdpsnbr			varchar(10),
pdspnbr			varchar(10),
pdprice 		decimal(10,2) default 0,
constraint pdps_pdpsnbr foreign key(pdpsnbr) references unitech_prices(psrfnbr) on delete cascade
);

--���еĹ�ϵ��
create table unitech_relation(
renbr1 			varchar(20),
renbr2 			varchar(20),
retype 			varchar(50)
remany 			decimal(12,2) default 0,
remany2			decimal(12,2) default 0,
);
--�ⷿ���û��Ĺ�ϵ/�ⷿ����Ʒ���Ĺ�ϵ/��Ʒ��ⷿ�Ĺ�ϵ���ƶ�ƽ���ۣ�/

-------------------------------�������ݲ��ֵı�--------------------------------------------------------------
-------------------------------�������ֵı�--------------------------------------------------------------
--���۽�������
drop table unitech_xsmaster;
create table unitech_xsmaster(
xmrfnbr 		varchar(20) not null primary key,
xmdate			datetime,
xmjsr			varchar(100),
xmflag			varchar(10),
xmdesc			varchar(1000)
);

--���۽����ӱ�
drop table unitech_xsdetail;
create table unitech_xsdetail(
xdrfnbr 		varchar(20) not null primary key,
xdxmnbr 		varchar(20),
xdspnbr			varchar(20),
xdspname		varchar(50),
xdspunit		varchar(10),
xdspunit2		varchar(10),
xdmany			decimal(12,2) default 0,
xdprice			decimal(12,5) default 0,
xdjine			decimal(12,2) default 0,
xdmany2			decimal(12,2) default 0,
constraint xd_xdxmnbr foreign key(xdxmnbr) references unitech_xsmaster(xmrfnbr) on delete cascade	
);

--������

drop table unitech_dingdan;
create table unitech_dingdan(
udrfnbr 		varchar(20) not null primary key,	
udtwh	 		varchar(50),
udthtainum		varchar(10),
udwaiter		varchar(10),
udusnbr			varchar(10),
uddcczy			varchar(10),
udssy			varchar(10),
udnumber		int default 0,
udday			datetime,
uddesc			varchar(200),
udflag			varchar(10),
udysjine		decimal(12,2) default 0,
udzhjine		decimal(12,2) default 0,
udssjine		decimal(12,2) default 0,
uddazhe			varchar(10),
udgjdate		datetime,
udname			varchar(50),
udml			decimal(12,2) default 0,
udzkl			decimal(12,2) default 0,
udxkflag		varchar(10),
udyuanyin		varchar(50),
udhgnbr			varchar(10),
udjztime		datetime,
udczflag		varchar(10),
udfapiao		varchar(10)
);

--�����ӱ�
drop table unitech_detail
create table unitech_detail(
derfnbr			varchar(20) not null primary key,
deudnbr			varchar(20),
despnbr			varchar(20),
despname		varchar(50),
dekouwei		varchar(100),
dezuofa			varchar(100),
dejiajia		decimal(12,2) default 0,
demany			decimal(12,2) default 0,
deprice			decimal(12,2) default 0,
dejine			decimal(12,2) default 0,
deunit			varchar(20),
dechuda			varchar(20),
deutnbr 		varchar(10),
dezsnbr			varchar(10),
dezhjine		decimal(12,2) default 0,
deqcflag		varchar(10),
dezkl			decimal(12,2) default 0,
decdflag		varchar(10),
deczyid			varchar(50),
deczyname		varchar(50),
dedytime		datetime,
dewctime		datetime,
dehcrid			varchar(10),
dehcrname		varchar(50),
depdahcflag		varchar(10),
dedcjnum		varchar(20),
dehcnum			decimal(12,0),
deunit2			varchar(20),
demany2			decimal(9,2) default 0,
depdnbr			varchar(20),
constraint de_deudnbr foreign key(deudnbr) references unitech_dingdan(udrfnbr) on delete cascade	
);

--��ʷ������
drop table unitech_dingdan1
create table unitech_dingdan1;

--��ʷ�����ӱ�
drop table unitech_detail1
create table unitech_detail1;
-------------------------------�������ֵı�--------------------------------------------------------------


-------------------------------�ⷿ���ֵı�--------------------------------------------------------------
--�ⷿ�̵�����
drop table unitech_kfpdmaster;
create table unitech_kfpdmaster(
kmrfnbr 		varchar(20) not null primary key,
kmdate			datetime,
kmjsr			varchar(100),
kmfknbr			varchar(20),
kmdesc			varchar(1000)
);

--�ⷿ�̵��ӱ�
drop table unitech_kfpddetail;
create table unitech_kfpddetail(
kdrfnbr 		varchar(20) not null primary key,
kdkmnbr 		varchar(20),
kdspnbr			varchar(20),
kdspname		varchar(50),
kdspunit		varchar(10),
kdspunit2		varchar(10),

kdqcmany		decimal(12,2) default 0,
kdqcprice		decimal(12,5) default 0,
kdqcjine		decimal(12,2) default 0,

kdrkmany		decimal(12,2) default 0,
kdrkprice		decimal(12,5) default 0,
kdrkjine		decimal(12,2) default 0,

kdckmany		decimal(12,2) default 0,
kdckprice		decimal(12,5) default 0,
kdckjine		decimal(12,2) default 0,

kdqmzmmany		decimal(12,2) default 0,
kdqmzmprice		decimal(12,5) default 0,
kdqmzmjine		decimal(12,2) default 0,

kdqmsjmany		decimal(12,2) default 0,
kdqmsjprice		decimal(12,5) default 0,
kdqmsjjine		decimal(12,2) default 0,

kdqmykmany		decimal(12,2) default 0,
kdqmykprice		decimal(12,5) default 0,
kdqmykjine		decimal(12,2) default 0,

kdqcmany2		decimal(12,2) default 0,
kdrkmany2		decimal(12,2) default 0,
kdckmany2		decimal(12,2) default 0,
kdqmzmmany2		decimal(12,2) default 0,
kdqmsjmany2		decimal(12,2) default 0,
kdqmykmany2		decimal(12,2) default 0,

constraint kd_kdkmnbr foreign key(kdkmnbr) references unitech_kfpdmaster(kmrfnbr) on delete cascade
);


--ԭ������
drop table unitech_ylmaster;
create table unitech_ylmaster(
ylmarfnbr 		varchar(20) not null primary key,
ylmatype 		varchar(10),
ylmadate		datetime,
ylmajsr			varchar(100),
ylmaflag		varchar(10),
ylmaghslb		varchar(10),
ylmaghs			varchar(10),
ylmastart		varchar(10),
ylmato			varchar(10),
yludnbr			varchar(20),
ylmadesc		varchar(100),
yljine			decimal(9,2),
ylyfnbr			varchar(20)
);

--ԭ���ӱ�
drop table unitech_yldetail
create table unitech_yldetail(
ylderfnbr 		varchar(20) not null primary key,
yldemanbr 		varchar(20),
yldespnbr		varchar(10),
yldename		varchar(50),
yldemany		decimal(12,2) default 0,
yldemany2		decimal(12,2) default 0,
yldeunit		varchar(10),
yldeunit2		varchar(10),
yldeprice		decimal(12,2) default 0,
yldespname		varchar(50),
yldespshl		decimal(12,2) default 0,
yldespshl2		decimal(12,2) default 0,
yldespunit		varchar(10),
yldespnbr1		varchar(10),
constraint yd_yldemanbr foreign key(yldemanbr) references unitech_ylmaster(ylmarfnbr) on delete cascade
);


--��ʷԭ������
drop table unitech_ylmaster1;
create table unitech_ylmaster1;

--��ʷԭ���ӱ�
drop table unitech_yldetail1
create table unitech_yldetail1;


--ԭ����ʱ��
drop table unitech_temp;
create table unitech_temp(
temp_ylderfnbr 		varchar(10) not null primary key,
temp_yldespnbr		varchar(10),
temp_yldename		varchar(50),
temp_yldemany		decimal(12,2) default 0,
temp_yldemany2		decimal(12,2) default 0,
temp_yldeunit		varchar(10),
temp_yldeunit2		varchar(10),
temp_yldetype		varchar(10),
temp_ghs		varchar(10),
temp_start		varchar(10),
temp_to			varchar(10),
temp_yldekc		decimal(12,2) default 0,
temp_jsrid		varchar(50),
temp_yldespname		varchar(50),
temp_yldespshl		decimal(12,2) default 0,
temp_yldeprice		decimal(12,2) default 0,
temp_yldespunit		varchar(10),
temp_yldespnbr1		varchar(10),
temp_ylpdshl		decimal(12,2) default 0,
temp_yldespshl2		decimal(12,2) default 0,
temp_ylpdshl2		decimal(12,2) default 0
);

--Ӧ����¼��
drop table unitech_yfjl
create table unitech_yfjl(
yfrfnbr 		varchar(20) not null primary key,
yfhgnbr			varchar(10),
yfjsr			varchar(50),
yfdate			datetime,
yfjine			dec(9,2),
yfflag			varchar(10),
constraint yfjl_yfhgnbr foreign key(yfhgnbr) references unitech_ghs(hgrfnbr) on delete cascade
);

--��ʷӦ����¼��
drop table unitech_yfjl1
create table unitech_yfjl1;


--��ʱ��
drop table unitech_temp1;
create table unitech_temp1(
temp1_derfnbr 		varchar(10) not null primary key,
temp1_deunit		varchar(10),
temp1_detype		varchar(10),
temp1_despname		varchar(50),
temp1_usname		varchar(50),
temp1_jsrid		varchar(50),
temp1_kfname		varchar(50),
temp1_rkshl   		decimal(12,2) default 0,
temp1_rkjine   		decimal(12,2) default 0,
temp1_drshl		decimal(12,2) default 0,
temp1_drjine		decimal(12,2) default 0,
temp1_dcshl		decimal(12,2) default 0,
temp1_dcjine		decimal(12,2) default 0,
temp1_shshl		decimal(12,2) default 0,
temp1_shjine		decimal(12,2) default 0,
temp1_ckshl		decimal(12,2) default 0,
temp1_ckjine		decimal(12,2) default 0,
temp1_thshl		decimal(12,2) default 0,
temp1_thjine		decimal(12,2) default 0,
temp1_usrfnbr		varchar(10),
temp1_sprfnbr		varchar(10),
temp1_fkrfnbr		varchar(10),
temp1_price		decimal(12,2) default 0,
temp1_xsshl		decimal(12,2) default 0,
temp1_xsshl2		decimal(12,2) default 0,
temp1_xsshl3		decimal(12,2) default 0,
temp1_xsshl4		decimal(12,2) default 0,
temp1_xhshl		decimal(12,2) default 0,
temp1_chengben		decimal(12,2) default 0,
temp1_lv		decimal(12,2) default 0,
temp1_xsckshl 		decimal(12,2) default 0,
temp1_xsckjine		decimal(12,2) default 0,
temp1_time		datetime ,

temp1_deunit2		varchar(10),
temp1_rkshl2 		decimal(12,2) default 0,
temp1_drshl2 		decimal(12,2) default 0,
temp1_dcshl2 		decimal(12,2) default 0,
temp1_shshl2 		decimal(12,2) default 0,
temp1_ckshl2 		decimal(12,2) default 0,
temp1_thshl2 		decimal(12,2) default 0,
temp1_xsshl21		decimal(12,2) default 0,
temp1_xssh22 		decimal(12,2) default 0,
temp1_xssh23 		decimal(12,2) default 0,
temp1_xssh24 		decimal(12,2) default 0,
temp1_xhshl2 		decimal(12,2) default 0,
temp1_chengben2 	decimal(12,2) default 0,
temp1_lv2 		decimal(12,2) default 0
);



-------------------------------�ⷿ���ֵı�--------------------------------------------------------------

-------------------------------��ӡ���ֵı�--------------------------------------------------------------
--��ӡ���б�
drop table unitech_dayinduilie;
create table unitech_dayinduilie(
ddrfnbr 		varchar(10) not null primary key,
ddtype	 		varchar(10),
ddperson		varchar(20),
ddstart			varchar(100),
ddto			varchar(100),
ddzhangdanid		varchar(2000),
dddesc			varchar(2000),
ddtime			datetime,
ddprintname		varchar(100),
ddprnbr			varchar(10),
ddxnbr			varchar(20)
);

--��ӡ����
create table unitech_printer(
prrfnbr 		varchar(10) not null primary key,
prname	 		varchar(100),
prprinter	 	varchar(100),
prwidth		 	varchar(10),
przidong	 	varchar(10),
prqiezhitype	 	varchar(10),
prfont_title	 	varchar(100),
prfont_content	 	varchar(100),
prfontsize_title 	varchar(10),
prfontsize_content 	varchar(10),
prfonttype_title 	varchar(10),
prfonttype_content	varchar(10),
prtop1			int default 0,
prleft_title1		int default 0,
prleft_title2		int default 0,
prleft_content		int default 0,
prhjj			int default 6
);

--���ݴ�ӡ���ñ�
create table unitech_dfcrelation(
dfcrfnbr 		varchar(10) not null primary key,
dfcdjname	 	varchar(20),
dfcchuda	 	varchar(10),
dfcccbda		varchar(10),
dfcorder		varchar(10),
dfclang			varchar(10),
dfccount		varchar(10),
dfcdesc			varchar(10),
dfcdyd			varchar(10),
dfcbddy			varchar(10),
dfccx			varchar(10)
);

insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000001','��˵�','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000002','�߲˵�','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000003','�˲˵�','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000004','���ͳ�','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000005','����','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000006','ת̨֪ͨ','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000007','��̨֪ͨ','��','��','���˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000009','�˵�','��','��','¼��˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000010','Ԥ�ᵥ','��','��','¼��˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000011','���ʵ�','��','��','¼��˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000012','��ӡ��','��','��','¼��˳��','��','��','��','��','��','��');
insert into unitech_dfcrelation(dfcrfnbr,dfcdjname,dfcchuda,dfcccbda,dfcorder,dfclang,dfccount,dfcdesc,dfcdyd,dfcbddy,dfccx)values('dfc000013','������ϸ','��','��','¼��˳��','��','��','��','��','��','��');

--������˾��Ϣ��
drop table unitech_info;
create table unitech_info(
uirfnbr 		varchar(10) not null primary key,
uiname	 		varchar(50),
uiaddress		varchar(50),
uilink			varchar(50),
uihomepage		varchar(50)
);
insert into unitech_info(uirfnbr,uiname,uiaddress,uilink,uihomepage)values('ui000001','����֧�֣�����ͬ�ͿƼ�','�����ϵؿƼ�԰','�绰��81731987��13911771896','��ַ��www.tonghechangye.com');

-------------------------------��ӡ���ֵı�--------------------------------------------------------------
-------------------------------Ȩ�޲��ֵı�--------------------------------------------------------------

--Ȩ�ޱ�
create table unitech_right(
rtrfnbr 		varchar(10) not null primary key,
rtpnbr		 	varchar(10),
rtname	 		varchar(100),
rtdesc		 	varchar(200)
);

--��֯������
create table unitech_department(
dprfnbr 		varchar(10) not null primary key,
dppnbr		 	varchar(10),
dpname	 		varchar(100),
dpdesc		 	varchar(200)
);
--�û���
create table unitech_user(
usrfnbr 		varchar(10) not null primary key,
uslogid		 	varchar(20),
uspwd		 	varchar(20),
usname	 		varchar(100),
usflag		 	varchar(10),
usdesc		 	varchar(200),
uszkl			int default 100,
usgonghao		varchar(10),
ussex			varchar(10),
usbirsday		datetime,
ushomeaddress		varchar(100),
usnowaddress		varchar(100),
uscode			varchar(20),
usmobile		varchar(50),
usphone			varchar(20),
usxueli			varchar(20),
uszhuanye		varchar(20),
ustechang		varchar(50),
uslyday			datetime,
uspinyin		varchar(20),
uszwname		varchar(50),
usflag2			varchar(10),
usygk	   		varchar(50),
usgongzi		decimal(12,2) default 0,
ustcbl			decimal(12,2) default 0
);
--��ɫ��
create table unitech_role(
rlrfnbr 		varchar(10) not null primary key,
rlpnbr		 	varchar(10),
rlname	 		varchar(100),
rldesc		 	varchar(200)
);
--�û�����֯��������ɫ��Ȩ�޹�ϵ��
create table unitech_udrrrelation(
usnbr	 		varchar(10),
dpnbr	 		varchar(10),
rlnbr	 		varchar(10),
rtnbr		 	varchar(10),
constraint udrr_usnbr foreign key(usnbr) references unitech_user(usrfnbr) on delete cascade,
constraint udrr_dpnbr foreign key(dpnbr) references unitech_department(dprfnbr) on delete cascade,
constraint udrr_rlnbr foreign key(rlnbr) references unitech_role(rlrfnbr) on delete cascade,
constraint udrr_rtnbr foreign key(rtnbr) references unitech_right(rtrfnbr) on delete cascade
);
-------------------------------Ȩ�޲��ֵı�--------------------------------------------------------------
-------------------------------��Ա�������ֵı�--------------------------------------------------------------
--��Ա���ͱ�
drop table unitech_hytype;
create table unitech_hytype(
htrfnbr 		varchar(10) not null primary key,
htname	 		varchar(50),
htdesc	 		varchar(200)
);

--��Ա�����ͱ�
drop table unitech_hyktype;
create table unitech_hyktype(
hkrfnbr 		varchar(10) not null primary key,
hkname	 		varchar(50),
hkjifen			decimal(9,2) default 0,
hkzkl			decimal(9,2) default 0,
hkgz			decimal(9,2) default 0,
hkdesc	 		varchar(200)
);

--��Ա���ֶһ����ͱ�
drop table unitech_jfdhtype;
create table unitech_jfdhtype(
jtrfnbr 		varchar(10) not null primary key,
jtname	 		varchar(50),
jtmany			decimal(9,2) default 0,
jtdesc	 		varchar(200)
);

--��Ա��
drop table unitech_hygl;
create table unitech_hygl(
hgrfnbr 		varchar(10) not null primary key,
hgname	 		varchar(50),
hgtel			varchar(20),
hgaddress		varchar(100),
hgdate			datetime,
hgdesc			varchar(200),
hgmobile		varchar(20),
hglink			varchar(50),
hgjsrid			varchar(10),
hgjsr			varchar(50),
hgbirthday		datetime,
hgemail			varchar(50),
hghtnbr			varchar(10),
hghtname		varchar(50),
hghknbr			varchar(10),
hghkname		varchar(50),
hgmany			decimal(9,2) default 0,
hgjifen			decimal(9,2) default 0,
hgzkl			decimal(9,2) default 0,
hgjfbz			decimal(9,2) default 0,
hggz			decimal(9,2) default 0,
hgkfp			varchar(10)
);

--��Ա��������
drop table unitech_hyk;
create table unitech_hyk(
hyrfnbr 		varchar(10) not null primary key,
hyhgnbr 		varchar(10),
hycardno 		varchar(100),
hyflag			varchar(10),
hydate			datetime,
hydesc	 		varchar(200),
hypwd	 		varchar(50),
constraint hy_hyhgnbr foreign key(hyhgnbr) references unitech_hygl(hgrfnbr) on delete cascade
);

--��Ա����ֵ��¼��
drop table unitech_chuzhi;
create table unitech_chuzhi(
czrfnbr 		varchar(10) not null primary key,
czhycardno 		varchar(100),
czhgnbr 		varchar(10),
czmany			decimal(9,2) default 0,
czjsr 			varchar(50),
czdate			datetime,
czflag 			varchar(10),
czdesc 			varchar(200)
);

--��Ա���ּ�¼��
drop table unitech_jifen;
create table unitech_jifen(
jfrfnbr 		varchar(10) not null primary key,
jfhycardno 		varchar(100),
jfhgnbr 		varchar(10),
jfmany			decimal(9,2) default 0,
jfjsr 			varchar(50),
jfdate			datetime,
jfudnbr 		varchar(20),
jfdesc 			varchar(200),
jfflag 			varchar(10)
);

--��Ա���ֶһ���¼��
drop table unitech_jfdh;
create table unitech_jfdh(
jdrfnbr 		varchar(10) not null primary key,
jdhycardno 		varchar(100),
jdhgnbr 		varchar(10),
jdjtnbr 		varchar(10),
jdjtname 		varchar(50),
jdmany			decimal(9,2) default 0,
jdjsr 			varchar(50),
jddate			datetime,
jdflag 			varchar(10),
jddesc 			varchar(200)
);

--��������
drop table unitech_sybb;
create table unitech_sybb(
syrfnbr 		varchar(20) primary key not null,
syudnbr 		varchar(20) not null,
syhuiyuanid		varchar(10),
syhuiyuanname		varchar(50),
syhycardno		varchar(100),
syid			varchar(10),
syy			varchar(50),
syfkfs			varchar(20),
syfkjine		decimal(12,2) default 0,
syys			decimal(12,2) default 0,
syzhjine		decimal(12,2) default 0,
syss			decimal(12,2) default 0,
syml			decimal(12,2) default 0,
syzhl			decimal(12,2) default 0,
sytime			datetime,
syflag			varchar(10),
syhkflag		varchar(10),
sydesc			varchar(200)
);

--��ʷ��������
drop table unitech_sybb1;
create table unitech_sybb1;

--����������ʱ��
drop table unitech_temp2;
create table unitech_temp2(
temp2_name		varchar(100),
temp2_jine		decimal(12,2)
);


--ʱʵ�۲���ʱ��
drop table unitech_temp3
create table unitech_temp3(
tename			varchar(50),
teshuzhi		decimal(12,2) default 0
);
--��ʱ��4
drop table unitech_temp4
create table unitech_temp4(
ut4rfnbr		varchar(10),
ut4udnbr		varchar(20),
ut4syfkjine		decimal(12,2) default 0,
ut4sygzfs		varchar(50),
ut4syrfnbr		varchar(20),
ut4hgnbr		varchar(10)
);

--�����¼��
drop table unitech_ldjl;
create table unitech_ldjl(
ljrfnbr 		varchar(10) not null primary key,
ljtel			varchar(20),
ljtime			datetime,
ljhgrfnbr 		varchar(10),
ljhgname	 	varchar(50),
ljhgtel			varchar(20),
ljhgaddress		varchar(100),
ljhgdate		datetime,
ljhgdesc		varchar(200),
ljdesc			varchar(200),
ljhgmobile		varchar(20),
ljhglink		varchar(50),
ljhgjsrid		varchar(10),
ljhgjsr			varchar(50),
ljhgbirthday		datetime,
ljhgemail		varchar(50),
ljhghtnbr		varchar(10),
ljhghtname		varchar(50),
ljhghknbr		varchar(10),
ljhghkname		varchar(50),
ljhgmany		decimal(9,2) default 0,
ljhgjifen		decimal(9,2) default 0,
ljhgzkl			decimal(9,2) default 0,
ljhgjfbz		decimal(9,2) default 0,
ljhggz			decimal(9,2) default 0
);

--��Ա���Ѽ�¼��
create table unitech_xfjl(
uxhyid 			varchar(10) not null,
uxhyname 		varchar(50),
uxdate			datetime,
uxfangshi		varchar(20),
uxjine			decimal(12,2) default 0,
uxmasterid		varchar(20)
);
-------------------------------��Ա�������ֵı�----------------------------------------------------------

-------------------------------���¹������ֵı�----------------------------------------------------------
--Ա����Ϣ��
drop table unitech_employee
create table unitech_employee(
uerfnbr			varchar(10) primary key not null,
uegonghao		varchar(10),
uename			varchar(50),
uesex			varchar(10),
uebirsday		datetime,
uehomeaddress		varchar(100),
uenowaddress		varchar(100),
uecode			varchar(20),
uemobile		varchar(50),
uephone			varchar(20),
uexueli			varchar(20),
uezhuanye		varchar(20),
uetechang		varchar(50),
uelyday			datetime,
uepinyin		varchar(20),
ueygk			varchar(50),
uedesc			varchar(500)
);

--��֯����
create table unitech_bm(
dprfnbr 		varchar(10) not null primary key,
dppnbr		 	varchar(10),
dpname	 		varchar(100),
dpdesc		 	varchar(200)
);

--Ա������֯������ϵ��
create table unitech_ebrelation(
uenbr		varchar(10),
dpnbr	 	varchar(10),
constraint eb_uenbr foreign key(uenbr) references unitech_employee(uerfnbr) on delete cascade,
constraint eb_dpnbr foreign key(dpnbr) references unitech_bm(dprfnbr) on delete cascade
);

--ְλ��
create table unitech_zw(
zwrfnbr			varchar(10) not null primary key,
zwname		 	varchar(50)
);

--���ʱ�
drop table unitech_gz;
create table unitech_gz(
gzrfnbr 		varchar(10) not null primary key,
gzusnbr		 	varchar(10),
gzjbgz	 		decimal(12,2) default 0,
gzjj		 	decimal(12,2) default 0,
gzjetc			decimal(12,2) default 0,
gzbltc			decimal(12,2) default 0,
gzmonth			datetime,
gzbegintime		datetime,
gztotime		datetime,
gzjsr			varchar(50)
);
--Ա�����ڱ�
drop table unitech_kq;
create table unitech_kq(			
kqname			varchar(50),
kqusnbr			varchar(10),
kqtime			time,
kqksnbr			varchar(10),
kqdate			date,
kqflag			varchar(20),
kqbcflag		varchar(20),
kqzcjs			int default 0,
kqcdjs			int default 0,
kqztjs			int default 0,
kqkgjs			int default 0
);

drop table unitech_kqsz;
create table unitech_kqsz(
ksrfnbr			varchar(10)  not null primary key,
ksbanci			varchar(50),
kssbtime		time,
ksxbtime		time,
kssbkg			int,
ksxbkg			int,
ksflag			varchar(20)
);
-------------------------------���¹������ֵı�----------------------------------------------------------
-------------------------------����ϵͳ----------------------------------------------------------
drop table unitech_hc;
create table unitech_hc(
hcrfnbr			varchar(10) not null primary key,
hctype		 	varchar(50),
hcid	 		varchar(20),
hcname			varchar(50)
);
-------------------------------����ϵͳ----------------------------------------------------------

drop table unitech_jl;
create table unitech_jl(
jlrfnbr			varchar(10),
jldate			datetime,
jlktime			datetime,
jljtime			datetime,
jlto			varchar(50),
jluser			varchar(50),
jldesc			varchar(2000)
);
----------------------------------------Ӫ�������---------------------------------------------------
--Ӫ��������
drop table unitech_yxmaster;
create table unitech_yxmaster(
ymrfnbr			varchar(10)  not null primary key,
ymname			varchar(50),
ymkstime		datetime,
ymjztime		datetime,
ymfzr			varchar(50),
ymjltime		datetime,
ymflag			varchar(10),
ymdesc  		varchar(2000)
);
--Ӫ������ٱ�
drop table unitech_yxdetail;
create table unitech_yxdetail(
ydrfnbr			varchar(10)  not null primary key,
ydymnbr			varchar(10),
ydtime			datetime,
ydfzr			varchar(50),
ydjine			decimal(12,2) default 0,
yddesc			varchar(2000),
constraint yd_ydymnbr foreign key(ydymnbr) references unitech_yxmaster(ymrfnbr) on delete cascade
);

----------------------------------------Ӫ�������---------------------------------------------------

----------------------------------------���ߵ�˲���---------------------------------------------------

--��˻���
create table unitech_dcj(
dcrfnbr 	varchar(3) 	primary key,
dcjzcode 	varchar(1),
dccccode	varchar(10),
dcygcode	varchar(4),
dcloc		varchar(20),
dclotime	datetime,
dcbdprint 	varchar(10),
dcsyprint 	varchar(10)
)
--��վ��
create table unitech_jz(
jzrfnbr		varchar(1)	primary key,
jzcom		varchar(4),
jzcname		varchar(40)
)

--PDA��
drop table unitech_pda;
create table unitech_pda(
pdaid		varchar(200),
zctime		datetime
)
--PDA��Ȩ��
create table unitech_pdasq(
sqflag		varchar(10),
sqmaxnum	int
)
insert into unitech_pdasq(sqflag,sqmaxnum)values('��',100)
----------------------------------------���ߵ�˲���---------------------------------------------------

---------------------------------------ǰ̨�ɿ͵ı�-----------------------------------------------------

--�Ŷӱ�
create table unitech_pd(
pdrfnbr		varchar(10) not null primary key,
pdtime	 	datetime,
pdxh		int,
pdrs		int,
pdflag		varchar(10)
);

--��ű�
create table unitech_xh(
xh	int
);
---------------------------------------ǰ̨�ɿ͵ı�-----------------------------------------------------


-----------------------------------------��ˮ�ⷿ�ı�-----------------------------------------------------
--��ˮ����
drop table js_master;
create table js_master(
ylmarfnbr 		varchar(20) not null primary key,
ylmatype 		varchar(10),
ylmadate		datetime,
ylmadate1		datetime,
ylmadate2		datetime,
ylmajsr			varchar(100),
ylmaflag		varchar(10),
ylmaghslb		varchar(10),
ylmaghs			varchar(10),
ylmastart		varchar(10),
ylmato			varchar(10),
yludnbr			varchar(20),
ylmadesc		varchar(100),
yljine			decimal(9,2),
ylyfnbr			varchar(20)
);

--��ˮ�ӱ�
drop table js_detail;
create table js_detail(
ylderfnbr 		varchar(20) not null primary key,
yldemanbr 		varchar(20),
yldespnbr		varchar(10),
yldename		varchar(50),
yldemany		decimal(12,2) default 0,
yldemany2		decimal(12,2) default 0,
yldeunit		varchar(10),
yldeunit2		varchar(10),
yldeprice		decimal(12,2) default 0,
yldespname		varchar(50),
yldespshl		decimal(12,2) default 0,
yldespshl2		decimal(12,2) default 0,
yldespunit		varchar(10),
yldespnbr1		varchar(10),

ylqcmany		decimal(12,2) default 0,
ylqmmany		decimal(12,2) default 0,
ylrkmany		decimal(12,2) default 0,
yltkmany		decimal(12,2) default 0,
ylshmany		decimal(12,2) default 0,
ylxsmany		decimal(12,2) default 0,
constraint js_yldemanbr foreign key(yldemanbr) references js_master(ylmarfnbr) on delete cascade
);

--��ʷ��ˮ����
drop table js_master1;
create table js_master1;

--��ʷ��ˮ�ӱ�
drop table js_detail1;
create table js_detail1;
-----------------------------------------��ˮ�ⷿ�ı�-----------------------------------------------------


-----------------------------------------�ɱ��ı�-----------------------------------------------------

--�ɱ�����ԭ�Ͻ�������
drop table unitech_yljsmaster;
create table unitech_yljsmaster(
ylmarfnbr 		varchar(20) not null primary key,
ylmatype 		varchar(10),
ylmadate		datetime,
ylmadate1		datetime,
ylmadate2		datetime,
ylmajsr			varchar(100),
ylmaflag		varchar(10),

ylmastart		varchar(10),
ylmato			varchar(10),
yludnbr			varchar(20),
ylmadesc		varchar(2000),
yljine			decimal(9,2)
);

--�ɱ�����ԭ�Ͻ����ӱ�
drop table unitech_yljsdetail;
create table unitech_yljsdetail(
ylderfnbr 		varchar(20) not null primary key,
yldemanbr 		varchar(20),
yldesplbnbr		varchar(10),
yldespnbr		varchar(10),
yldename		varchar(50),
yldeunit		varchar(10),
yldeunit2		varchar(10),
yldemany		decimal(12,2) default 0,
yldemany2		decimal(12,2) default 0,
yldeprice		decimal(12,2) default 0,
yldejine		decimal(12,2) default 0,
yldcmany		decimal(12,2) default 0,
ylshmany		decimal(12,2) default 0,
ylthmany		decimal(12,2) default 0,
ylckmany		decimal(12,2) default 0,
Ylykmany		decimal(12,2) default 0,
constraint yl_yldemanbr foreign key(yldemanbr) references unitech_yljsmaster(ylmarfnbr) on delete cascade
);


-----------------------------------------�ɱ��ı�-----------------------------------------------------
-----------------------------------------����ı�-----------------------------------------------------
--��֧���
drop table unitech_fylb;
create table unitech_fylb(
flrfnbr 		varchar(20) not null primary key,
flname			varchar(50),
florder			varchar(20),
fltype			varchar(20)
);

--fltype(����/֧��)

--��֧��Ŀ
drop table unitech_fy;
create table unitech_fy(
fyrfnbr 		varchar(20) not null primary key,
fyflnbr			varchar(20),
fyname			varchar(50),
fyorder			varchar(20),
fyyxnum			varchar(20),
constraint fy_fyflnbr foreign key(fyflnbr) references unitech_fylb(flrfnbr) on delete cascade
);


--��֧����
drop table unitech_fymaster;
create table unitech_fymaster(
fmrfnbr 		varchar(20) not null primary key,
fmdate			datetime,
fmtype			varchar(20),
fmjsr			varchar(20),
fmdesc			varchar(1000)
);
--fmtype(����/֧��)


--��֧��ϸ
drop table unitech_fydetail;
create table unitech_fydetail(
fdrfnbr 		varchar(20) not null primary key,
fdfmnbr 		varchar(20),
fdfynbr			varchar(20),
fdfyname		varchar(50),
fdjine			decimal(12,2) default 0,
constraint fd_fdfmnbr foreign key(fdfmnbr) references unitech_fymaster(fmrfnbr) on delete cascade
);

--��֧��������
drop table unitech_fyjsmaster;
create table unitech_fyjsmaster(
fjmrfnbr 		varchar(20) not null primary key,
fjmdate			datetime,
fjmjsr			varchar(50),
fjmdesc			varchar(1000),
fjmqcjine		decimal(12,2) default 0,
fjmsrjine		decimal(12,2) default 0,
fjmzcjine		decimal(12,2) default 0,
fjmqmjine		decimal(12,2) default 0
);

--��֧�����ӱ�
--drop table unitech_fyjsdetail;
--create table unitech_fyjsdetail(
--fjdrfnbr 		varchar(20) not null primary key,
--fjdfjmnbr 		varchar(20),
--fjdfynbr		varchar(20),
--fjdfyname		varchar(50),
--fjdfyjine		decimal(12,2) default 0,
--constraint fjd_fjdfjmnbr foreign key(fjdfjmnbr) references unitech_fyjsmaster(fjmrfnbr) on delete cascade
--);

-----------------------------------------����ı�-----------------------------------------------------
-----------------------------------------��ͼ-----------------------------------------------------
create view v_dingdan as select * from unitech_dingdan union select * from unitech_dingdan1
create view v_detail as select * from unitech_detail union select * from unitech_detail
create view v_sybb as select * from unitech_sybb union select * from unitech_sybb1
create view v_ylmaster as select * from unitech_ylmaster union select * from unitech_ylmaster1
create view v_yldetail as select * from unitech_yldetail union select * from unitech_yldetail
-----------------------------------------��ͼ-----------------------------------------------------
