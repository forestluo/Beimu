#########################公共的表###############################################
################删除表#########################
drop table bm_type;
################删除表#########################
################创建表#########################
# 类别表(档案类别sp，事件类别se,收入类别sr，支出类别zc,部门de，角色ro，权限ri）
create table bm_type(
	btid 	    	varchar(10) primary key,             	# 编号  主键
	btpid 	    	varchar(10),                 	     	# 父编号
	btname 	       	varchar(100),                  	      	# 名称
	btorder         varchar(10),                  	       	# 排序字段
	bttype 	      	varchar(10)                  	       	# 类型（档案类别sp，事件类别se,收入类别sr，支出类别zc,部门de，角色ro，权限ri）
);
################创建表#########################
#########################公共的表###############################################

#########################饲养管理###############################################
################删除表#########################
drop table sp_event;
drop table sp_archives;
################删除表#########################
################创建表#########################
# 档案表
create table sp_archives(
    	said	  	varchar(20) primary key,       	     	# 编号 主键
    	saspid          varchar(20),                            # 类别编号
    	sadeid          varchar(10),                            # 圈舍编号
    	sabianhao       varchar(20),                 	    	# 档案人工编号
    	safubianhao  	varchar(20),                 	    	# 父亲编号
    	samubianhao  	varchar(20),                 	    	# 母亲编号
    	satizhong       dec(10,2)                               # 最后一次称的体重
);
# 事件表（疫苗,治疗,出生,转育成,转种羊,转圈舍,秤体重,入场,死亡,淘汰,出栏,打羊毛）
create table sp_event(
    	seid	  	varchar(20) primary key,       	     	# 编号 主键
    	sesaid          varchar(20),                 	    	# 档案编号
    	seseid          varchar(10),                 	    	# 类别编号
    	sedate   	datetime,                 	    	# 日期
    	sedesc          varchar(100)                 	    	# 备注（出生：按体质分 好，中，坏；
    	#转圈舍：原圈舍编号；体重：本次称重的体重；入场，死亡，淘汰，出栏，转育成，转种羊：记录体重）
);
################创建表#########################
##########################饲养管理###############################################
##########################采购管理###############################################
##########################采购管理###############################################
##########################库存管理###############################################
##########################库存管理###############################################
##########################销售管理###############################################
##########################销售管理###############################################

##########################财务管理###############################################
################删除表#########################
drop table cw_bill;
################删除表#########################
################创建表#########################
# 帐单表
create table cw_bill(
    	cbid	  	varchar(20) primary key,       	 	# 编号 主键
    	cbbtid 	  	varchar(10),                 	 	# 类别编号    	
    	cbruid 	  	varchar(10),                 	 	# 用户编号
    	cbdeid 	  	varchar(10),                 	 	# 部门编号
    	cbshouru        dec(10,2),                 	 	# 收入
    	cbzhichu        dec(10,2),                 	 	# 支出
    	cbyue           dec(10,2),                 	 	# 余额    	
    	cbdate   	datetime,                 	 	# 日期
    	cbdesc   	varchar(200)               	 	# 备注
);
################创建表#########################
##########################财务管理###############################################

#########################人力资源###############################################
################删除表#########################
drop table rt_relation;
drop table rt_user;
drop table lz_xg;
drop table lz_kh;
drop table lz_jc;
drop table lz_xgjc;
drop view v_kh;
drop view v_xg;
################删除表#########################
################创建表#########################
# 用户表
create table rt_user(
	ruid            varchar(10) primary key,		# 编号 主键
	runame          varchar(50),				# 姓名
	rulogid         varchar(20),				# 登录ID
	rupwd           varchar(20),				# 密码
	rupinyin        varchar(50),				# 拼音码
	rugonghao       varchar(50),				# 工号
	rushouji        varchar(20),				# 手机
	rushenfenzheng  varchar(30),				# 身份证
	ruzhiwei        varchar(50),				# 职位
	rugongzi        dec(10,2),				# 工资
	ruxueli         varchar(10),				# 学历（博士，硕士，本科，大专，中专，高中，初中，小学，文盲）
	ruxingbie       varchar(10),				# 性别（男，女）
	rulogflag       varchar(10),				# 登录状态（正常，禁用）
	ruzaizhiflag    varchar(10),				# 在职状态（在职，离职）
	ruruzhidate     varchar(10),				# 入职日期
	rulizhidate     varchar(10),				# 离职日期
	rubirthday      varchar(10),				# 生日
	ruzhuanye       varchar(50),				# 专业
	rutechang       varchar(10),				# 特长
	rugongzika      varchar(50),				# 工资卡
	rujiatingzhuzhi varchar(100),				# 家庭地址
	ruxianzhuzhi    varchar(100)				# 现住址
);
# 用户、部门、角色、权限关系表
create table rt_relation(
	reruid 	 	varchar(10),				# 用户编号
	redeid 	 	varchar(10),				# 部门编号
	reroid	  	varchar(10),				# 角色编号
	reriid	 	varchar(10)				# 权限编号
);
# 相关责任人表
create table lz_xg(
	lxruid 	        varchar(10),             	        # 用户编号
	lxxgruid        varchar(10),                 	     	# 相关责任人编号
	lxxglv          dec(10,2),                  	      	# 相关率
	lxdesc 	      	varchar(100)                  	       	# 备注
);
# 绩效考核表
create table lz_kh(
	lkruid 	        varchar(10),             	        # 用户编号
	lkkhruid        varchar(10),                 	     	# 考核人编号
	lkdafen         dec(10,2),                  	      	# 考核打分（0-150）
	lkdate          datetime,                  	      	# 考核日期
	lkdesc 	      	varchar(100)                  	       	# 备注
);
# 奖励处罚表
create table lz_jc(
	lcruid 	        varchar(10),             	        # 用户编号
	lctype          varchar(10),                 	     	# 奖励处罚类型（奖励，处罚）
	lcjine          dec(10,2),                  	      	# 奖励处罚金额
	lcdate          datetime,                  	      	# 日期
	lcdesc 	      	varchar(100)                  	       	# 备注
);
# 相关责任人奖励处罚表
create table lz_xgjc(
	lgruid 	        varchar(10),             	        # 用户编号
	lgxgruid        varchar(10),             	        # 相关责任人编号
	lgtype          varchar(10),                 	     	# 奖励处罚类型（奖励，处罚）
	lgjine          dec(10,2),                  	      	# 奖励处罚金额
	lgdate          datetime                  	      	# 日期
);
################创建表#########################
################创建视图#########################
# 绩效考核视图
create view v_kh as select a.lkruid,a.runame as lkruname,a.lkkhruid,b.runame as lkkhruname,a.lkdafen,a.lkdate,a.lkdesc from (select 
lkruid,runame,lkkhruid,lkdafen,lkdate,lkdesc from lz_kh,rt_user where lkruid=ruid) a,rt_user b where a.lkkhruid=b.ruid;
# 奖励处罚视图
create view v_xg as select a.lxruid,a.runame as lxruname,a.lxxgruid,b.runame as lxxgruname,a.lxxglv,a.lxdesc from (select 
lxruid,runame,lxxgruid,lxxglv,lxdesc from lz_xg,rt_user where lxruid=ruid) a,rt_user b where a.lxxgruid=b.ruid;
################创建视图#########################
#########################人力资源###############################################




