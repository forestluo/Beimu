# demo.py
from mainwindow1 import Mainwindow 
#import mainwindow1
class Window(Mainwindow):
    def __init__(self) -> None:
        super().__init__()
        # set window's title.
        self.title('Demo')
        # set window's geometry size
        self.geometry('600x400')
        self.showmessage('Ready.')

if __name__ == '__main__':
    w = Window()
    w.mainloop()
