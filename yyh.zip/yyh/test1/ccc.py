import tkinter as tk
import tkinter.messagebox
class this_main(object):
    def __init__(self):
        self.window_1_true = None
    def window_2(self):
        self.window_1_true = None
        self.window_1.destroy()
    def window_1(self):
        if self.window_1_true == None:
            self.window_1 = tk.Toplevel(window)
            self.window_1_true = True
            self.window_1.protocol('WM_DELETE_WINDOW',self.window_2)
            window.attributes('-disabled',True)
            self.window_1.mainloop()
 
        #else:
        #    tkinter.messagebox.showwarning(title='警告', message='不可以创建两个子窗口！')
if __name__ == '__main__':
    this_main = this_main()
    window = tk.Tk()
    b = tk.Button(window, text='创建子窗口', font=('Arial', 12), width=10, height=1,
command=this_main.window_1)
 
    b.pack()
    window.mainloop()

