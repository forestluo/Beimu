import tkinter as tk
def mousedown(event):
    widget=event.widget
    widget.startx=event.x # 开始拖动时, 记录控件位置
    widget.starty=event.y
def drag(event):
    widget=event.widget
    dx=event.x-widget.startx
    dy=event.y-widget.starty
    # winfo_x(),winfo_y() 方法获取控件的坐标
    if isinstance(widget,tk.Wm):
        widget.geometry("+%d+%d"%(widget.winfo_x()+dx,widget.winfo_y()+dy))
    else:
        widget.place(x=widget.winfo_x()+dx,
                     y=widget.winfo_y()+dy)
def draggable(tkwidget):
    # tkwidget为一个控件(Widget)或一个窗口(Wm)
    tkwidget.bind("<Button-1>",mousedown,add='+')
    tkwidget.bind("<B1-Motion>",drag,add='+')

root=tk.Tk()
root.title("Test")
button=tk.Button(root,text="Drag!")
button.place(width=80,height=30)
draggable(button)
root.mainloop()
