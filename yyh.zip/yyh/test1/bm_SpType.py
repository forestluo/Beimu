##########################import的模块###########################################
from ast import Return
import tkinter                      as tk
import tkinter.messagebox           as msgbox
import bm_base                      as bm_base
##########################import的模块###########################################

################################饲养管理--档案类别类##################################
class bmSpType(bm_base.bmWindow):# 饲养管理--档案类别
    def __init__(self):# 类初始化
        super().__init__()
        self.bmDB=bm_base.bmDB()
        self.tree_stid=""
        self.tree1_stid=""

    def add(self):# 增加类别
        self.tree1_stid=""
        self.entry_stname.delete(0,tk.END)
        self.entry_storder.delete(0,tk.END)
        self.entry_stdesc.delete(0,tk.END)

    def save(self):# 保存类别
        stid=self.tree1_stid
        stpid=self.tree_stid
        stname=self.entry_stname.get()
        storder=self.entry_storder.get()
        stdesc=self.entry_stdesc.get()
        if stpid=="":
            msgbox.showerror("信息","请选择上一级类别。",parent=self.topWindow)
            return()
        if stname=="":
            msgbox.showerror("信息","请输入类别名称。",parent=self.topWindow)
            return()
        if storder=="":
            msgbox.showerror("信息","请输入排序字段。",parent=self.topWindow)
            return()
        if stid=="":# 增加记录
            info,stid=self.bmDB.getFieldMaxID('sp_type','stid','st',10)
            if info!='OK':
                msgbox.showerror("信息",info,parent=self.topWindow)
                return()
            sql='insert into sp_type(stid,stpid,stname,storder,stdesc) \
                values(\'' + stid + '\',\'' + stpid + '\',\'' + stname + '\',\'' + storder + \
                    '\',\'' + stdesc +'\')' 
            info=self.bmDB.execSQL(sql)
            if info!="OK":
                msgbox.showerror("信息",info,parent=self.topWindow)
                return()
        else:       # 修改记录
            sql='update sp_type set stname=\'' + stname + '\',storder=\'' + storder + \
                '\',stdesc=\'' + stdesc +'\' where stid=\'' + stid +'\'' 
            info=self.bmDB.execSQL(sql)
            if info!="OK":
                msgbox.showerror("信息",info,parent=self.topWindow)
                return()

        self.tree1_stid=""
        tree_stid=self.tree.selection()                            
        self.showTree()
        self.tree.selection_set(tree_stid)

    def delete(self):# 删除类别
        if self.tree1_stid=="":
            return()
        if msgbox.askyesno("信息","您确认要删除这个类别吗？",parent=self.topWindow)==False:
            return()
        sql='select stid from sp_type where stpid=\'' + self.tree1_stid + '\''
        info,result=self.bmDB.returnResult(sql)
        if info!="OK":
            msgbox.showerror("信息",info,parent=self.topWindow)
            return()
        if len(result)>0:
            msgbox.showerror("信息","该类别下有子类别，不能删除。",parent=self.topWindow)
            return()
        sql='select said from sp_archives where sastid=\'' + self.tree1_stid + '\''
        info,result=self.bmDB.returnResult(sql)
        if info!="OK":
            msgbox.showerror("信息",info,parent=self.topWindow)
            return()
        if len(result)>0:
            msgbox.showerror("信息","该类别下有档案记录，不能删除。",parent=self.topWindow)
            return()
        sql='delete from sp_type where stid=\'' + self.tree1_stid + '\''
        info=self.bmDB.execSQL(sql)
        if info!="OK":
            msgbox.showerror("信息",info,parent=self.topWindow)
            return()
        self.tree1_stid=""
        tree_stid=self.tree.selection()                            
        self.showTree()
        self.tree.selection_set(tree_stid)

    def refreshList(self,stid):# 刷新self.tree1
        aaa=list(stid)
        bbb=str(aaa[0])
        self.tree_stid=bbb
        for i in self.tree1.get_children():
            self.tree1.delete(i)
        for i in self.result:
            if str(i[1])==bbb:
                self.tree1.insert('', 'end',str(i[0]), values=(str(i[2]),str(i[3]),str(i[4])))
        self.add()

    def refreshEntry(self,stid):# 刷新文本框
        aaa=list(stid)
        bbb=str(aaa[0])
        self.tree1_stid=bbb

        aaa=list(self.tree1.item(bbb).values())
        bbb=aaa[2]
        self.entry_stname.delete(0,tk.END)
        self.entry_storder.delete(0,tk.END)
        self.entry_stdesc.delete(0,tk.END)

        self.entry_stname.insert(tk.END,bbb[0])
        self.entry_storder.insert(tk.END,bbb[1])
        self.entry_stdesc.insert(tk.END,bbb[2])

    def reorder(self,result,pid,item_p):# 递归调用刷新self.tree
        if item_p==None:
            for i in result:
                if str(i[0])==pid:
                    item_p = self.tree.insert("",'end',str(i[0]),text=str(i[2]),open=True)
                    self.reorder(result,pid,item_p)
        else:
            for i in result:
                if str(i[1])==pid:
                    item_p1=self.tree.insert(item_p,'end',str(i[0]),text=str(i[2]),open=True)
                    self.reorder(result,str(i[0]),item_p1)

    def showTree(self):# 显示self.tree
        for i in self.tree.get_children():
            self.tree.delete(i)
        sql='select stid,stpid,stname,storder,stdesc from sp_type order by storder'
        info,self.result=self.bmDB.returnResult(sql)
        if info!='OK':
            msgbox.showerror("错误信息",info,parent=self.topWindow)
        else:
            self.reorder(self.result,"st00000001",None)

    def showWindow(self,rootWindow):# 显示窗口
        self.getWindow(rootWindow)
        # self.tree
        self.topWindow.title("饲养管理--档案类别")
        self.topWindow.geometry('1000x560+300+170')
        self.tree = tk.ttk.Treeview(self.topWindow)
        self.tree.place(x = 10,y = 10,width = 300,height = 530)
        self.tree.bind("<<TreeviewSelect>>", lambda event:self.refreshList(self.tree.selection())) # 绑定TreeViewSelect事件
        self.showTree()
        # self.tree1
        columns = ("类别名称","排序字段","备注")
        self.tree1 = tk.ttk.Treeview(self.topWindow,show="headings",columns = columns)   # 创建树状对象

        self.tree1.column("类别名称", width=250, anchor='center')
        self.tree1.column("排序字段", width=80, anchor='center') # 表示列,不显示
        self.tree1.column("备注", width=320, anchor='center')

        self.tree1.heading("类别名称", text="类别名称")
        self.tree1.heading("排序字段", text="排序字段")
        self.tree1.heading("备注", text="备注")

        self.tree1.place(x = 320,y = 10,width = 650,height = 400)
        self.tree1.bind("<<TreeviewSelect>>", lambda event:self.refreshEntry(self.tree1.selection())) # 绑定TreeViewSelect事件
        # 文本框
        self.lable_stname=tk.Label(self.topWindow,text="类别名称：",anchor='e')
        self.lable_stname.place(x = 320,y = 420,width = 100,height = 30)
        self.entry_stname=tk.Entry(self.topWindow)
        self.entry_stname.place(x = 420,y = 420,width = 300,height = 30)

        self.lable_storder=tk.Label(self.topWindow,text="排序字段：",anchor='e')
        self.lable_storder.place(x = 720,y = 420,width = 100,height = 30)
        self.entry_storder=tk.Entry(self.topWindow)
        self.entry_storder.place(x = 820,y = 420,width = 100,height = 30)

        self.lable_stdesc=tk.Label(self.topWindow,text="备注：",anchor='e')
        self.lable_stdesc.place(x = 320,y = 460,width = 100,height = 30)
        self.entry_stdesc=tk.Entry(self.topWindow)
        self.entry_stdesc.place(x = 420,y = 460,width = 500,height = 30)
        # 按钮
        self.button_add = tk.Button(self.topWindow, text='增加', command=self.add)
        self.button_add.place(x = 420,y = 500,width = 100,height = 30)

        self.button_save = tk.Button(self.topWindow, text='保存', command=self.save)
        self.button_save.place(x = 540,y = 500,width = 100,height = 30)

        self.button_add = tk.Button(self.topWindow, text='删除', command=self.delete)
        self.button_add.place(x = 660,y = 500,width = 100,height = 30)

        self.button_exit = tk.Button(self.topWindow, text='退出', \
             command=self.destroyWindow)
        self.button_exit.place(x = 820,y = 500,width = 100,height = 30)
        # 显示窗口
        self.topWindow.mainloop()
################################饲养管理--档案类别类##################################

