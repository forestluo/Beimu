import pandas as pd
import numpy as np
aaa=pd.read_excel("yyh.xlsx")
aaa.loc[:,"ccc"]=aaa["ccc"]*100+2
aaa.loc[:,"bbb"]=aaa["bbb"]+"yyh"
print(aaa.head(5))
