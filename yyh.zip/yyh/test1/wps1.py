# First import the module you want

# rpcwpsapi contains the interfaces for WPS

# rpcwppapi is for WPP

# and rpcetapi for ET

# the common module contains the shared interfaces, you can not use it alone.

# you always need the createXXXRpcInstance, so first import

# take wps for example here

from pywpsrpc.rpcwpsapi import (createWpsRpcInstance, wpsapi)

# use the RpcProxy to make things easy...

from pywpsrpc import RpcProxy

# now create the rpc instance

hr, rpc = createWpsRpcInstance()

# all the calls returns the error code as the first value

# you can check it for fails

# 0 means all fines, you can use the common module's S_OK,

# FAILED or SUCCEEDED to check

# recommend use the RpcProxy instead

# get the application and you get everything...

# here we use the RpcProxy to wrap the application

# otherwise, you have to call Release on each instance

# and handle the hr for every call...

app = RpcProxy(rpc.getWpsApplication())

# Add blank doc e.g.

doc = app.Documents.Add()

# append text...

selection = app.Selection

selection.InsertAfter("Hello, world")

# bold the "Hello, world"

selection.Font.Bold = True

# get a notify about saving

#rpc.registerEvent(app.rpc_object,

# wpsapi.DIID_ApplicationEvents4,

# "DocumentBeforeSave",

# onDocumentBeforeSave)

#def onDocumentBeforeSave(doc, saveAsUi, cancel):

# to discard the saving, return cancel as True

# return saveAsUi, cancel

# save the doc, onDocumentBeforeSave will be called

doc.SaveAs2("test.docx")

# Quit the application if you don't need anymore

# use wpsapi.wdDoNotSaveChanges to ignore the changes

app.Quit(wpsapi.wdDoNotSaveChanges)
