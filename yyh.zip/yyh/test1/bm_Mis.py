##########################import的模块###########################################
#from distutils.command.sdist import sdist
#from yaml import safe_dump
import tkinter as tk
import tkinter.messagebox as msgbox

#from matplotlib.pyplot import text
import bm_base as bB
##########################import的模块###########################################

#########################父类##########################
class bmWindow(object):# bmWindow类（避免重复打开窗口）
    def __init__(self):                     # 类初始化方法
        self.topWindow=None
        self.topWindow_flag = None

    def destroyWindow(self):                # 关闭窗口
        self.topWindow_flag = None
        self.topWindow.destroy()

    def getWindow(self,rootWindow):         # get窗口
        if self.topWindow_flag == None:
            self.topWindow = tk.Toplevel(rootWindow)
            self.topWindow.attributes('-topmost', True)
            self.topWindow.resizable(False,False)
            self.topWindow_flag = True
            self.topWindow.protocol('WM_DELETE_WINDOW',self.destroyWindow)
            return(True)
        else:
            return(False)
#####################父类##############################

################################维护权限管理--部门管理类##################################
class bmrtDepartMent(bmWindow):# 权限管理--部门管理
    def __init__(self):
        super().__init__()
        self.tree=None
        self.txt=None
        self.bmDB=bB.bmDB()
    def calladd(self,event=None):
        self.tree.event_generate('<<Cut>>')
        
    def calldelete(self):
        aaa=msgbox.askyesno("信息","您确认要删除吗？",parent=self.topWindow)
        if aaa==True:
            self.tree.delete(self.tree.focus())
        
    def callmove(self,event=None):
        self.tree.event_generate('<<Paste>>')

    def popup(self,event):
        self.menu.post(event.x_root, event.y_root)   # post在指定的位置显示弹出菜单

    def refreshlist(self,event):
        msgbox.showinfo("信息",self.tree.selection(),parent=self.topWindow)
    
    def zhankaitree(self):
        self.tree.item(self.tree.focus(), open=True) # Tried with and without
        for child in self.tree.get_children(self.tree.focus()):
            self.tree.item(child, open=True)

    def reorder(self,result,pid,item_p):
        if item_p==None:
            for i in result:
                if str(i[0])==pid:
                    item_p = self.tree.insert("",'end',str(i[0]),text=str(i[2]))
                    #self.tree.item(self.tree.focus(),open=True)
                    self.reorder(result,pid,item_p)
        else:
            for i in result:
                if str(i[1])==pid:
                    item_p1=self.tree.insert(item_p,'end',str(i[0]),text=str(i[2]))
                    #self.tree.item(self.tree.focus(),open=True)
                    self.reorder(result,str(i[0]),item_p1)

    def getDB(self):
        sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department order by rdorder'
        info,result=self.bmDB.returnResult(sql)
        if info!='OK':
            msgbox.showerror("错误信息",info,parent=self.topWindow)
        else:
            self.reorder(result,"rd00000001",None)

    def showWindow(self,rootWindow):
        info=self.getWindow(rootWindow)
        if info==True:
            self.topWindow.title("权限管理--部门管理")
            self.topWindow.geometry('1000x560+300+170')
            # 创建树状对象
            self.tree = tk.ttk.Treeview(self.topWindow,height=30)
            self.getDB()

            # self.menu = tk.Menu(self.topWindow,tearoff=False)
            # self.menu.add_command(label="增加", command=self.calladd)
            # self.menu.add_command(label="删除", command=self.calldelete)
            # self.menu.add_command(label="移动", command=self.callmove)

            # self.tree.bind("<Button-3>", self.popup)                 # 绑定鼠标右键,执行popup函数
            # self.tree.bind("<Button-1>", self.refreshlist)                 # 绑定鼠标左键,执行refreshlist函数

            #self.tree.bind("<<TreeviewSelect>>", self.refreshlist)                 # 绑定鼠标左键,执行refreshlist函数
            #self.vbar = tk.ttk.Scrollbar(self.topWindow,orient=tk.VERTICAL,command=self.tree.yview)
            #self.tree.configure(yscrollcommand=self.vbar.set)
            #self.tree.grid(row=0,column=0,sticky=tk.NSEW)
            #self.tree.grid(row=0,column=1,sticky=tk.NS)
            
            self.tree.place(x = 10,y = 10,width = 300,height = 120)

            # self.txt = tk.Text(self.topWindow)
            # self.txt.place(x = 350,y = 20,width = 600,height = 200)

            self.btn1 = tk.Button(self.topWindow, text='展开树形结构', command=self.zhankaitree)
            self.btn1.place(x = 350,y = 250,width = 100,height = 30)
            self.topWindow.mainloop()
################################维护权限管理--部门管理类##################################

################################维护档案管理类##################################
class bmSpType(bmWindow):# 档案管理--类别管理
    def __init__(self):
        super().__init__()
        self.tree=None

    def calladd(self,event=None):
        self.tree.event_generate('<<Cut>>')
        
    def calldelete(self):
        aaa=msgbox.askyesno("信息","您确认要删除吗？",parent=self.topWindow)
        if aaa==True:
            self.tree.delete(self.tree.focus())
        
    def callmove(self,event=None):
        self.tree.event_generate('<<Paste>>')

    def showWindow(self,rootWindow):
        info=self.getWindow(rootWindow)
        if info==True:
            self.topWindow.title("档案管理--类别管理")
            self.topWindow.geometry('1000x560+300+170')
            # 创建树状对象
            self.tree = tk.ttk.Treeview(self.topWindow,height=10)

            # 添加第一层级列
            self.tree11 = self.tree.insert('',0,'china',text='中国')
            self.tree12 = self.tree.insert('',1,'americal',text='美国')
            self.tree13 = self.tree.insert('',2,'taiwan',text='中国-台湾')
            self.tree14 = self.tree.insert('',3,'gem',text='德国')
            
            # 添加第二层级列
            self.tree11_1 = self.tree.insert(self.tree11,0,'bj',text='北京')
            self.tree11_2 = self.tree.insert(self.tree11,1,'sh',text='上海')
            self.tree11_3 = self.tree.insert(self.tree11,2,'tj',text='天津')
            self.tree11_4 = self.tree.insert(self.tree11,3,'gd',text='广东')

            self.tree12_1 = self.tree.insert(self.tree12,0,'ny',text='纽约')
            self.tree12_2 = self.tree.insert(self.tree12,1,'hsd',text='华盛顿')
            
            # 添加第三级
            self.tree11_1_1 = self.tree.insert(self.tree11_1,0,'xa',text='雄安新区')
            self.tree11_1_2 = self.tree.insert(self.tree11_1,1,'qt',text='其他地区')
            
            self.tree.place(x = 10,y = 10,width = 300,height = 500)

            self.menu = tk.Menu(self.topWindow,tearoff=False)
            self.menu.add_command(label="增加", command=self.calladd)
            self.menu.add_command(label="删除", command=self.calldelete)
            self.menu.add_command(label="移动", command=self.callmove)

            self.vbar = tk.ttk.Scrollbar(self.topWindow,orient=tk.VERTICAL,command=self.tree.yview)
            self.tree.configure(yscrollcommand=self.vbar.set)
            self.tree.grid(row=0,column=0,sticky=tk.NSEW)
            self.tree.grid(row=0,column=1,sticky=tk.NS)
            
            def popup(event):
                self.menu.post(event.x_root, event.y_root)   # post在指定的位置显示弹出菜单
            self.tree.bind("<Button-3>", popup)                 # 绑定鼠标右键,执行popup函数
            self.topWindow.mainloop()
################################维护档案管理类##################################
