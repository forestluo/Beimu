from tkinter import *

root = Tk()
root.title("apidemos.com")
root.geometry("300x180")

menubar = Menu(root)           # 建立最上层菜单
# 建立菜单类别对象，并将此菜单类别命名为File

filemenu = Menu(menubar,tearoff=False)
menubar.add_cascade(label="File",menu=filemenu)
# 在File菜单内建立菜单列表Exit
filemenu.add_command(label="Exit",command=root.destroy)

# 建立工具栏
toolbar = Frame(root,relief=RAISED,borderwidth=3)
# 在工具栏内创建按钮
myGif = PhotoImage(file="ccc.png")
exitBtn = Button(toolbar,image=myGif,height=20,width=20,command=root.destroy)
exitBtn.pack(side=LEFT,padx=1,pady=1)                          # 包装按钮
exitBtn1 = Button(toolbar,image=myGif,height=20,width=20,command=root.destroy)
exitBtn1.pack(side=LEFT,padx=1,pady=1)                          # 包装按钮
exitBtn2 = Button(toolbar,image=myGif,height=20,width=20,command=root.destroy)
exitBtn2.pack(side=LEFT,padx=1,pady=1)                          # 包装按钮
exitBtn3 = Button(toolbar,image=myGif,height=20,width=20,command=root.destroy)
exitBtn3.pack(side=LEFT,padx=1,pady=1)                          # 包装按钮
exitBtn4 = Button(toolbar,image=myGif,height=20,width=20,command=root.destroy)
exitBtn4.pack(side=LEFT,padx=1,pady=1)                          # 包装按钮
exitBtn5 = Button(toolbar,image=myGif,height=20,width=20,command=root.destroy)
exitBtn5.pack(side=LEFT,padx=1,pady=1)                          # 包装按钮


toolbar.pack(side=TOP,fill=X)                                  # 包装工具栏
root.config(menu=menubar)                                      # 显示菜单对象

root.mainloop()