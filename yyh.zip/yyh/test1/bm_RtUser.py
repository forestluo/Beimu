##########################import的模块###########################################
from ast import Return
import tkinter                      as tk
import tkinter.messagebox           as msgbox
import bm_base                      as bm_base
##########################import的模块###########################################

################################权限管理--部门管理类##################################
class bmRtUser(bm_base.bmWindow):# 权限管理--部门管理
    def __init__(self):# 类初始化
        super().__init__()
        self.bmDB=bm_base.bmDB()
        self.tree_rdid=""
        self.tree1_rdid=""

    def add(self):# 增加部门
        self.tree1_rdid=""
        self.entry_rdname.delete(0,tk.END)
        self.entry_rdorder.delete(0,tk.END)
        self.entry_rddesc.delete(0,tk.END)

    def save(self):# 保存部门
        rdid=self.tree1_rdid
        rdpid=self.tree_rdid
        rdname=self.entry_rdname.get()
        rdorder=self.entry_rdorder.get()
        rddesc=self.entry_rddesc.get()
        if rdpid=="":
            msgbox.showerror("信息","请选择上一级部门。",parent=self.topWindow)
            return()
        if rdname=="":
            msgbox.showerror("信息","请输入部门名称。",parent=self.topWindow)
            return()
        if rdorder=="":
            msgbox.showerror("信息","请输入排序字段。",parent=self.topWindow)
            return()
        if rdid=="":# 增加记录
            info,rdid=self.bmDB.getFieldMaxID('rt_department','rdid','rd',10)
            if info!='OK':
                msgbox.showerror("信息",info,parent=self.topWindow)
                return()
            sql='insert into rt_department(rdid,rdpid,rdname,rdorder,rddesc) \
                values(\'' + rdid + '\',\'' + rdpid + '\',\'' + rdname + '\',\'' + rdorder + \
                    '\',\'' + rddesc +'\')' 
            info=self.bmDB.execSQL(sql)
            if info!="OK":
                msgbox.showerror("信息",info,parent=self.topWindow)
                return()
        else:       # 修改记录
            sql='update rt_department set rdname=\'' + rdname + '\',rdorder=\'' + rdorder + \
                '\',rddesc=\'' + rddesc +'\' where rdid=\'' + rdid +'\'' 
            info=self.bmDB.execSQL(sql)
            if info!="OK":
                msgbox.showerror("信息",info,parent=self.topWindow)
                return()

        self.tree1_rdid=""
        tree_rdid=self.tree.selection()                            
        self.showTree()
        self.tree.selection_set(tree_rdid)

    def delete(self):# 删除部门
        if self.tree1_rdid=="":
            return()
        if msgbox.askyesno("信息","您确认要删除这个部门吗？",parent=self.topWindow)==False:
            return()
        sql='select rdid from rt_department where rdpid=\'' + self.tree1_rdid + '\''
        info,result=self.bmDB.returnResult(sql)
        if info!="OK":
            msgbox.showerror("信息",info,parent=self.topWindow)
            return()
        if len(result)>0:
            msgbox.showerror("信息","该部门下有子部门，不能删除。",parent=self.topWindow)
            return()
        sql='select * from rt_relation where rerdid=\'' + self.tree1_rdid + '\''
        info,result=self.bmDB.returnResult(sql)
        if info!="OK":
            msgbox.showerror("信息",info,parent=self.topWindow)
            return()
        if len(result)>0:
            msgbox.showerror("信息","该部门下有用户，不能删除。",parent=self.topWindow)
            return()
        sql='delete from rt_department where rdid=\'' + self.tree1_rdid + '\''
        info=self.bmDB.execSQL(sql)
        if info!="OK":
            msgbox.showerror("信息",info,parent=self.topWindow)
            return()
        self.tree1_rdid=""
        tree_rdid=self.tree.selection()                            
        self.showTree()
        self.tree.selection_set(tree_rdid)

    def refreshList(self,rdid):# 刷新self.tree1
        aaa=list(rdid)
        bbb=str(aaa[0])
        self.tree_rdid=bbb
        for i in self.tree1.get_children():
            self.tree1.delete(i)
        for i in self.result:
            if str(i[1])==bbb:
                self.tree1.insert('', 'end',str(i[0]), values=(str(i[2]),str(i[3]),str(i[4])))
        self.add()

    def refreshEntry(self,rdid):# 刷新文本框
        aaa=list(rdid)
        bbb=str(aaa[0])
        self.tree1_rdid=bbb

        aaa=list(self.tree1.item(bbb).values())
        bbb=aaa[2]
        self.entry_rdname.delete(0,tk.END)
        self.entry_rdorder.delete(0,tk.END)
        self.entry_rddesc.delete(0,tk.END)

        self.entry_rdname.insert(tk.END,bbb[0])
        self.entry_rdorder.insert(tk.END,bbb[1])
        self.entry_rddesc.insert(tk.END,bbb[2])

    def reorder(self,result,pid,item_p):# 递归调用刷新self.tree
        if item_p==None:
            for i in result:
                if str(i[0])==pid:
                    item_p = self.tree.insert("",'end',str(i[0]),text=str(i[2]),open=True)
                    self.reorder(result,pid,item_p)
        else:
            for i in result:
                if str(i[1])==pid:
                    item_p1=self.tree.insert(item_p,'end',str(i[0]),text=str(i[2]),open=True)
                    self.reorder(result,str(i[0]),item_p1)

    def showTree(self):# 显示self.tree
        for i in self.tree.get_children():
            self.tree.delete(i)
        sql='select rdid,rdpid,rdname,rdorder,rddesc from rt_department order by rdorder'
        info,self.result=self.bmDB.returnResult(sql)
        if info!='OK':
            msgbox.showerror("错误信息",info,parent=self.topWindow)
        else:
            self.reorder(self.result,"rd00000001",None)

    def showWindow(self,rootWindow):# 显示窗口
        self.getWindow(rootWindow)
        # self.tree    
        self.topWindow.title("权限管理--用户管理")
        self.topWindow.geometry('1000x560+300+170')
        self.tree = tk.ttk.Treeview(self.topWindow)
        self.tree.place(x = 10,y = 10,width = 300,height = 530)
        self.tree.bind("<<TreeviewSelect>>", lambda event:self.refreshList(self.tree.selection())) # 绑定TreeViewSelect事件
        self.showTree()
        # self.tree1
        columns = ("部门名称","排序字段","描述")
        self.tree1 = tk.ttk.Treeview(self.topWindow,show="headings",columns = columns)   # 创建树状对象

        self.tree1.column("部门名称", width=250, anchor='center')
        self.tree1.column("排序字段", width=80, anchor='center') # 表示列,不显示
        self.tree1.column("描述", width=320, anchor='center')

        self.tree1.heading("部门名称", text="部门名称")
        self.tree1.heading("排序字段", text="排序字段")
        self.tree1.heading("描述", text="描述")

        self.tree1.place(x = 320,y = 10,width = 650,height = 400)
        self.tree1.bind("<<TreeviewSelect>>", lambda event:self.refreshEntry(self.tree1.selection())) # 绑定TreeViewSelect事件
        # 文本框
        self.lable_rdname=tk.Label(self.topWindow,text="部门名称：",anchor='e')
        self.lable_rdname.place(x = 320,y = 420,width = 100,height = 30)
        self.entry_rdname=tk.Entry(self.topWindow)
        self.entry_rdname.place(x = 420,y = 420,width = 300,height = 30)

        self.lable_rdorder=tk.Label(self.topWindow,text="排序字段：",anchor='e')
        self.lable_rdorder.place(x = 720,y = 420,width = 100,height = 30)
        self.entry_rdorder=tk.Entry(self.topWindow)
        self.entry_rdorder.place(x = 820,y = 420,width = 100,height = 30)

        self.lable_rddesc=tk.Label(self.topWindow,text="描述：",anchor='e')
        self.lable_rddesc.place(x = 320,y = 460,width = 100,height = 30)
        self.entry_rddesc=tk.Entry(self.topWindow)
        self.entry_rddesc.place(x = 420,y = 460,width = 500,height = 30)
        # 按钮
        self.button_add = tk.Button(self.topWindow, text='增加', command=self.add)
        self.button_add.place(x = 420,y = 500,width = 100,height = 30)

        self.button_save = tk.Button(self.topWindow, text='保存', command=self.save)
        self.button_save.place(x = 540,y = 500,width = 100,height = 30)

        self.button_add = tk.Button(self.topWindow, text='删除', command=self.delete)
        self.button_add.place(x = 660,y = 500,width = 100,height = 30)

        self.button_exit = tk.Button(self.topWindow, text='退出', \
             command=self.destroyWindow)
        self.button_exit.place(x = 820,y = 500,width = 100,height = 30)
        # 显示窗口
        self.topWindow.mainloop()
################################权限管理--部门管理类##################################

